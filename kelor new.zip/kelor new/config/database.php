<?php
// Buat class koneksi
class database 
{
    // Property database
    protected $hostname = "localhost"; 
    protected $username = "yosef";
    protected $password = "tanyayoyok";
    protected $database = "u1606087_sikelor";

    // Properti koneksi dibuat publik agar bisa diakses oleh child class
    public $koneksi;

    // Konstruktor untuk membuat koneksi saat class diinstansiasi
    public function __construct()
    {
        // Jika koneksi belum ada, buat koneksi baru
        if (!isset($this->koneksi)) {
            $this->koneksi = new mysqli(
                $this->hostname,
                $this->username,
                $this->password,
                $this->database
            );

            // Cek apakah koneksi gagal
            if ($this->koneksi->connect_error) {
                die("Koneksi database gagal: " . $this->koneksi->connect_error);
            }
        }
    }
}
?>
