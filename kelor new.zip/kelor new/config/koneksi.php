<?php 
// Konfigurasi database
$hostname 	= "localhost"; 
$username 	= "yosef";
$password 	= "tanyayoyok";
$database 	= "u1606087_sikelor";

// Membuat koneksi
$koneksi = mysqli_connect($hostname, $username, $password, $database);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>
