<?php

session_start();

date_default_timezone_set('Asia/Jakarta');
include('../config/koneksi.php');

$peg = mysqli_query($koneksi, "SELECT * FROM pegawai ORDER BY id ASC");

require '../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$sheet->setCellValue('A1', 'NIP');
$sheet->setCellValue('B1', 'NAMA');
$sheet->setCellValue('C1', 'TEMPAT LAHIR');
$sheet->setCellValue('D1', 'TGL LAHIR');
$sheet->setCellValue('E1', 'GENDER');
$sheet->setCellValue('F1', 'AGAMA');
$sheet->setCellValue('G1', 'KEBANGSAAN');
$sheet->setCellValue('H1', 'JUMLAH KELUARGA');
$sheet->setCellValue('I1', 'ALAMAT');
$sheet->setCellValue('J1', 'SK TERAKHIR');
$sheet->setCellValue('K1', 'PANGKAT');
$sheet->setCellValue('L1', 'TMT GOLONGAN');
$sheet->setCellValue('M1', 'JENIS PEGAWAI');
$sheet->setCellValue('N1', 'TMT CAPEG');
$sheet->setCellValue('O1', 'STATUS PEGAWAI');
$sheet->setCellValue('P1', 'JABATAN');
$sheet->setCellValue('Q1', 'DIGAJI MENURUT');
$sheet->setCellValue('R1', 'GAJI POKOK');
$sheet->setCellValue('S1', 'BESARNYA PENGHASILAN');
$sheet->setCellValue('T1', 'MASA KERJA GOLONGAN');
$sheet->setCellValue('U1', 'MASA KERJA KESELURUHAN');
$sheet->setCellValue('V1', 'NPWP');
$sheet->setCellValue('W1', 'RT');
$sheet->setCellValue('X1', 'RW');
$sheet->setCellValue('Y1', 'DESA');
$sheet->setCellValue('Z1', 'KECAMATAN');
$sheet->setCellValue('AA1', 'KABUPATEN');
$sheet->setCellValue('AB1', 'WA');

// Mengatur teks menjadi bold pada baris pertama
$boldFont = $sheet->getStyle('A1:AB1')->getFont();
$boldFont->setBold(true);

// Mengatur lebar kolom
$sheet->getColumnDimension('A')->setWidth(5);
$sheet->getColumnDimension('B')->setWidth(20);
$sheet->getColumnDimension('C')->setWidth(15);
$sheet->getColumnDimension('D')->setWidth(15);
$sheet->getColumnDimension('E')->setWidth(10);
$sheet->getColumnDimension('F')->setWidth(10);
$sheet->getColumnDimension('G')->setWidth(15);
$sheet->getColumnDimension('H')->setWidth(15);
$sheet->getColumnDimension('I')->setWidth(30);
$sheet->getColumnDimension('J')->setWidth(20);
$sheet->getColumnDimension('K')->setWidth(15);
$sheet->getColumnDimension('L')->setWidth(15);
$sheet->getColumnDimension('M')->setWidth(15);
$sheet->getColumnDimension('N')->setWidth(15);
$sheet->getColumnDimension('O')->setWidth(15);
$sheet->getColumnDimension('P')->setWidth(15);
$sheet->getColumnDimension('Q')->setWidth(15);
$sheet->getColumnDimension('R')->setWidth(15);
$sheet->getColumnDimension('S')->setWidth(20);
$sheet->getColumnDimension('T')->setWidth(20);
$sheet->getColumnDimension('U')->setWidth(20);
$sheet->getColumnDimension('V')->setWidth(15);
$sheet->getColumnDimension('W')->setWidth(5);
$sheet->getColumnDimension('X')->setWidth(5);
$sheet->getColumnDimension('Y')->setWidth(20);
$sheet->getColumnDimension('Z')->setWidth(20);
$sheet->getColumnDimension('AA')->setWidth(20);
$sheet->getColumnDimension('AB')->setWidth(15);

$nomor = 1;
$row = 2;

while ($row_data = mysqli_fetch_array($peg)) {
    $sheet->setCellValue('A' . $row, $row_data['nip']);
    $sheet->setCellValue('B' . $row, $row_data['nama']);
    $sheet->setCellValue('C' . $row, $row_data['tempat_lahir']);
    $sheet->setCellValue('D' . $row, $row_data['tgl_lahir']);
    $sheet->setCellValue('E' . $row, $row_data['gender']);
    $sheet->setCellValue('F' . $row, $row_data['agama']);
    $sheet->setCellValue('G' . $row, $row_data['kebangsaan']);
    $sheet->setCellValue('H' . $row, $row_data['jumlah_keluarga']);
    $sheet->setCellValue('I' . $row, $row_data['alamat']);
    $sheet->setCellValue('J' . $row, $row_data['sk_terakhir']);
    $sheet->setCellValue('K' . $row, $row_data['pangkat']);
    $sheet->setCellValue('L' . $row, $row_data['tmt_golongan']);
    $sheet->setCellValue('M' . $row, $row_data['jenis_pegawai']);
    $sheet->setCellValue('N' . $row, $row_data['tmt_capeg']);
    $sheet->setCellValue('O' . $row, $row_data['status_pegawai']);
    $sheet->setCellValue('P' . $row, $row_data['jabatan']);
    $sheet->setCellValue('Q' . $row, $row_data['digaji_menurut']);
    $sheet->setCellValue('R' . $row, $row_data['gaji_pokok']);
    $sheet->setCellValue('S' . $row, $row_data['besarnya_penghasilan']);
    $sheet->setCellValue('T' . $row, $row_data['masa_kerja_golongan']);
    $sheet->setCellValue('U' . $row, $row_data['masa_kerja_keseluruhan']);
    $sheet->setCellValue('V' . $row, $row_data['npwp']);
    $sheet->setCellValue('W' . $row, $row_data['rt']);
    $sheet->setCellValue('X' . $row, $row_data['rw']);
    $sheet->setCellValue('Y' . $row, $row_data['desa']);
    $sheet->setCellValue('Z' . $row, $row_data['kecamatan']);
    $sheet->setCellValue('AA' . $row, $row_data['kabupaten']);
    $sheet->setCellValue('AB' . $row, $row_data['wa']);
  
    $row++;
}

$writer = new Xlsx($spreadsheet);
$filename = 'data_pegawai.xlsx';
$savePath = '../files/excel/' . $filename;
$writer->save($savePath);

$fileUrl = '../files/excel/' . $filename;

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: inline; filename="'.$filename.'"');
header('Content-Length: ' . filesize($fileUrl));
readfile($fileUrl);
exit();
?>
