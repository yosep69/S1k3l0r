<?php

session_start();

date_default_timezone_set('Asia/Jakarta');
include('../config/koneksi.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];

        // Ambil informasi file
        $fileName = $file['name'];
        $fileTmp = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];

        // Tentukan format file yang diperbolehkan
        $allowedFormats = ['csv', 'xlsx', 'xls'];

        // Ambil ekstensi file
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));


        if (in_array($fileExt, $allowedFormats)) {
            // Tentukan path untuk menyimpan file
            $uploadPath = '../files/import/' . $fileName;

            // Pindahkan file ke path yang ditentukan
            move_uploaded_file($fileTmp, $uploadPath);

            if ($fileExt === 'csv') {
                // Impor file CSV
                $handle = fopen($uploadPath, 'r');
                $header = fgetcsv($handle);

                while (($data = fgetcsv($handle, 1000, ';')) !== false) {
                    // Proses penyimpanan data ke dalam tabel pegawai
                    // Sesuaikan kode ini dengan struktur tabel dan kolom yang ada
                    $nip = !empty($data[0]) ? $data[0] : "-";
                    $nama = !empty($data[1]) ? $data[1] : "-";
                    $tempat_lahir = !empty($data[2]) ? $data[2] : "-";
                    $tgl_lahir = !empty($data[3]) ? $data[3] : "0000-00-00";
                    $gender = !empty($data[4]) ? $data[4] : "-";
                    $agama = !empty($data[5]) ? $data[5] : "-";
                    $kebangsaan = !empty($data[6]) ? $data[6] : "WNI";
                    $jumlah_keluarga = !empty($data[7]) ? $data[7] : "0";
                    $alamat = !empty($data[8]) ? $data[8] : "-";
                    $sk_terakhir = !empty($data[9]) ? $data[9] : "-";
                    $pangkat = !empty($data[10]) ? $data[10] : "-";
                    $tmt_golongan = !empty($data[11]) ? $data[11] : "0000-00-00";
                    $jenis_pegawai = !empty($data[12]) ? $data[12] : "-";
                    $tmt_capeg = !empty($data[13]) ? $data[13] : "0000-00-00";
                    $status_pegawai = !empty($data[14]) ? $data[14] : "-";
                    $jabatan = !empty($data[15]) ? $data[15] : "-";
                    $digaji_menurut = !empty($data[16]) ? $data[16] : "-";
                    $gaji_pokok = !empty($data[17]) ? $data[17] : "-";
                    $besarnya_penghasilan = !empty($data[18]) ? $data[18] : "0";
                    $masa_kerja_golongan = !empty($data[19]) ? $data[19] : "-";
                    $masa_kerja_keseluruhan = !empty($data[20]) ? $data[20] : "-";
                    $npwp = !empty($data[21]) ? $data[21] : "-";
                    $rt = !empty($data[22]) ? $data[22] : "-";
                    $rw = !empty($data[23]) ? $data[23] : "-";
                    $desa = !empty($data[24]) ? $data[24] : "-";
                    $kecamatan = !empty($data[25]) ? $data[25] : "-";
                    $kabupaten = !empty($data[26]) ? $data[26] : "-";
                    $wa = !empty($data[27]) ? $data[27] : "-";

                    // Pengecekan keunikan NIP
                    $query = "SELECT COUNT(*) AS count FROM pegawai WHERE nip = '$nip'";
                    $result = mysqli_query($koneksi, $query);
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    if ($count) {
                        echo "<script> 
                                    alert('NIP tidak unik: $nip');
                                    window.location.href = '../index.php?controller=pegawai&method=select';
                                </script>";
                    } else {
                        $query_insert = "INSERT INTO pegawai (nip,nama, tempat_lahir, tgl_lahir, gender, agama, kebangsaan, jumlah_keluarga, alamat, sk_terakhir, pangkat, tmt_golongan, jenis_pegawai, tmt_capeg, status_pegawai, jabatan, digaji_menurut, gaji_pokok, besarnya_penghasilan, masa_kerja_golongan, masa_kerja_keseluruhan, npwp, rt, rw, desa, kecamatan, kabupaten, wa) 
                                VALUES ('$nip','$nama', '$tempat_lahir', '$tgl_lahir', '$gender', '$agama', '$kebangsaan', '$jumlah_keluarga', '$alamat', '$sk_terakhir', '$pangkat', '$tmt_golongan', '$jenis_pegawai', '$tmt_capeg', '$status_pegawai', '$jabatan', '$digaji_menurut', '$gaji_pokok', '$besarnya_penghasilan', '$masa_kerja_golongan', '$masa_kerja_keseluruhan', '$npwp', '$rt', '$rw', '$desa', '$kecamatan', '$kabupaten', '$wa')";
                        mysqli_query($koneksi, $query_insert);
                        echo "<script> 
                          alert('Import data berhasil!');
                          window.location = '../index.php?controller=pegawai&method=select'; 
                          </script>";
                    }
                }

                fclose($handle);
            } else if ($fileExt === 'xlsx' || $fileExt === 'xls') {
                // Impor file XLSX atau XLS
                require '../vendor/autoload.php';
                $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($uploadPath);
                $sheetData = $spreadsheet->getActiveSheet()->toArray();
                // print_r(count($sheetData));exit;
                for ($i = 1; $i < count($sheetData); $i++) {
                    $nip     = $sheetData[$i]['0'];
                    $nama    = $sheetData[$i]['1'];
                    $tempat_lahir     = $sheetData[$i]['2'];
                    $tgl_lahir = $sheetData[$i]['3'];
                    $gender     = $sheetData[$i]['4'];
                    $agama    = $sheetData[$i]['5'];
                    $kebangsaan     = $sheetData[$i]['6'];
                    $jumlah_keluarga = $sheetData[$i]['7'];
                    $alamat     = $sheetData[$i]['8'];
                    $sk_terakhir    = $sheetData[$i]['9'];
                    $pangkat     = $sheetData[$i]['10'];
                    $tmt_golongan = $sheetData[$i]['11'];
                    $jenis_pegawai     = $sheetData[$i]['12'];
                    $tmt_capeg    = $sheetData[$i]['13'];
                    $status_pegawai     = $sheetData[$i]['14'];
                    $jabatan = $sheetData[$i]['15'];
                    $digaji_menurut     = $sheetData[$i]['16'];
                    $gaji_pokok    = $sheetData[$i]['17'];
                    $besarnya_penghasilan     = $sheetData[$i]['18'];
                    $masa_kerja_golongan = $sheetData[$i]['19'];
                    $masa_kerja_keseluruhan     = $sheetData[$i]['20'];
                    $npwp    = $sheetData[$i]['21'];
                    $rt     = $sheetData[$i]['22'];
                    $rw = $sheetData[$i]['23'];
                    $desa     = $sheetData[$i]['24'];
                    $kecamatan    = $sheetData[$i]['25'];
                    $kabupaten     = $sheetData[$i]['26'];
                    $wa = $sheetData[$i]['27'];
                    $query = "SELECT COUNT(*) AS count FROM pegawai WHERE nip = '$nip'";
                    $result = mysqli_query($koneksi, $query);
                    $row = mysqli_fetch_assoc($result);
                    $count = $row['count'];
                    if ($count) {

                        echo "<script> 
                                            alert('NIP tidak unik: $nip');
                                            window.location.href = '../index.php?controller=pegawai&method=select';
                                        </script>";
                    } else {
                        $query_insert = "INSERT INTO pegawai (nip,nama, tempat_lahir, tgl_lahir, gender, agama, kebangsaan, jumlah_keluarga, alamat, sk_terakhir, pangkat, tmt_golongan, jenis_pegawai, tmt_capeg, status_pegawai, jabatan, digaji_menurut, gaji_pokok, besarnya_penghasilan, masa_kerja_golongan, masa_kerja_keseluruhan, npwp, rt, rw, desa, kecamatan, kabupaten, wa) 
                                        VALUES ('$nip','$nama', '$tempat_lahir', '$tgl_lahir', '$gender', '$agama', '$kebangsaan', '$jumlah_keluarga', '$alamat', '$sk_terakhir', '$pangkat', '$tmt_golongan', '$jenis_pegawai', '$tmt_capeg', '$status_pegawai', '$jabatan', '$digaji_menurut', '$gaji_pokok', '$besarnya_penghasilan', '$masa_kerja_golongan', '$masa_kerja_keseluruhan', '$npwp', '$rt', '$rw', '$desa', '$kecamatan', '$kabupaten', '$wa')";
                        mysqli_query($koneksi, $query_insert);
                        echo "<script> 
                                  alert('Import data berhasil!');
                                  window.location = '../index.php?controller=pegawai&method=select'; 
                                  </script>";
                    }
                }
                // $sheet = $spreadsheet->getActiveSheet();
                // $highestRow = $sheet->getHighestRow();
                // $highestColumn = $sheet->getHighestColumn();
                // $sheetData = $spreadsheet->getActiveSheet()->toArray();
                // for ($row = 2; $row <=count($sheetData); $row++) {
                //     // Proses penyimpanan data ke dalam tabel pegawai
                //     // Sesuaikan kode ini dengan struktur tabel dan kolom yang ada
                //     $nip = $sheet->getCell('A' . $row)->getValue();
                //     $nama = $sheet->getCell('B' . $row)->getValue();
                //     $tempat_lahir = $sheet->getCell('C' . $row)->getValue();
                //     $tgl_lahir = $sheet->getCell('D' . $row)->getValue();
                //     $gender = $sheet->getCell('E' . $row)->getValue();
                //     $agama = $sheet->getCell('F' . $row)->getValue();
                //     $kebangsaan = $sheet->getCell('G' . $row)->getValue();
                //     $jumlah_keluarga = $sheet->getCell('H' . $row)->getValue();
                //     $alamat = $sheet->getCell('I' . $row)->getValue();
                //     $sk_terakhir = $sheet->getCell('J' . $row)->getValue();
                //     $pangkat = $sheet->getCell('K' . $row)->getValue();
                //     $tmt_golongan = $sheet->getCell('L' . $row)->getValue();
                //     $jenis_pegawai = $sheet->getCell('M' . $row)->getValue();
                //     $tmt_capeg = $sheet->getCell('N' . $row)->getValue();
                //     $status_pegawai = $sheet->getCell('O' . $row)->getValue();
                //     $jabatan = $sheet->getCell('P' . $row)->getValue();
                //     $digaji_menurut = $sheet->getCell('Q' . $row)->getValue();
                //     $gaji_pokok = $sheet->getCell('R' . $row)->getValue();
                //     $besarnya_penghasilan = $sheet->getCell('S' . $row)->getValue();
                //     $masa_kerja_golongan = $sheet->getCell('T' . $row)->getValue();
                //     $masa_kerja_keseluruhan = $sheet->getCell('U' . $row)->getValue();
                //     $npwp = $sheet->getCell('V' . $row)->getValue();
                //     $rt = $sheet->getCell('W' . $row)->getValue();
                //     $rw = $sheet->getCell('X' . $row)->getValue();
                //     $desa = $sheet->getCell('Y' . $row)->getValue();
                //     $kecamatan = $sheet->getCell('Z' . $row)->getValue();
                //     $kabupaten = $sheet->getCell('AA' . $row)->getValue();
                //     $wa = $sheet->getCell('AB' . $row)->getValue();

                //     $query = "SELECT COUNT(*) AS count FROM pegawai WHERE nip = '$nip'";
                //     $result = mysqli_query($koneksi, $query);
                //     $row = mysqli_fetch_assoc($result);
                //     $count = $row['count'];
                //     if ($count) {

                //         echo "<script> 
                //                     alert('NIP tidak unik: $nip');
                //                     window.location.href = '../index.php?controller=pegawai&method=select';
                //                 </script>";
                //     } else {
                //         $query_insert = "INSERT INTO pegawai (nip,nama, tempat_lahir, tgl_lahir, gender, agama, kebangsaan, jumlah_keluarga, alamat, sk_terakhir, pangkat, tmt_golongan, jenis_pegawai, tmt_capeg, status_pegawai, jabatan, digaji_menurut, gaji_pokok, besarnya_penghasilan, masa_kerja_golongan, masa_kerja_keseluruhan, npwp, rt, rw, desa, kecamatan, kabupaten, wa) 
                //                 VALUES ('$nip','$nama', '$tempat_lahir', '$tgl_lahir', '$gender', '$agama', '$kebangsaan', '$jumlah_keluarga', '$alamat', '$sk_terakhir', '$pangkat', '$tmt_golongan', '$jenis_pegawai', '$tmt_capeg', '$status_pegawai', '$jabatan', '$digaji_menurut', '$gaji_pokok', '$besarnya_penghasilan', '$masa_kerja_golongan', '$masa_kerja_keseluruhan', '$npwp', '$rt', '$rw', '$desa', '$kecamatan', '$kabupaten', '$wa')";
                //         mysqli_query($koneksi, $query_insert);
                //         echo "<script> 
                //           alert('Import data berhasil!');
                //           window.location = '../index.php?controller=pegawai&method=select'; 
                //           </script>";
                //     }
                // }
            }
        }
    }
}
