<?php
function base_url($path = '') {
    return 'http://localhost/sikelor/' . $path;
}

session_start();

date_default_timezone_set('Asia/Jakarta');
include('../config/koneksi.php');
include("../config/database.php");
include("../model/model_riwayat.php");

static $riwayat;
$riwayat = new model_riwayat();

$pencetak = $_POST['pencetak'];
$nipcetak = $_POST['nip_cetak'];
$nip = $_POST['nip'];

$data_riwayat_golongan = $riwayat->dataRiwayatGolongan($nip);
$data_riwayat_angka_kredit = $riwayat->dataRiwayatAngkaKredit($nip);
$data_riwayat_diklat_pimpinan = $riwayat->dataRiwayatDiklatPimpinan($nip);
$data_riwayat_dp3 = $riwayat->dataRiwayatDP3($nip);
$data_riwayat_hukuman_disiplin = $riwayat->dataRiwayatHukumanDisiplin($nip);
$data_riwayat_jabatan = $riwayat->dataRiwayatJabatan($nip);
$data_riwayat_berkala = $riwayat->dataRiwayatBerkala($nip);
$data_riwayat_keterangan_keluarga = $riwayat->dataRiwayatKeteranganKeluarga($nip);
$data_riwayat_kursus = $riwayat->dataRiwayatKursus($nip);
$data_riwayat_pendidikan = $riwayat->dataRiwayatPendidikan($nip);
$data_riwayat_penghargaan = $riwayat->dataRiwayatPenghargaan($nip);

$peg = mysqli_query($koneksi, "SELECT * FROM pegawai WHERE nip='$nip'");
$data_pegawai = mysqli_fetch_array($peg);

$data = mysqli_query($koneksi, "SELECT * FROM profil");
$home = mysqli_fetch_array($data);

// Konversi logo ke base64
$logo_path = realpath(__DIR__ . '/../logo/2_ikon_log.png');
$logo_base64 = '';
if (file_exists($logo_path)) {
    $logo_data = file_get_contents($logo_path);
    $logo_base64 = 'data:image/png;base64,' . base64_encode($logo_data);
}

// Konversi foto pegawai ke base64
$foto_base64 = '';
$foto_path = realpath(__DIR__ . '/../uploads/foto_pegawai/' . $data_pegawai['foto']);
if (!empty($data_pegawai['foto']) && file_exists($foto_path)) {
    $foto_data = file_get_contents($foto_path);
    $foto_base64 = 'data:image/jpeg;base64,' . base64_encode($foto_data);
}

require_once '../dompdf/autoload.inc.php';
use Dompdf\Dompdf;

$pdf = new Dompdf();

// Aktifkan akses file lokal
$options = $pdf->getOptions();
$options->setIsRemoteEnabled(true);
$pdf->setOptions($options);

// Mulai penangkapan output
ob_start();
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Profil ASN - <?php echo $data_pegawai['nama']; ?></title>
     <style>
        @page {
    margin-top: 2cm;
    margin-bottom: 2cm;
    margin-left: 2.5cm;
    margin-right: 2.5cm;
}


        body {
            font-family: Arial, sans-serif;
            font-size: 11px;
            color: #000;
            margin: 0;
            padding: 0;
        }

        * {
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 5px;
        }

        th, td {
            padding: 5px;
            vertical-align: top;
        }

        thead th {
            border-bottom: 3px double #000;
            text-align: center;
            font-weight: bold;
            background-color: #f9f9f9;
        }

        .table1 {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
            font-family: sans-serif;
            border: 2px solid #000;
        }

        .table1 th, .table1 td {
            border: 1px solid #000;
            padding: 5px;
        }

        .text-center {
            text-align: center;
        }

        .judul {
            text-align: center;
    vertical-align: middle;
    font-size: 14px;
    line-height: 1.5;
        }

        .judul-teks {
            text-align: center;
            font-weight: bold;
            font-size: 14px;
            line-height: 1.5;
        }

        .area {
            margin: 20px;
        }

        .container {
            padding-top: 1rem;
            margin: 0 auto;
        }

        .logo {
            width: 80px;
        }

        img.foto-pegawai {
            width: 100px;
            height: 120px;
            object-fit: cover;
            border: 1px solid #333;
            padding: 2px;
        }

        .page {
            page-break-after: always;
        }

        .page:last-child {
            page-break-after: unset;
        }

        .no-border td {
            border: none !important;
        }

        .no-padding {
            padding: 0 !important;
        }

        .no-margin {
            margin: 0 !important;
        }

        .center {
            text-align: center;
        }

        .right {
            text-align: right;
        }

        .bold {
            font-weight: bold;
        }
    </style>

</head>
<body>

<table>
    <tr>
        <!-- Logo -->
        <td class="logo">
            <?php if ($logo_base64 != '') { ?>
                <img src="<?php echo $logo_base64; ?>" width="100" height="120">
            <?php } ?>
        </td>

        <!-- Judul -->
        <td class="judul" style="text-align: center;">
            <b>BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA<br>
            KABUPATEN PARIGI MOUTONG</b><br><br>
            <h3><b>PROFIL APARATUR SIPIL NEGARA</b></h3>
        </td>

        <!-- Foto Pegawai -->
        <td class="foto">
            <?php if ($foto_base64 != '') { ?>
                <img src="<?php echo $foto_base64; ?>" width="100" height="120">
            <?php } else { ?>
                <i>Tidak ada foto</i>
            <?php } ?>
        </td>
    </tr>
</table>
<hr>

        <table class="table1">
                <thead>
                    <tr class="table-head">
                        <td colspan="2" style="text-align:center; font-weight:bold;">DATA INSTANSI</td>
                    </tr>
                </thead>

            <tbody>

                <tr>
                    <td style="font-weight:bold;">NAMA UNIT KERJA</td>
                    <td>:
                        <?php echo $data_pegawai['kebangsaan'];?>
                    </td>
                </tr>
                <!--<tr>
                    <td>ALAMAT UNIT KERJA</td>
                    <td>:
                        <?php echo $home['alamat']; ?>
                    </td>
                </tr>-->
                <tr>
                    <td style="font-weight:bold;">INSTANSI INDUK</td>
                    <td>:
                        <?php echo $home['instansi']; ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <!-- data_pribadi -->
        <table class="table1">
            <thead>

                <tr class="table-head">
                    <td colspan="2" style="text-align:center; font-weight:bold;">DATA PRIBADI</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="font-weight:bold;">Nama Lengkap</td>
                    <td>:
                        <?php echo $data_pegawai['nama']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">NIP</td>
                    <td>:
                        <?php echo $data_pegawai['nip']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Pangkat / Golongan ( ruang )</td>
                    <td>:
                        <?php echo $data_pegawai['pangkat']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">TMT Golongan ( ruang )</td>
                    <td>:
                        <?php if ($data_pegawai['tmt_golongan'] == "0000-00-00") {
                        } else {
                            echo TanggalIndo($data_pegawai['tmt_golongan']);
                        } ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Tempat / tanggal lahir</td>
                    <td>:
                        <?php echo $data_pegawai['tempat_lahir']; ?> /
                        <?php if ($data_pegawai['tgl_lahir'] == "0000-00-00") {
                        } else {
                            echo TanggalIndo($data_pegawai['tgl_lahir']);
                        } ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Jenis Kelamin</td>
                    <td>:
                        <?php if ($data_pegawai['gender'] == "l") {
                            echo "Laki - Laki";
                        } else {
                            echo "Wanita";
                        } ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Agama</td>
                    <td>:
                        <?php echo $data_pegawai['agama']; ?> 
                        
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Unit Kerja</td>
                    <td>:
                        <?php echo $data_pegawai['kebangsaan']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Alamat Lengkap</td>
                    <td>:
                        <?php echo $data_pegawai['alamat']; ?>
                        <br>&nbsp; RT / RW :
                        <?php echo $data_pegawai['rt']; ?> /
                        <?php echo $data_pegawai['rw']; ?>
                        <br>&nbsp; Desa ( Kelurahan ) :
                        <?php echo $data_pegawai['desa']; ?>
                        <br>&nbsp; Kecamatan :
                        <?php echo $data_pegawai['kecamatan']; ?>
                        <br>&nbsp; Kabupaten / Kotamadya :
                        <?php echo $data_pegawai['kabupaten']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">TMT Capeg</td>
                    <td>:
                        <?php if ($data_pegawai['tmt_capeg'] == "0000-00-00") {
                        } else {
                            echo TanggalIndo($data_pegawai['tmt_capeg']); 
                        } ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Jenis Kepegawaian</td>
                    </td>
                    <td>:
                        <?php echo $data_pegawai['jenis_pegawai']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Status Kepegawaian</td>
                    <td>:
                        <?php echo $data_pegawai['status_pegawai']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Digaji menurut ( PP / SK)</td>
                    <td>:
                        <?php echo $data_pegawai['digaji_menurut']; ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Gaji pokok</td>
                    <td>:
                        Rp. <?php echo number_format($data_pegawai['gaji_pokok'], 0, ".", "."); ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Besarnya Penghasilan</td>
                    <td>: Rp.
                        <?php echo number_format($data_pegawai['besarnya_penghasilan'], 0, ".", "."); ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Jabatan Struktural / Fungsional</td>
                    <td>:
                        <?php echo $data_pegawai['jabatan']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Jumlah Keluarga Tertanggung</td>
                    <td>:
                        <?php if ($data_pegawai['jumlah_keluarga'] > 0 && $data_pegawai['jumlah_keluarga'] <= 10) {
                            echo $data_pegawai['jumlah_keluarga'];
                        } elseif ($data_pegawai['jumlah_keluarga'] > 10) {
                        } ?>
                        <?php if ($data_pegawai['jumlah_keluarga'] == "0" or $data_pegawai['jumlah_keluarga'] == "") {
                        } elseif ($data_pegawai['jumlah_keluarga'] == "1") {
                            echo "(satu)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "2") {
                            echo "(dua)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "3") {
                            echo "(tiga)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "4") {
                            echo "(empat)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "5") {
                            echo "(lima)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "6") {
                            echo "(enam)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "7") {
                            echo "(tujuh)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "8") {
                            echo "(delapan)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "9") {
                            echo "(sembilan)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] == "10") {
                            echo "(sepuluh)     orang";
                        } elseif ($data_pegawai['jumlah_keluarga'] >= "1") {
                            echo "(lebih dari sepuluh)     orang";
                        } ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">SK Terakhir yang dimiliki</td>
                    <td>:
                        <?php echo $data_pegawai['sk_terakhir']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Masa kerja golongan</td>
                    <td>:
                        <?php echo $data_pegawai['masa_kerja_golongan']; ?>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight:bold;">Masa kerja keseluruhan</td>
                    <td>:
                        <?php echo $data_pegawai['masa_kerja_keseluruhan']; ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <br>
        <!-- data_pribadi -->

        <table class="table1 no-mp" width="100%">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT GOLONGAN</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222;" width="20%">Nama Golongan</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;" width="40%">Jenjang Golongan</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;" width="15%" align="center">TMT</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_golongan) && mysqli_num_rows($data_riwayat_golongan) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_golongan)) {
                echo '
                <tr>
                    <td>' . htmlspecialchars($row['nama_golongan']) . '</td>
                    <td>' . htmlspecialchars($row['keterangan']) . '</td>
                    <td align="center">' . htmlspecialchars($row['golongan_tmt']) . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>
        <table class="table1" width="100%">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT JABATAN</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222;">NAMA JABATAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;">UNIT KERJA</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;" width="15%" align="center">TAHUN</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_jabatan) && mysqli_num_rows($data_riwayat_jabatan) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_jabatan)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . htmlspecialchars($row['jabatan']) . '</td>
                    <td>' . htmlspecialchars($row['keterangan']) . '</td>
                    <td align="center">' . htmlspecialchars($row['jabatan_tmt']) . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>
        <table class="table1" width="100%">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT BERKALA</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222;">NAMA JABATAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;">TANGGAL PENETAPAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;" width="15%" align="center">TMT</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_berkala) && mysqli_num_rows($data_riwayat_berkala) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_berkala)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . htmlspecialchars($row['jabatan']) . '</td>
                    <td>' . htmlspecialchars($row['keterangan']) . '</td>
                    <td align="center">' . htmlspecialchars($row['jabatan_tmt']) . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>
        <table class="table1" width="100%">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT PENDIDIKAN</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222;">JENJANG PENDIDIKAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;">NAMA SEKOLAH / PERGURUAN TINGGI</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222;" width="15%" align="center">TAHUN LULUS</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_pendidikan) && mysqli_num_rows($data_riwayat_pendidikan) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_pendidikan)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . htmlspecialchars($row['nama_pendidikan']) . '</td>
                    <td>' . htmlspecialchars($row['keterangan']) . '</td>
                    <td align="center">' . htmlspecialchars($row['tahun_pendidikan']) . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>

        

       <table class="table1" width="100%">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT SUSUNAN KELUARGA</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="20%">HUBUNGAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="30%">NO</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="40%" align="center">NAMA KELUARGA</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_keterangan_keluarga) && mysqli_num_rows($data_riwayat_keterangan_keluarga) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_keterangan_keluarga)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . $row['keterangan'] . '</td>
                    <td>' . $row['no'] . '</td>
                    <td align="center">' . $row['nama_keluarga'] . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>

        
        <table width="100%" class="table1">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT SKP</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222">TAHUN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222">PREDIKAT</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="30%" align="center">RATING</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_dp3) && mysqli_num_rows($data_riwayat_dp3) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_dp3)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . $row['tahun'] . '</td>
                    <td>' . $row['nilai_rata_rata'] . '</td>
                    <td align="center">' . $row['keterangan'] . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                   Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>
        
        <table class="table1" width="100%">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT DIKLAT</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222">NAMA DIKLAT</td>
        <td style="font-weight:bold; border-bottom: 1px solid #222">PENYELENGGARA</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="15%" align="center">TAHUN</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_diklat_pimpinan) && mysqli_num_rows($data_riwayat_diklat_pimpinan) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_diklat_pimpinan)) {
                echo '
                <tr>
                    <td>' . $row['nama_diklat'] . '</td>
                     <td>' . $row['keterangan'] . '</td>
                    <td align="center">' . $row['tahun'] . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

<br>
<table width="100%" class="table1">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT KURSUS/PELATIHAN</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222">NAMA KURSUS / PELATIHAN</td>
        	<td style="font-weight:bold; border-bottom: 1px solid #222" align="center">PENYELENGARA</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="15%" align="center">Tahun</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_kursus) && mysqli_num_rows($data_riwayat_kursus) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_kursus)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . $row['nama_kursus'] . '</td>
                    <td align="center">' . $row['keterangan'] . '</td>
                    <td align="center">' . $row['tahun'] . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

<br>
<table width="100%" class="table1">
    <thead>
        <tr class="table-head">
            <td colspan="4" style="text-align:center; font-weight:bold;">RIWAYAT ANGKA KREDIT</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="15%">TANGGAL SK</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="25%">AK UTAMA</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="25%">AK PENUNJANG</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222" width="25%">AK TOTAL</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_angka_kredit) && mysqli_num_rows($data_riwayat_angka_kredit) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_angka_kredit)) {
                echo '
                <tr class="odd gradeX">
                    <td>' . $row['tanggal_sk'] . '</td>
                    <td>' . $row['ak_utama'] . '</td>
                    <td>' . $row['ak_penunjang'] . '</td>
                    <td>' . $row['ak_total'] . '</td>
                </tr>';
            }
        } else {
            echo '
            <tr>
                <td colspan="4" style="text-align:center; font-style:italic; color:#888;">
                    Belum Ada Data
                </td>
            </tr>';
        }
        ?>
    </tbody>
</table>

        <br>

        <table width="100%" class="table1">
    <thead>
        <tr class="table-head">
            <td colspan="3" style="text-align:center; font-weight:bold;">RIWAYAT TANDA JASA/PENGHARGAAN</td>
        </tr>
        <tr>
            <td style="font-weight:bold; border-bottom: 1px solid #222">JENIS PENGHARGAAN</td>
        <td style="font-weight:bold; border-bottom: 1px solid #222">YANG MENETAPKAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222">TAHUN</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_penghargaan) && mysqli_num_rows($data_riwayat_penghargaan) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_penghargaan)) {
                echo '
                    <tr>
                        <td>' . $row['jenis_penghargaan'] . '</td>
                         <td>' . $row['keterangan'] . '</td>
                        <td>' . $row['tahun'] . '</td>
                    </tr>';
            }
        } else {
            echo '
                <tr>
                    <td colspan="3" style="text-align:center; font-style:italic; color:#888;">
                        Belum Ada Data
                    </td>
                </tr>';
        }
        ?>
    </tbody>
</table>

        <br>



        

        


        <table class="table1">
    <thead>
        <tr class="table-head">
            <td colspan="4" style="text-align:center; font-weight:bold;">RIWAYAT HUKUMAN DISIPLIN</td>
        </tr>
        <tr class="odd bg-gray">
            <td style="font-weight:bold; border-bottom: 1px solid #222">JENIS HUKUMAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222">TANGGAL HUKUMAN</td>
            <td style="font-weight:bold; border-bottom: 1px solid #222">TANGGAL AKHIR</td>
        <td style="font-weight:bold; border-bottom: 1px solid #222">KETERANGAN</td>
        </tr>
    </thead>
    <tbody>
        <?php
        if (isset($data_riwayat_hukuman_disiplin) && mysqli_num_rows($data_riwayat_hukuman_disiplin) > 0) {
            while ($row = mysqli_fetch_array($data_riwayat_hukuman_disiplin)) {
                echo '
                    <tr>
                        <td>' . $row['jenis_hukuman'] . '</td>
                        <td>' . $row['tgl_hukuman'] . '</td>
                        <td>' . $row['tgl_akhir'] . '</td>
                        <td>' . $row['keterangan'] . '</td>
                    </tr>';
            }
        } else {
            echo '
                <tr>
                    <td colspan="4" style="text-align:center; font-style:italic; color:#888;">
                        Belum Ada Data
                    </td>
                </tr>';
        }
        ?>
    </tbody>
</table>


    </div>

</body>

</div>


</body>

</html>

<?php

$html = ob_get_clean();

$pdf->loadHtml($html);

$pdf->setPaper('A4', 'Potrait');

$pdf->render();
$pdf->stream('Surat Keterangan_' . $data_pegawai['nama'] . '.pdf', array('Attachment' => 0));
?>

<?php
function TanggalIndo($date)
{
    $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");

    $tahun = substr($date, 0, 4);
    $bulan = substr($date, 5, 2);
    $tgl = substr($date, 8, 2);

    $result = $tgl . " " . $BulanIndo[(int) $bulan - 1] . " " . $tahun;
    return ($result);
}
?>