<?php

session_start();

date_default_timezone_set('Asia/Jakarta');
include('../config/koneksi.php');

$peg = mysqli_query($koneksi, "SELECT * FROM pegawai ORDER BY id ASC");

// Menyiapkan file CSV
$filename = 'data_pegawai.csv';
$savePath = '../files/excel/' . $filename;
$file = fopen($savePath, 'w');

// Menulis header kolom
$header = array('NIP', 'NAMA', 'TEMPAT LAHIR', 'TGL LAHIR', 'GENDER', 'AGAMA', 'KEBANGSAAN', 'JUMLAH KELUARGA', 'ALAMAT', 'SK TERAKHIR', 'PANGKAT', 'TMT GOLONGAN', 'JENIS PEGAWAI', 'TMT CAPEG', 'STATUS PEGAWAI', 'JABATAN', 'DIGAJI MENURUT', 'GAJI POKOK', 'BESARNYA PENGHASILAN', 'MASA KERJA GOLONGAN', 'MASA KERJA KESELURUHAN', 'NPWP', 'RT', 'RW', 'DESA', 'KECAMATAN', 'KABUPATEN', 'WA');
fputcsv($file, $header, ';');

// Menulis data pegawai ke dalam file CSV
while ($row_data = mysqli_fetch_array($peg)) {
    $data = array(
        $row_data['nip'],
        $row_data['nama'],
        $row_data['tempat_lahir'],
        $row_data['tgl_lahir'],
        $row_data['gender'],
        $row_data['agama'],
        $row_data['kebangsaan'],
        $row_data['jumlah_keluarga'],
        $row_data['alamat'],
        $row_data['sk_terakhir'],
        $row_data['pangkat'],
        $row_data['tmt_golongan'],
        $row_data['jenis_pegawai'],
        $row_data['tmt_capeg'],
        $row_data['status_pegawai'],
        $row_data['jabatan'],
        $row_data['digaji_menurut'],
        $row_data['gaji_pokok'],
        $row_data['besarnya_penghasilan'],
        $row_data['masa_kerja_golongan'],
        $row_data['masa_kerja_keseluruhan'],
        $row_data['npwp'],
        $row_data['rt'],
        $row_data['rw'],
        $row_data['desa'],
        $row_data['kecamatan'],
        $row_data['kabupaten'],
        $row_data['wa']
    );
    fputcsv($file, $data, ';');
}

fclose($file);

// Mengirim file CSV untuk diunduh
$fileUrl = '../files/excel/' . $filename;

header('Content-Type: application/csv');
header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Length: ' . filesize($fileUrl));
readfile($fileUrl);
exit();

?>
