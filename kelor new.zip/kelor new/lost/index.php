<?php 
include('../config/koneksi.php');
$data = mysqli_query($koneksi,"SELECT * FROM profil");
$home = mysqli_fetch_array($data); 
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $home['nama'];?> | Lupa Password</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="../bootstrap/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bootstrap/bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../bootstrap/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../bootstrap/dist/css/skins/_all-skins.min.css">
  <link rel="shortcut icon" href="../logo/bm11.png">
</head>

<body style="background: linear-gradient(to right, rgba(255,215,0,0.4), rgba(0,0,0,0.7)), url('../logo/bg22.png') no-repeat center center fixed; background-size: cover; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #fff; margin: 0; padding: 0;">

<br>

<!-- Header Logo -->
<div style="max-width: 100%; margin: 0 auto;">
  <table style="width: 100%;">
    <tr>
      <td style="text-align: left; width: 30%; padding-left: 220px;">
        <img src="../logo/b.png" style="max-width: 100%; height: auto; width: 120px;">
      </td>
      <td style="text-align: center; width: 40%;">
        <img src="../logo/sikelor.png" style="max-width: 100%; height: auto; width: 350px;">
      </td>
      <td style="text-align: right; width: 30%; padding-right: 220px;">
        <img src="../logo/logo2.png" style="max-width: 100%; height: auto; width: 150px;">
      </td>
    </tr>
  </table>
</div>

<!-- Judul -->
<div style="text-align: center;">
  <h3 style="color: white; margin-top: 10px;">
    <b><?php echo $home['nama']; ?><br><?php echo $home['instansi']; ?></b>
  </h3>
  
</div>

<!-- Form Ubah Password -->

<div class="box box-info" style="max-width: 400px; margin: 20px auto;">
  <div class="box-header with-border bg-blue" style="background-color: #3c8dbc; padding: 10px 15px; border-top-left-radius: 10px; border-top-right-radius: 10px;">
    <center><h3 class="box-title" style="color: white;"><b>Ubah Password</b></h3></center>
  </div>

  <form method="post" action="../proses?valid=sistem&method=ubah_pass" onsubmit="return validasi_input(this)">
    <div class="box-body" style="background-color: rgba(255,255,255,0.95); border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; padding: 20px;">
      
      <div class="form-group">
        <label for="username" style="color: black;">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Masukkan Username" style="color: black;" required
          oninvalid="this.setCustomValidity('Masukan Username Terlebih Dahulu')"
          oninput="setCustomValidity('')" autocomplete="off">
      </div>

      <div class="form-group">
        <label for="password" style="color: black; ">Password Baru</label>
        <input type="password" name="password" class="form-control" placeholder="Masukkan Password Baru" style="color: black;" required
          oninvalid="this.setCustomValidity('Masukan Password Terlebih Dahulu')"
          oninput="setCustomValidity('')" autocomplete="off">
      </div>

      <div class="form-group text-center" style="margin-top: 20px;">
        <a href="https://sikelor.parigimoutongkab.go.id/" class="btn btn-default">Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>

    </div>
  </form>
</div>


 </div>
  <!-- /.login-box-body -->
  <div class="text-center" style="color: white; margin-top: 30px;">
  <p>
    Copyright © <?php echo $home['nama']; ?> - <?php echo $home['instansi']; ?> <br>
    <small>
      <?php 
        $a = 2020;
        $b = date('Y');
        echo ($b == $a) ? "2020" : "2023 - $b";
      ?>
    </small>
  </p>
</div>
</div>
<!-- /.login-box -->

<script src="../bootstrap/bower_components/jquery/dist/jquery.min.js"></script>
<script src="../bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<script type="text/javascript">
function validasi_input(form){
   var pola_username = /^[a-zA-Z0-9\_\-]{6,100}$/;
   if (!pola_username.test(form.username.value)){
      alert('Username minimal 6 karakter dan hanya boleh Huruf atau Angka!');
      form.username.focus();
      return false;
   }
   var mincar = 6;
   if (form.password.value.length < mincar){
      alert("Password Minimal 6 Karakter!");
      form.password.focus();
      return false;
   }
   return true;
}
</script>

</body>
</html>
