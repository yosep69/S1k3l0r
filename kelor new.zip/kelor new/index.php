<?php
session_start();
date_default_timezone_set("Asia/Makassar");

// ======================
// Whitelist controller
// ======================
$allowed_controllers = array(
    'sistem',
    'user',
    'admin',
    'koordinator',
    'pegawai',
    'riwayat',
    'pengajuan',
    'pensiun',
    'pangkat',
    'mutasi',
    'gaji',
    'tpp',
    'temuan',
    'berkas',
    'sk',
    'wa',
    'pesan',
    'kategori',
    'golongan',
    'dinkes',
    'disdik'
);


// ======================
// Ambil parameter
// PHP 5.6 compatible
// ======================
$controller = isset($_GET['controller']) ? $_GET['controller'] : 'sistem';
$method     = isset($_GET['method']) ? $_GET['method'] : 'login';


// ======================
// Validasi input
// Jangan menghapus karakter ilegal.
// Request yang mengandung karakter ilegal ditolak.
// ======================

if (!preg_match('/^[a-zA-Z0-9_]+$/', $controller)) {
    http_response_code(400);
    exit('Invalid controller.');
}

if (!preg_match('/^[a-zA-Z0-9_]+$/', $method)) {
    http_response_code(400);
    exit('Invalid method.');
}


// ======================
// Validasi controller
// ======================

if (!in_array($controller, $allowed_controllers, true)) {
    http_response_code(403);
    exit('Access denied.');
}


// ======================
// Tentukan file controller
// ======================

$controller_file = __DIR__ . DIRECTORY_SEPARATOR . 'controller'
                 . DIRECTORY_SEPARATOR . $controller . '.php';


// ======================
// Cek apakah file controller ada
// ======================

if (!is_file($controller_file)) {
    http_response_code(404);
    exit('Page not found.');
}


// ======================
// Include file controller
// ======================

require_once $controller_file;


// ======================
// Cek apakah class ada
// ======================

if (!class_exists($controller)) {
    http_response_code(500);
    exit('Application error.');
}


// ======================
// Buat objek controller
// ======================

$objek = new $controller();


// ======================
// Cek apakah method dapat dipanggil
// ======================

if (!is_callable(array($objek, $method))) {

    // fallback ke default method jika tidak ditemukan
    if (is_callable(array($objek, 'index'))) {
        $method = 'index';
    } else {
        http_response_code(404);
        exit('Page not found.');
    }
}


// ======================
// Panggil method
// ======================

$objek->$method();