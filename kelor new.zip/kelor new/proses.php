<?php
session_start();

// LANGKAH 1 :
// MENDAPATKAN NILAI valid DAN METHOD DARI LINK
// UNTUK DIGUNAKAN MENGARAHKAN KE FILE valid, CLASS DAN METHOD

if (isset($_GET['valid'])) {

    // LANGKAH 2 :
    // SIMPAN NILAI GET DI VARIABEL
    $valid = $_GET['valid'];

    // Validasi nama file/class.
    // Hanya mengizinkan huruf, angka, dan underscore.
    // Mencegah ../, ..\, slash, backslash, dan karakter path lainnya.
    if (!preg_match('/^[A-Za-z0-9_]+$/', $valid)) {
        exit('Invalid request');
    }

    // Nama class mengikuti nama valid
    $class = $valid;

    // Method wajib tersedia
    if (!isset($_GET['method']) || $_GET['method'] === '') {
        exit('Invalid method');
    }

    $method = $_GET['method'];

    // Validasi nama method.
    // Hanya mengizinkan huruf, angka, dan underscore.
    if (!preg_match('/^[A-Za-z0-9_]+$/', $method)) {
        exit('Invalid method');
    }

} else {

    // JIKA valid TIDAK ADA, MAKA DIARAHKAN KE LOGIN

    // LANGKAH 3 :
    $valid = "sistem";
    $class = "sistem";
    $method = "login";
}


// LANGKAH 4 :
// MENENTUKAN FILE valid

$validDir = __DIR__ . DIRECTORY_SEPARATOR . 'valid';
$file = $validDir . DIRECTORY_SEPARATOR . $valid . '.php';

// Pastikan file yang akan di-include benar-benar berada
// di dalam direktori valid.
$realValidDir = realpath($validDir);
$realFile = realpath($file);

if ($realValidDir === false || $realFile === false) {
    exit('Invalid request');
}

// Pastikan file berada di dalam folder valid.
$validPrefix = $realValidDir . DIRECTORY_SEPARATOR;

if (strpos($realFile, $validPrefix) !== 0) {
    exit('Invalid request');
}

// Pastikan file benar-benar file PHP yang diharapkan.
if (!is_file($realFile)) {
    exit('Invalid request');
}


// LANGKAH 5 :
// MENGGUNAKAN CLASS DI FILE valid

include_once($realFile);

if (!class_exists($class)) {
    exit('Invalid class');
}

$objek = new $class();


// LANGKAH 6 :
// MEMASTIKAN METHOD TERSEDIA

if (!method_exists($objek, $method)) {
    exit('Invalid method');
}

// Jalankan method
$objek->$method();
?>