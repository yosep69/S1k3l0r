<title><?php echo $row_data['nama']; ?> | Dokumen Kepegawaian  </title>
<?php
date_default_timezone_set('Asia/Jakarta');
$row_detail  = mysqli_fetch_array($data_detail);
?>

<!-- INI UNTUK JUDUL -->
<section class="content-header">
  <h1>
    Dokumen Kepegawaian
  </h1>
  <ol class="breadcrumb">
    <li><a href="index.php?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Dokumen Kepegawaian</li>
  </ol>
</section>
<section class="content">
  <a href="index.php?controller=pegawai&method=select" class="btn btn-md btn-success" data-toggle="tooltip" data-placement="top" title="Data Pegawai">
        <i class="fa fa-chevron-left fa-fw"></i>Back
    </a>

    <a href="index.php?controller=pegawai&method=detail&nip=<?php echo $row_detail['nip'];?>" class="btn btn-md btn-danger" data-toggle="tooltip" data-placement="top" title="Data Pegawai">
        <i class="fa fa-user fa-fw"></i>Data Diri
    </a>

    <!-- Dropdown untuk Data Keluarga -->
    <div class="btn-group">
        <button type="button" class="btn btn-md btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Data Keluarga">
            <i class="fa fa-users fa-fw"></i>Data Keluarga <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
            <li>
                <a href="index.php?controller=pegawai&method=keluarga&nip=<?php echo $row_detail['nip'];?>">
                    <i class="fa fa-street-view fa-fw"></i>Data Istri / Suami
                </a>
            </li>
            <li>
                <a href="index.php?controller=pegawai&method=anak&nip=<?php echo $row_detail['nip'];?>">
                    <i class="fa fa-venus-double fa-fw"></i>Data Anak
                </a>
            </li>
        </ul>
    </div>

    <a href="index.php?controller=pegawai&method=riwayat&nip=<?php echo $row_detail['nip'];?>" class="btn btn-md btn-info" data-toggle="tooltip" data-placement="top" title="Riwayat">
        <i class="fa fa-file-archive-o fa-fw"></i>Dokumen Kepegawaian
    </a>

    <a href="index.php?controller=pegawai&method=berkas&nip=<?php echo $row_detail['nip'];?>" class="btn btn-md btn-info" data-toggle="tooltip" data-placement="top" title="Lampiran">
        <i class="fa fa-file-archive-o fa-fw"></i>Dokumen Pendukung
    </a>


  <div class="pull-right">
    <form method="post" action="laporan/cetak_detail_riwayat.php" target="_blank">
      <input name="pencetak" type="hidden" value="<?php echo $_SESSION['nama_simpeg']; ?>"></input>
      <input name="nip_cetak" type="hidden" value="<?php echo $row_data2['nip']; ?>"></input>
      <input name="nip" type="hidden" value="<?php echo $row_detail['nip']; ?>"></input>
      <button class="btn btn-md btn-primary" name="ctk" data-toggle="tooltip" data-placement="top" title="Cetak Data Riwayat"><i class="fa fa-print fa-fw"></i>Cetak</button>
    </form>
  </div>

  <br>
  <br>
  <div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
      <!-- JUDUL TABEL -->
      <div class="panel-heading bg-aqua">
        <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Golongan
        <div class="pull-right">
          <label class="label" style="font-size: 15px;"> Pegawai : <?php echo $row_detail['nama']; ?></label>
        </div>
      </div>

      <!-- ISI UTAMA golongan -->
      <div class="panel-body table-responsive">
        <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateDataRiwayatGolongan">
          <i class="fa fa-plus"></i> Add
        </button>
        <br><br>

        <!-- TABEL -->
        <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
          <thead>
            <tr class="odd bg-gray">
              <th width="1%">No</th>
              <th width="25%"><center>Golongan/Pangkat</center></th>
              <th width="25%"><center>Keterangan</center></th>
              <th width="8%"><center>TMT</center></th>
              
              <th width="8%"><center>File SK</center></th>
              <th width="5%"><center>Aksi</center></th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1;
            if (isset($data_riwayat_golongan)) {
              while ($row = mysqli_fetch_array($data_riwayat_golongan)) {
            ?>
              <tr class="odd gradeX">
                <td><?php echo $nomor; ?></td>
                <td><?php echo $row['nama_golongan']; ?></td>
                <td><?php echo $row['keterangan']; ?></td>
                <td><?php echo $row['golongan_tmt']; ?></td>
                
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                <td>
                  <center>
                    <!-- Tombol Edit -->
                    <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditRiwayatGolongan<?php echo $row['id']; ?>">
                      <i class="fa fa-edit"></i>
                    </button>

                    <!-- Modal Edit -->
                    <div class="modal modal-success fade" id="modalEditRiwayatGolongan<?php echo $row['id']; ?>">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <center><h4 class="modal-title">Ubah Data Riwayat Golongan</h4></center>
                          </div>


                          <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_golongan" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Golongan Pangkat</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"></input>
                                        <select name="id_golongan" id="id_golongan" style="width: 100%;" class="form-control select2" required>
                                          <option value=" ">- Pilih Pangkat / Golongan -</option>
                                          <?php
                                          include("config/koneksi.php");
                                          $query_pangkat = "select * from jabatan WHERE jenis='pangkat'";
                                          $pangkat = mysqli_query($koneksi, $query_pangkat);
                                          while ($row_pangkat = mysqli_fetch_array($pangkat)) {
                                            // MENAMPILKAN OPSI Kategori
                                            $selected = ($row_pangkat[50] == $row['id_golongan']) ? "selected" : "";
                                            echo "<option value='$row_pangkat[50]' $selected>$row_pangkat[nama]</option>";
                                          }
                                          ?>
                                        </select>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Keterangan</label>
                                           
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>
										<small>contoh : CPNS</small>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Golongan TMT</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <div class="input-group">
                                          <input type="date" name="golongan_tmt" class="form-control" placeholder="Masukkan TMT" value="<?php echo $row['golongan_tmt']; ?>" required oninvalid="this.setCustomValidity('Masukan TMT Golongan')">

                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                        </div>
                      </div>
                    </div>

                    <!-- Tombol Hapus -->
                    <a href="index.php?controller=riwayat&method=delete_riwayat_golongan&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" 
                       class="btn btn-danger btn-xs" 
                       onclick="return confirm('Yakin hapus?')">
                      <i class="fa fa-trash"></i>
                    </a>
                  </center>
                </td>
              </tr>
            <?php
                $nomor++;
              }
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


 <!-- table riwayat_jabatan -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Jabatan
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?>
            </label>
          </div>
        </div>

        <!-- INI BAGIAN ISI UTAMA -->
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatJabatan">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <!-- INI BAGIAN TABEL -->
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
  <thead>
    <tr class="odd bg-gray">
      <th width="1%">No</th>
      <th width="35%">Jabatan</th>
      <th width="30%">Keterangan</th>
      <th width="15%">TMT</th>
      <th width="10%"><center>File</center></th>
      <th width="9%"><center>Aksi</center></th>
    </tr>
  </thead>
  <tbody>
    <?php
    $nomor = 1;
    if ($data_riwayat_jabatan && $data_riwayat_jabatan->num_rows > 0) {
      while ($row = $data_riwayat_jabatan->fetch_assoc()) {
    ?>
      <tr class="odd gradeX">
        <td><?php echo $nomor++; ?></td>
        <td><?php echo htmlspecialchars($row['jabatan']); ?></td>
        <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
        <td><?php echo htmlspecialchars($row['jabatan_tmt']); ?></td>
        <td>
          <center>
            <?php if (!empty($row['file_sk'])): ?>
              <a href="upload_berkas/<?php echo htmlspecialchars($row['file_sk']); ?>" target="_blank">Lihat File</a>
            <?php else: ?>
              <span class="text-muted">Tidak ada file</span>
            <?php endif; ?>
          </center>
        

                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataJabatan<?php echo $row['id']; ?>">
    <i class="fa fa-edit"></i>
  </button>

  <div class="modal modal-success fade" id="modalEditDataJabatan<?php echo $row['id']; ?>"> 
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <center>
            <h4 class="modal-title">Ubah Data Riwayat Jabatan</h4>
          </center>
        </div>

        <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_jabatan" enctype="multipart/form-data" onsubmit="return validasi();">
          <input type="hidden" name="nip" value="<?php echo htmlspecialchars($row_detail['nip']); ?>">
          <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">

          <table width="100%" class="modal-body">
            <tr>
              <td></td>
                <td><div class="modal-body"><label>Jabatan Strukural</label></div></td>
                <td><div class="modal-body">:</div></td>
                                    <td style="padding-right: 20px;">
                                        <div class="form-group">
                                            <input 
                                            type="text" 
                                            name="jabatan" 
                                            id="jabatan" 
                                            class="form-control" 
                                            style="width: 100%;" 
                                            value="<?php echo isset($row_pegawai['jabatan']) ? htmlspecialchars($row_pegawai['jabatan']) : ''; ?>" 
                                            placeholder="Masukkan Jabatan Struktural" />

                                        </div>
                                    </td>

            </tr>
            <tr>
              <td></td>
              <td><div class="modal-body"><label>TMT Jabatan</label></div></td>
              <td><div class="modal-body">:</div></td>
              <td>
                <div class="modal-body">
                  <div class="input-group">
                    <input type="date" 
                           name="jabatan_tmt" 
                           class="form-control" 
                           value="<?php echo htmlspecialchars($row['jabatan_tmt']); ?>" 
                           required>
                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                </div>
              </td>
            </tr>

            <tr>
              <td></td>
              <td><div class="modal-body"><label>Keterangan</label></div></td>
              <td><div class="modal-body">:</div></td>
              <td>
                <div class="modal-body">
                  <input type="text" 
                         name="keterangan" 
                         class="form-control" 
                         placeholder="Masukkan Keterangan" 
                         value="<?php echo htmlspecialchars($row['keterangan']); ?>" 
                         required>
                </div>
              </td>
            </tr>

            <tr>
              <td></td>
              <td><div class="modal-body"><label>Upload File (PDF/IMG)</label></div></td>
              <td><div class="modal-body">:</div></td>
              <td>
                <div class="modal-body">
                <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                <small>File Max 900Kb</small>
              </div>
                
              </td>
            </tr>

            <tr>
              <td></td>
              <td><div class="modal-body"><label>File saat ini: </label></div></td>
              <td><div class="modal-body">:</div></td>
              <td>
                <div class="modal-body">
                  <a href="upload_berkas/<?php echo htmlspecialchars($row['file_sk']); ?>" target="_blank" class="btn btn-info btn-xs" style="margin-left: 10px;">
                      <i class="fa fa-file"></i> Lihat
                    </a>
                </div>
              </td>
            </tr>
          </table>

          <div class="modal-footer">
            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
            <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
          </div>
        </form>
      </div>
    </div>
  </div>

  <a href="index.php?controller=riwayat&method=delete_riwayat_jabatan&id=<?php echo $row['id']; ?>&nip=<?php echo htmlspecialchars($row_detail['nip']); ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
    <i class="fa fa-trash"></i>
  </a>

                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>



<!-- table riwayat_berkala -->
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
      <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
      <div class="panel-heading bg-aqua">
        <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Berkala
        <div class="pull-right">
          <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?>
          </label>
        </div>
      </div>

      <!-- INI BAGIAN ISI UTAMA -->
      <div class="panel-body table-responsive">
        <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatBerkala">
          <li class="fa fa-plus"></li> Add
        </button>
        <br>
        <br>
        <!-- INI BAGIAN TABEL -->
        <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
          <thead>
            <tr class="odd bg-gray">
              <th width="1%">No</th>
              <th width="35%">Jabatan</th>
              <th width="30%">Tanggal Penetapan</th>
              <th width="15%">TMT</th>
              <th width="10%"><center>File</center></th>
              <th width="9%"><center>Aksi</center></th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1;
            if ($data_riwayat_berkala && $data_riwayat_berkala->num_rows > 0) {
              while ($row = $data_riwayat_berkala->fetch_assoc()) {
            ?>
              <tr class="odd gradeX">
                <td><?php echo $nomor++; ?></td>
                <td><?php echo htmlspecialchars($row['jabatan']); ?></td>
                <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
                <td><?php echo htmlspecialchars($row['jabatan_tmt']); ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo htmlspecialchars($row['file_sk']); ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                <td>
                  <center>
                    <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataBerkala<?php echo $row['id']; ?>">
                      <i class="fa fa-edit"></i>
                    </button>

                    <div class="modal modal-success fade" id="modalEditDataBerkala<?php echo $row['id']; ?>"> 
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                            <center>
                              <h4 class="modal-title">Ubah Data Riwayat Berkala</h4>
                            </center>
                          </div>

                          <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_berkala" enctype="multipart/form-data" onsubmit="return validasi();">
                            <input type="hidden" name="nip" value="<?php echo htmlspecialchars($row_detail['nip']); ?>">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">

                            <table width="100%" class="modal-body">
                              <tr>
                                <td></td>
                                <td><div class="modal-body"><label>Jabatan</label></div></td>
                                <td><div class="modal-body">:</div></td>
                                <td style="padding-right: 20px;">
                                  <div class="form-group">
                                    <input 
                                      type="text" 
                                      name="jabatan" 
                                      id="jabatan" 
                                      class="form-control" 
                                      style="width: 100%;" 
                                      value="<?php echo htmlspecialchars($row['jabatan']); ?>" 
                                      placeholder="Masukkan Jabatan" />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td></td>
                                <td><div class="modal-body"><label>TMT Jabatan</label></div></td>
                                <td><div class="modal-body">:</div></td>
                                <td>
                                  <div class="modal-body">
                                    <div class="input-group">
                                      <input type="date" 
                                             name="jabatan_tmt" 
                                             class="form-control" 
                                             value="<?php echo htmlspecialchars($row['jabatan_tmt']); ?>" 
                                             required>
                                      <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td></td>
                                <td><div class="modal-body"><label>Keterangan</label></div></td>
                                <td><div class="modal-body">:</div></td>
                                <td>
                                  <div class="modal-body">
                                    <input type="text" 
                                           name="keterangan" 
                                           class="form-control" 
                                           placeholder="Masukkan Keterangan" 
                                           value="<?php echo htmlspecialchars($row['keterangan']); ?>" 
                                           required>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td></td>
                                <td><div class="modal-body"><label>Upload File (PDF/IMG)</label></div></td>
                                <td><div class="modal-body">:</div></td>
                                <td>
                                  <div class="modal-body">
                                    <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                                    <small>File Max 900Kb</small>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td></td>
                                <td><div class="modal-body"><label>File saat ini: </label></div></td>
                                <td><div class="modal-body">:</div></td>
                                <td>
                                  <div class="modal-body">
                                    <a href="upload_berkas/<?php echo htmlspecialchars($row['file_sk']); ?>" target="_blank" class="btn btn-info btn-xs" style="margin-left: 10px;">
                                      <i class="fa fa-file"></i> Lihat
                                    </a>
                                  </div>
                                </td>
                              </tr>
                            </table>

                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                              <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <a href="index.php?controller=riwayat&method=delete_riwayat_berkala&id=<?php echo $row['id']; ?>&nip=<?php echo htmlspecialchars($row_detail['nip']); ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                      <i class="fa fa-trash"></i>
                    </a>
                  </center>
                </td>
              </tr>
            <?php
                }
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- modal_create_data_riwayat_berkala -->
<div class="modal modal-primary fade" id="modalCreateRiwayatBerkala">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Berkala</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_berkala" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr> 
            <td></td>
            <td><div class="modal-body"><label>Jabatan</label></div></td>
            <td><div class="modal-body">:</div></td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                <input type="text" name="jabatan" class="form-control" placeholder="Masukkan nama jabatan" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>TMT Jabatan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">:</div>
            </td>
            <td>
              <div class="modal-body">
                <input type="date" name="jabatan_tmt" class="form-control" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">:</div>
            </td>
            <td>
              <div class="modal-body">
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Upload File</label>
              </div>
            </td>
            <td>
              <div class="modal-body">:</div>
            </td>
            <td>
              <div class="modal-body">
                <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                <small>File Max 900Kb</small>
              </div>
            </td>
          </tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>

 
  

  <!-- table riwayat_diklat_pimpinan -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Diklat Pimpinan
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatDiklatPimpinan">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="15%">
                  Nama Diklat
                </th>
                 <th width="35%">
                  Penyelenggara
                </th>
                <th width="8%">
                  Tahun
                </th>
                <th width="8%">
                  <center>File </center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_diklat_pimpinan)) {
                while ($row = mysqli_fetch_array($data_riwayat_diklat_pimpinan)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['nama_diklat']; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                    <td><?php echo $row['tahun']; ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataDiklatPimpinan<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataDiklatPimpinan<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <center>
                                  <h4 class="modal-title">Ubah Data Diklat Pimpinan</h4>
                                </center>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_diklat_pimpinan" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Nama Diklat</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="nama_diklat" class="form-control" placeholder="Masukkan Nama Diklat" value="<?php echo $row['nama_diklat']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tahun</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="text" name="tahun" class="form-control" placeholder="Masukkan Tahun" value="<?php echo $row['tahun']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Penyelenggara</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                      
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>


                        <a href="index.php?controller=riwayat&method=delete_riwayat_diklat_pimpinan&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


  <!-- table riwayat_angka_kredit -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Angka Kredit
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatAngkaKredit">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="8%">
                  Tanggal SK
                </th>
                <th width="15%">
                  AK Utama
                </th>
                <th width="15%">
                  AK Penunjang
                </th>

                <th width="15%">
                  AK Total
                </th>
                <th width="8%"><center>File </center></th>

                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_angka_kredit)) {
                while ($row = mysqli_fetch_array($data_riwayat_angka_kredit)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['tanggal_sk']; ?></td>
                    <td><?php echo $row['ak_utama']; ?></td>
                    <td><?php echo $row['ak_penunjang']; ?></td>
                    <td><?php echo $row['ak_total']; ?></td>
                    <td>
  <center>
    <?php if (!empty($row['file_sk'])): ?>
      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
    <?php else: ?>
      <span class="text-muted">Tidak ada file</span>
    <?php endif; ?>
  </center>
</td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataAngkaKredit<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataAngkaKredit<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <center>
                                  <h4 class="modal-title">Ubah Data Angka Kredit</h4>
                                </center>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_angka_kredit" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tanggal SK</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="date" name="tanggal_sk" class="form-control" placeholder="Masukkan Tanggal SK" value="<?php echo $row['tanggal_sk']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>AK Utama</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="text" 
             name="ak_utama" 
             class="form-control" 
             placeholder="Masukkan AK Utama"
             value="<?php echo htmlspecialchars($row['ak_utama']); ?>" 
             pattern="[A-Za-z0-9, ]+" 
             title="Hanya huruf, angka, spasi, dan koma"
             required>
    </div>
  </td>
</tr>

<tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>AK Penunjang</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="text" 
             name="ak_penunjang" 
             class="form-control" 
             placeholder="Masukkan AK Penunjang"
             value="<?php echo htmlspecialchars($row['ak_penunjang']); ?>" 
             pattern="[A-Za-z0-9, ]+" 
             title="Hanya huruf, angka, spasi, dan koma"
             required>
    </div>
  </td>
</tr>

<tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>AK Total</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="text" 
             name="ak_total" 
             class="form-control" 
             placeholder="Masukkan AK Total"
             value="<?php echo htmlspecialchars($row['ak_total']); ?>" 
             pattern="[A-Za-z0-9, ]+" 
             title="Hanya huruf, angka, spasi, dan koma"
             required>
    </div>
  </td>
</tr>

                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        <small>File Max 900kb</small>
                                      </div>
                                    </td>
                                  </tr>

                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>


                        <a href="index.php?controller=riwayat&method=delete_riwayat_angka_kredit&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- table riwayat_pendidikan -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Pendidikan
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatPendidikan">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="25%">
                  Jenjang Pendidikan
                </th>
                <th width="25%">
                  Nama Sekolah / Perguruan Tinggi
                </th>
                <th width="8%">
                  Tahun Lulus
                </th>
                <th width="8%">
                  <center>File </center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_pendidikan)) {
                while ($row = mysqli_fetch_array($data_riwayat_pendidikan)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['nama_pendidikan']; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                    <td><?php echo $row['tahun_pendidikan']; ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataPendidikan<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataPendidikan<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <center>
                                  <h4 class="modal-title">Ubah Data Pendidikan</h4>
                                </center>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_pendidikan" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Jenjang Pendidikan</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="nama_pendidikan" class="form-control" placeholder="Masukkan Nama Pendidikan" value="<?php echo $row['nama_pendidikan']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tahun Lulus</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="text" name="tahun_pendidikan" class="form-control" placeholder="Masukkan Tahun" value="<?php echo $row['tahun_pendidikan']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Nama Sekolah</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>

                        <a href="index.php?controller=riwayat&method=delete_riwayat_pendidikan&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- table riwayat_keterangan_keluarga -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Daftar Susunan Keluarga
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatKeteranganKeluarga">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="10%"> Hubungan</th>
                <th width="10%">Nomor</th>
                <th width="35%">Nama Keluarga</th>
                <th width="8%">
                  <center>File</center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_keterangan_keluarga)) {
                while ($row = mysqli_fetch_array($data_riwayat_keterangan_keluarga)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                    <td><?php echo $row['no']; ?></td>
                    <td><?php echo $row['nama_keluarga']; ?></td>
                    <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataKeluarga<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataKeluarga<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <center>
                                  <h4 class="modal-title">Ubah Daftar Keluarga</h4>
                                </center>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_keterangan_keluarga" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Hubungan</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>No</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="text" name="no" class="form-control" placeholder="Masukkan No" value="<?php echo $row['no']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Nama Keluarga</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="text" name="nama_keluarga" class="form-control" placeholder="Masukkan Nama Keluarga" value="<?php echo $row['nama_keluarga']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>

                        <a href="index.php?controller=riwayat&method=delete_riwayat_keterangan_keluarga&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- table riwayat_kursus -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Kursus / Pelatihan
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatKursus">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="25%">Nama Kursus/Pelatihan</th>
                <th width="25%">
                  Penyelenggara
                </th>
                <th width="8%">Tahun</th>
                <th width="8%">
                  <center>File </center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_kursus)) {
                while ($row = mysqli_fetch_array($data_riwayat_kursus)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['nama_kursus']; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                    <td><?php echo $row['tahun']; ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataKursus<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataKursus<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <center>
                                  <h4 class="modal-title">Ubah Data Kursus/Pelatihan</h4>
                                </center>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_kursus" enctype="multipart/form-data" onsubmit="return validasi();">
                                <div class="modal-body">
                                  <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                  <table width="100%">
                                    <tr>
                                      <td></td>
                                      <td>
                                        <div class="modal-body">
                                          <label>Nama Kursus/Pelatihan</label>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          :
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          <input type="text" name="nama_kursus" class="form-control" placeholder="Masukkan Nama Kursus" value="<?php echo $row['nama_kursus']; ?>" required>
                                        </div>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td></td>
                                      <td>
                                        <div class="modal-body">
                                          <label>Tahun</label>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          :
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" value="<?php echo $row['tahun']; ?>" min="1900" max="2099" required>
                                        </div>
                                      </td>
                                    </tr>
                                    <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Keterangan</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                  </table>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>


                        <a href="index.php?controller=riwayat&method=delete_riwayat_kursus&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- table riwayat_penghargaan -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Penghargaan
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatPenghargaan">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="25%">
                  Jenis Penghargaan</th>
                  <th width="25%">
                  Yang menetapkan
                </th>
                <th width="8%">
                  Tahun</th>
                <th width="8%">
                  <center>File </center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_penghargaan)) {
                while ($row = mysqli_fetch_array($data_riwayat_penghargaan)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['jenis_penghargaan']; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                    <td><?php echo $row['tahun']; ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataPenghargaan<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataPenghargaan<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Ubah Data Penghargaan</h4>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_penghargaan" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Jenis Penghargaan:</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="jenis_penghargaan" class="form-control" placeholder="Masukkan Jenis Penghargaan" value="<?php echo $row['jenis_penghargaan']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tahun:</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" value="<?php echo $row['tahun']; ?>" min="1900" max="2099" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Keterangan</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>


                        <a href="index.php?controller=riwayat&method=delete_riwayat_penghargaan&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat SKP
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatDP3">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="8%">Tahun</th>
                <th width="25%">Predikat</th>
                <th width="25%">Keterangan</th>
                <th width="8%">
                  <center>File </center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_dp3)) {
                while ($row = mysqli_fetch_array($data_riwayat_dp3)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['tahun']; ?></td>
                    <td><?php echo $row['nilai_rata_rata']; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataDP3<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataDP3<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Ubah Data SKP</h4>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_dp3" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tahun</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" value="<?php echo $row['tahun']; ?>" min="1900" max="2099" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td>
                                      <div class="modal-body">
                                        <label>Predikat</label>
                                       
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="text" name="nilai_rata_rata" class="form-control" placeholder="Masukkan Predikat" value="<?php echo $row['nilai_rata_rata']; ?>" required>
                                      <small>Contoh : Baik</small>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    
                                    <td>
                                      <div class="modal-body">
                                        <label>Keterangan</label>
                                       
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>
                                      <small>Contoh : Sesuai Ekspektasi</small>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                        
                                        <small>File Max 2mb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>


                        <a href="index.php?controller=riwayat&method=delete_riwayat_dp3&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- table riwayat_hukuman_disiplin -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading bg-aqua">
          <i class="fa fa-file-archive-o fa-fw"></i> Data Riwayat Hukuman Disiplin
          <div class="pull-right">
            <label class="label" style="font-size: 15px;"> Pegawai: <?php echo $row_detail['nama']; ?></label>
          </div>
        </div>
        <div class="panel-body table-responsive">
          <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#modalCreateRiwayatHukumanDisiplin">
            <li class="fa fa-plus"></li> Add
          </button>
          <br>
          <br>
          <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
            <thead>
              <tr class="odd bg-gray">
                <th width="1%">No</th>
                <th width="25%">Jenis Hukuman</th>
                <th width="8%">Tanggal Hukuman</th>
                <th width="8%">Tanggal Akhir</th>
                <th width="25%">
                  Keterangan
                </th>
                <th width="8%">
                  <center>File </center>
                </th>
                <th width="5%">
                  <center>Aksi</center>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $nomor = 1;
              if (isset($data_riwayat_hukuman_disiplin)) {
                while ($row = mysqli_fetch_array($data_riwayat_hukuman_disiplin)) {
              ?>
                  <tr class="odd gradeX">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $row['jenis_hukuman']; ?></td>
                    <td><?php echo $row['tgl_hukuman']; ?></td>
                    <td><?php echo $row['tgl_akhir']; ?></td>
                    <td><?php echo $row['keterangan']; ?></td>
                <td>
                  <center>
                    <?php if (!empty($row['file_sk'])): ?>
                      <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat File</a>
                    <?php else: ?>
                      <span class="text-muted">Tidak ada file</span>
                    <?php endif; ?>
                  </center>
                </td>
                    <td>
                      <center>
                        <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalEditDataHukuman<?php echo $row['id']; ?>">
                          <li class="fa fa-edit"></li>
                        </button>
                        <div class="modal modal-success fade" id="modalEditDataHukuman<?php echo $row['id']; ?>">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Ubah Data Hukuman Disiplin</h4>
                              </div>
                              <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=update_riwayat_hukuman" enctype="multipart/form-data" onsubmit="return validasi();">
                                <table width="100%" class="modal-body">
                                  <tr>
                                    <td>
                                      <div class="modal-body">
                                        <label>Jenis Hukuman</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="text" name="jenis_hukuman" class="form-control" placeholder="Masukkan Jenis Hukuman" value="<?php echo $row['jenis_hukuman']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tanggal Hukuman</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="date" name="tgl_hukuman" class="form-control" placeholder="Masukkan Tanggal Hukuman" value="<?php echo $row['tgl_hukuman']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td>
                                      <div class="modal-body">
                                        <label>Tanggal Akhir</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="date" name="tgl_akhir" class="form-control" placeholder="Masukkan Tanggal Akhir" value="<?php echo $row['tgl_akhir']; ?>" required>
                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Keterangan</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        :
                                      </div>
                                    </td>

                                    <td>
                                      <div class="modal-body">
                                        <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" value="<?php echo $row['keterangan']; ?>" required>

                                      </div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td>
                                      <div class="modal-body">
                                        <label>Upload File (PDF/IMG)</label>
                                      </div>
                                    </td>
                                    <td>
                                      <div class="modal-body">:</div>
                                    </td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png" required>
                                      
                                        <small>File Max 900Kb</small>
                                      </div>
                                    </td>
                                  </tr>
                                </table>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>


                        <a href="index.php?controller=riwayat&method=delete_riwayat_hukuman&id=<?php echo $row['id']; ?>&nip=<?php echo $row_detail['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')">
                          <i class="fa fa-trash"></i>
                        </a>
                      </center>
                    </td>
                  </tr>
              <?php
                  $nomor++;
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


  </div>
</section>

<!--Modal Untuk Tambah Data Riwayat Golongan-->
<div class="modal modal-primary fade" id="modalCreateDataRiwayatGolongan">

  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Golongan</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_golongan" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Golongan Pangkat</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>

            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <select name="id_golongan" id="id_golongan" style="width: 100%;" class="form-control select2" required>
                  <option value=" ">- Pilih Pangkat / Golongan -</option>
                  <?php
                  include("config/koneksi.php");
                  $query_pangkat = "select * from jabatan WHERE jenis='pangkat'";
                  $pangkat = mysqli_query($koneksi, $query_pangkat);
                  while ($row_pangkat = mysqli_fetch_array($pangkat)) {
                    // MENAMPILKAN OPSI Kategori
                    echo "<option value='$row_pangkat[50]'>$row_pangkat[nama]</option>";
                  }
                  ?>
                </select>

              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Golongan TMT</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="date" name="golongan_tmt" class="form-control" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
               <small>contoh : CPNS</small>
              </div>
            </td>
          </tr>

          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label><br>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900Kb</small>
    </div>
  </td>
</tr>

        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>

    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- Modal Untuk Tambah Data Riwayat Golongan -->

<!-- modal_create_data_riwayat_jabatan -->
<div class="modal modal-primary fade" id="modalCreateRiwayatJabatan">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Jabatan</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_jabatan" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr> 
            <td></td>
            <td><div class="modal-body"><label>Jabatan</label></div></td>
            <td><div class="modal-body">:</div></td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>">
                <input type="text" name="jabatan" class="form-control" placeholder="Masukkan nama jabatan" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>TMT Jabatan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">:</div>
            </td>
            <td>
              <div class="modal-body">
                <input type="date" name="jabatan_tmt" class="form-control" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">:</div>
            </td>
            <td>
              <div class="modal-body">
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Upload File</label>
              </div>
            </td>
            <td>
              <div class="modal-body">:</div>
            </td>
            <td>
              <div class="modal-body">
                <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                <?php if (!empty($row['file_sk'])): ?>
                  <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
                <?php endif; ?>
                <small>File Max 900Kb</small>
              </div>
            </td>
          </tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>





<!-- modal_create_data_riwayat_diklat -->

<!-- modal_create_data_riwayat_diklat_pimpinan -->
<div class="modal modal-primary fade" id="modalCreateRiwayatDiklatPimpinan">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Diklat Pimpinan</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_diklat_pimpinan" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Nama Diklat Pimpinan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="nama_diklat" class="form-control" placeholder="Masukkan Nama Diklat Pimpinan" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tahun</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900Kb</small>
    </div>
  </td>
</tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- modal_create_data_riwayat_diklat_pimpinan -->

<!-- modal_create_riwayat_angka_kredit -->
<div class="modal modal-primary fade" id="modalCreateRiwayatAngkaKredit">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Angka Kredit</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_angka_kredit" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">

          <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tanggal SK</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="date" name="tanggal_sk" class="form-control" required>
              </div>
            </td>
          </tr>

          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>AK Utama</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="text" name="ak_utama" class="form-control" placeholder="ak_utama" 
             pattern="[A-Za-z0-9, ]+" title="Hanya huruf, angka, spasi, dan koma" required>
    </div>
  </td>
</tr>

<tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>AK Penunjang</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="text" name="ak_penunjang" class="form-control" placeholder="ak_penunjang" 
             pattern="[A-Za-z0-9, ]+" title="Hanya huruf, angka, spasi, dan koma" required>
    </div>
  </td>
</tr>

<tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>AK Total</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="text" name="ak_total" class="form-control" placeholder="ak_total" 
             pattern="[A-Za-z0-9, ]+" title="Hanya huruf, angka, spasi, dan koma" required>
    </div>
  </td>
</tr>
<tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900Kb</small>
    </div>
  </td>
</tr>



        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- modal_create_riwayat_angka_kredit -->

<!-- modal_create_riwayat_pendidikan -->
<div class="modal modal-primary fade" id="modalCreateRiwayatPendidikan">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Pendidikan</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_pendidikan" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Jenjang Pendidikan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="nama_pendidikan" class="form-control" placeholder="Masukkan Jenjang Pendidikan" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tahun Lulus</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="number" name="tahun_pendidikan" class="form-control" placeholder="Masukkan Tahun Pendidikan" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Nama Sekolah</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900Kb</small>
    </div>
  </td>
</tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- modal_create_riwayat_pendidikan -->

<!-- modal_create_riwayat_keterangan_keluarga -->
<div class="modal modal-primary fade" id="modalCreateRiwayatKeteranganKeluarga">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Daftar Susunan Keluarga</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_keterangan_keluarga" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Hubungan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Nomor</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="text" name="no" class="form-control" placeholder="Masukkan No" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Nama Keluarga</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="text" name="nama_keluarga" class="form-control" placeholder="Masukkan Nama Keluarga" required>
              </div>
            </td>
          </tr>
          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>Max file 900kb</small>
    </div>
  </td>
</tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- modal_create_riwayat_keterangan_keluarga -->

<!-- modal_create_riwayat_kursus -->
<div class="modal modal-primary fade" id="modalCreateRiwayatKursus">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Kursus / Pelatihan</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_kursus" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Nama Kursus / Pelatihan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="nama_kursus" class="form-control" placeholder="Masukkan Nama Kursus" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tahun</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- modal_create_riwayat_kursus -->

<!-- modal_create_riwayat_penghargaan -->
<div class="modal modal-primary fade" id="modalCreateRiwayatPenghargaan">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Penghargaan</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_penghargaan" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Jenis Penghargaan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="jenis_penghargaan" class="form-control" placeholder="Masukkan Jenis Penghargaan" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tahun</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900kb</small>
    </div>
  </td>
</tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- modal_create_riwayat_penghargaan -->

<!-- modal_create_riwayat_dp3 -->
<div class="modal modal-primary fade" id="modalCreateRiwayatDP3">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat SKP</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_dp3" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tahun</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="number" name="tahun" class="form-control" placeholder="Masukkan Tahun" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Predikat</label>
               
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="text" name="nilai_rata_rata" class="form-control" placeholder="Masukkan Predikat" required>
              <small>Contoh : Baik</small>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
               
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <textarea name="keterangan" class="form-control" rows="3" placeholder="Masukkan Keterangan"></textarea>
              <small>Contoh : Sesuai Eksektasi</small>
              </div>
            </td>
          </tr>
          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900kb</small>
    </div>
  </td>
</tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>
<!--modal_create_riwayat_dp3 -->
<!-- modal_create_riwayat_hukuman_disiplin -->
<div class="modal modal-primary fade" id="modalCreateRiwayatHukumanDisiplin">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <center>
          <h4 class="modal-title">Tambah Data Riwayat Hukuman Disiplin</h4>
        </center>
      </div>
      <form role="form" method="POST" name="kategori" action="index.php?controller=riwayat&method=insert_riwayat_hukuman_disiplin" enctype="multipart/form-data" onsubmit="return validasi();">
        <table width="100%" class="modal-body">
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Jenis Hukuman</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="jenis_hukuman" class="form-control" placeholder="Masukkan Jenis Hukuman" required>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tanggal Hukuman</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <div class="input-group">
                  <input type="date" name="tgl_hukuman" class="form-control" placeholder="Masukkan Tanggal Hukuman" required>
                  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Tanggal Akhir Hukuman</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <div class="input-group">
                  <input type="date" name="tgl_akhir" class="form-control" placeholder="Masukkan Tanggal Akhir Hukuman" required>
                  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <div class="modal-body">
                <label>Keterangan</label>
              </div>
            </td>
            <td>
              <div class="modal-body">
                :
              </div>
            </td>
            <td>
              <div class="modal-body">
                <input type="hidden" name="nip" value="<?php echo $row_detail['nip']; ?>"></input>
                <input type="text" name="keterangan" class="form-control" placeholder="Masukkan Keterangan" required>
              </div>
            </td>
          </tr>

          <tr>
  <td></td>
  <td>
    <div class="modal-body">
      <label>Upload File</label>
    </div>
  </td>
  <td>
    <div class="modal-body">:</div>
  </td>
  <td>
    <div class="modal-body">
      <input type="file" name="file_sk" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
      <?php if (!empty($row['file_sk'])): ?>
        <small>File saat ini: <a href="upload_berkas/<?php echo $row['file_sk']; ?>" target="_blank">Lihat</a></small>
      <?php endif; ?>
      <small>File Max 900kb</small>
    </div>
  </td>
</tr>
        </table>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
          <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
        </div>
      </form>
    </div>
  </div>
</div>

<!-- modal_create_riwayat_hukuman_disiplin -->



<!-- /.modal -->
<script type="text/javascript">
  function angka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
</script>