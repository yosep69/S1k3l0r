<title><?php echo $row_data['nama']; ?> | Pegawai</title>
<!-- INI UNTUK JUDUL -->
<section class="content-header">
    <h1>
        Data Pegawai
    </h1>
    <ol class="breadcrumb">
        <li><a href="index.php?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Data Pegawai</li>
    </ol>
</section>
<section class="content">
    <?php
    if ($_SESSION['level_simpeg'] == 'superadmin') { ?>
        <a href="index.php?controller=pegawai&method=insert" class="btn btn-md btn-info" data-toggle="tooltip" data-placement="top" title="Tambah Data"><i class="fa fa-plus fa-fw"></i>Tambah Data</a>
        <div class="btn-group pull-right">

            <!--<a href="laporan/cetak_pegawai.php" target="_blank" class="btn btn-md btn-primary" data-toggle="tooltip" data-placement="top" title="Cetak"><i class="fa fa-print"></i></a>-->
            <a href="laporan/export_pegawai.php" target="_blank" class="btn btn-md btn-success" data-toggle="tooltip" data-placement="top" title="Cetak"><i class="fa fa-table"></i> Export Excel</a>
            <!--<a href="laporan/export_pegawai_csv.php" target="_blank" class="btn btn-md btn-success" data-toggle="tooltip" data-placement="top" title="Cetak"><i class="fa fa-table"></i> Export CSV</a>-->
            <!--<a data-toggle="modal" data-target="#modal-import" class="btn btn-md btn-success" data-toggle="tooltip" data-placement="top" title="Cetak"><i class="fa fa-table"></i> Import Pegawai</a>-->
        </div>

        <br>
        <br>
    <?php }elseif ($_SESSION['level_simpeg'] == "koordinator"){
        ?>
            <a href="index.php?controller=pegawai&method=insert" class="btn btn-md btn-info" data-toggle="tooltip" data-placement="top" title="Tambah Data"><i class="fa fa-plus fa-fw"></i>Tambah Data</a>

            <br>
        <br>
        <?php
    } ?>
    <!-- INI UNTUK ISI -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
                <div class="panel-heading bg-aqua">
                    <i class="fa fa-users fa-fw"></i> Data Pegawai
                </div>

                <!-- INI BAGIAN ISI UTAMA -->
                <div class="panel-body table-responsive">
                    <!-- INI BAGIAN TABEL -->
                    <table width="100%" id="example1"id="tabel" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr class="odd bg-gray">
                                <th width="5%">No</th>
                                <th>
                                    <center>Nip</center>
                                </th>
                                <th>
                                    <center>Nama Pegawai</center>
                                </th>
                                <th>
                                    <center>Jabatan</center>
                                </th>
                                <?php
                                if ($_SESSION['level_simpeg'] == "user") { ?>
                                    <th>
                                        <center>Pangkat / Golongan</center>
                                    </th>
                                    <th>
                                        <center>TMT Pangkat / Golongan</center>
                                    </th>
                                <?php } ?>
                                <th>
                                    <center>Instansi</center>
                                </th>
                                <?php
                                if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == 'superadmin') { ?>
                                    <th>
                                        <center>Agama</center>
                                    </th>
                                <?php } ?>
                                <?php
                                if ($_SESSION['level_simpeg'] == "user" ||$_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == 'superadmin') { ?>
                                    <th>
                                        <center>Aksi</center>
                                    </th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <!-- INI UNTUK MENERIMA DATA DARI CONTROLLER -->
                        <tbody>
                            <?php
                            // SET NOMOR URUT DATA
                            $nomor          =   1;

                            // CEK DATA YANG DITERIMA
                            if (isset($data_pegawai)) {
                                while ($row_pegawai  = mysqli_fetch_array($data_pegawai)) {
                            ?>

                                    <tr class="odd gradeX">
                                        <td align="center"><?php echo $nomor; ?></td>
                                        <td><?php echo $row_pegawai['nip']; ?></td>
                                        <td><?php echo $row_pegawai['nama']; ?></td>
                                        <td><?php echo $row_pegawai['jabatan']; ?></td>

                                        <?php
                                        if ($_SESSION['level_simpeg'] == "user") { ?>
                                            <td><?php echo $row_pegawai['pangkat']; ?></td>
                                            <td align="center"><?php echo TanggalIndo($row_pegawai['tmt_golongan']); ?></td>
                                        <?php } ?>

                                        <td><?php echo $row_pegawai['kebangsaan']; ?></td>

                                        <?php
                                        if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == 'superadmin') { ?>
                                            <td><?php echo $row_pegawai['agama']; ?></td>
                                        <?php } ?>

                                        <?php
                                        if ($_SESSION['level_simpeg'] == "user" ||$_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == 'superadmin') { ?>
                                            <td>
                                                <center>
                                                    <a href="index.php?controller=pegawai&method=detail&nip=<?php echo $row_pegawai['nip']; ?>" class="btn btn-primary btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Detail"> <i class="fa fa-info fa-fw"></i> </a>

                                                    <!--<a href="index.php?controller=pegawai&method=delete&nip=<?php echo $row_pegawai['nip']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin ingin menghapus data NIP : <?php echo $row_pegawai['nip']; ?> ?')"> <i class="fa fa-trash fa-fw"></i> </a>-->
                                                </center>
                                            </td>
                                        <?php } ?>
                                    </tr>

                            <?php
                                    // INCREMENT NOMOR URUT
                                    $nomor++;
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- /.modal -->

<div class="modal fade" id="modal-import">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Import Data Pegawai</h4>
            </div>
            <form method="POST" action="laporan/import_pegawai.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                            <th colspan="2">Keterangan :</th>
                        </thead>
                        <tbody>
                            <tr>

                                <td colspan="2">Untuk format import tersedia <b>file CSV, XLSX, XLS</b></td>
                            </tr>
                            <tr>

                                <td colspan="2">Download Terlebih Dahulu Template Berikut ini
                            <tr>
                                <td colspan="2">
                                    <div class="btn-group">
                                        <a class="btn btn-primary" href="files/template/template.xlsx">Download template .XLSX</a>
                                        <!-- <a class="btn btn-primary" href="files/template/template.csv">Download template .CSV</a> -->
                                    </div>
                                </td>
                            </tr>
                            </td>
                            <td colspan="2">Tanda <b>*</b> Berarti kolom wajib di isi</td>

                            </tr>
                            <tr>
                                <td>Jika data belum tersedia, biarkan kosong atau isi dengan <b>-</b></td>
                            </tr>

                        </tbody>
                    </table>

                    <label for="file">Upload file import pegawai :</label>
                    <input type="file" class="form-control" name="file" id="file" accept=".csv, .xlsx, .xls" required>
                </div>
                <div class="modal-footer">

                    <button type="submit" class="btn btn-primary">IMPORT</button>


                </div>
            </form>
        </div>
    </div>
</div>

<script src="bootstrap/bower_components/jquery/dist/jquery.min.js"></script>
<script src="bootstrap/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script>
  $(function () {
    $('#example1').DataTable(); // Ganti ID sesuai dengan tabel kamu
  })
</script>

<script type="text/javascript">
    function angka(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
</script>