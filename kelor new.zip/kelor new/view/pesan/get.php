<?php
 
date_default_timezone_set('Asia/Jakarta');

if (!empty($_SESSION['kontak'])) {
    $penerima = $this->message->getPenerima($_SESSION['kontak']);
    $row_penerima = mysqli_fetch_array($penerima);
} else {
    $row_penerima = null;
}

$username_sender = $getUser;

?>

<title>Pesan</title>
<section class="content-header">
    <h1>
        Pesan
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pesan</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-4">

            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Kontak</h3>
                </div>
                <div class="box-body">

                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="contact-select">Kontak:</label>
                            <select name="kontak" id="kontak" class="form-control select2">
                                <option value=" ">- Pilih Kontak -</option>
                                <?php

                                $getUser = $_SESSION['username_simpeg'];
                                $query_user = "SELECT * FROM user WHERE status='Aktif' AND username!='$getUser'";
                                $user = mysqli_query($koneksi, $query_user);
                                while ($row_user = mysqli_fetch_array($user)) {
                                    // MENAMPILKAN OPSI Kategori
                                    echo "<option value='$row_user[username]'>$row_user[nama]</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <button class="btn btn-primary" type="submit">Pilih kontak</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <?php if (!empty($row_penerima)) : ?>
                        <h3 class="box-title">Chat : <?php echo $row_penerima['nama']; ?></h3>
                    <?php else : ?>
                        <h3 class="box-title">Chat</h3>
                    <?php endif; ?>
                </div>
                <?php if (!empty($row_penerima)) : ?>
                    <div class="box-body">
                        <!-- Chat Messages -->
                        <div class="direct-chat-messages" id="chat-messages">
                            <?php foreach ($messages as $message) : ?>
                                <div class="direct-chat-msg<?php echo ($message['sender'] == $getUser) ? ' right' : ''; ?>">
                                    <div class="direct-chat-info clearfix">
                                        <?php if ($message['sender'] == $getUser) : ?>
                                            <span class="direct-chat-name pull-right">Saya</span>
                                            <span class="direct-chat-timestamp pull-left"><?php echo $message['sent_at']; ?></span>
                                        <?php else : ?>
                                            <span class="direct-chat-name pull-left"><?php echo $message['sender']; ?></span>
                                            <span class="direct-chat-timestamp pull-right"><?php echo $message['sent_at']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="direct-chat-text">
                                        <?php echo $message['message_content']; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <script>
                            // Scroll to bottom of chat messages
                            var chatMessages = document.getElementById('chat-messages');
                            chatMessages.scrollTop = chatMessages.scrollHeight;
                        </script>
                    </div>

                    <div class="box-footer">
                        <form action="index.php?controller=pesan&method=send_message" method="post">
                            <div class="input-group">
                                <input type="hidden" name="receiver" id="receiver" value="<?php echo $row_penerima['username']; ?>">
                                <?php if (!empty($row_penerima)) : ?>
                                    <input type="text" name="messageContent" placeholder="Type message..." class="form-control">
                                    <span class="input-group-btn">
                                        <button type="submit" class="btn btn-primary">Send</button>
                                    </span>
                                <?php else : ?>
                                    <input type="text" name="messageContent" placeholder="Select a contact to start a chat..." class="form-control" disabled>
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-primary" disabled>Send</button>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>


</section>