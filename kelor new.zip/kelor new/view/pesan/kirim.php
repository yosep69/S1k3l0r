<title><?php echo $row_data['nama']; ?> | Kirim Pesan </title>
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == 'superadmin') {
?>

    <!-- INI UNTUK JUDUL -->
    <section class="content-header">
        <h1>
            Kirim Pesan
        </h1>
        <ol class="breadcrumb">
            <li><a href="index.php?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Pesan</li>
        </ol>
    </section>
    <section class="content">
        <!-- INI UNTUK ISI -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
                    <div class="panel-heading bg-aqua">
                        <i class="fa fa-users fa-fw"></i> Kirim Pesan
                    </div>


                    <!-- INI BAGIAN ISI UTAMA -->
                    <div class="panel-body table-responsive">
                        <?php foreach ($messages as $message) : ?>
                            <div>
                                <h3>message ID: <?php echo $message['message_id']; ?></h3>
                                <p>User 1: <?php echo $message['sender']; ?></p>
                                <p>User 2: <?php echo $message['receiver']; ?></p>
                                <p>Message: <?php echo $message['message_content']; ?></p>
                                <p>Sent At: <?php echo $message['sent_at']; ?></p>
                            </div>
                            <hr>
                        <?php endforeach; ?>
                        <!-- INI BAGIAN TABEL -->
                        <form role="form" method="POST" action="index.php?controller=pesan&method=send_message">
                            <table width="100%">
                                <thead>
                                    <tr>
                                        <th width="6%">
                                            <div class="form-group">
                                                Kontak
                                            </div>
                                        </th>
                                        <th width="60%">
                                            <div class="form-group">
                                                <!-- // Ganti jadi selection yang diambil dari db -->
                                                <select name="receiver" id="receiver" class="form-control select2">
                                                    <option value=" ">- Pilih Kontak -</option>
                                                    <?php

                                                    $getUser = $_SESSION['username_simpeg'];
                                                    $query_user = "SELECT * FROM user WHERE status='Aktif' AND username!='$getUser'";
                                                    $user = mysqli_query($koneksi, $query_user);
                                                    while ($row_user = mysqli_fetch_array($user)) {
                                                        // MENAMPILKAN OPSI Kategori
                                                        echo "<option value='$row_user[username]'>$row_user[nama]</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>
                                            <div class="form-group">
                                                Pesan
                                            </div>
                                        </th>
                                        <th>
                                            <div class="form-group">
                                                <textarea name="messageContent" class="form-control" rows="3" required></textarea>
                                            </div>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th width="10%" colspan="2">
                                            <center>
                                                <button type="submit" class="btn btn-info btn-md pull-right" title="Cari"><i class="fa fa-send fa-fw"></i> Kirim</button>
                                            </center>
                                        </th>
                                    </tr>
                                </thead>
                            </table>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
<?php
} else {
    echo "<script>window.history.back(); </script>";
}
?>