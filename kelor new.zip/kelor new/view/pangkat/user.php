<title><?php echo $row_data['nama']; ?> | Pengajuan Pangkat</title>

<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin" || $_SESSION['level_simpeg'] == "user") {
?>
<!-- Judul Halaman -->
<section class="content-header">
    <h1>Data Pengajuan Pangkat</h1>
    <ol class="breadcrumb">
        <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Data Pengajuan Pangkat</li>
    </ol>
</section>

<!-- Konten Utama -->
<section class="content">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default">
                <!-- Header Panel -->
                <div class="panel-heading bg-aqua">
                    <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Pangkat
                </div>
                
                <!-- Body Panel -->
                <div class="panel-body table-responsive">
                    <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
                        <!-- Tabel untuk Admin/Superadmin -->
                        <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr class="odd bg-gray">
                                    <th width="1%" class="text-center">No</th>
                                    <th class="text-center">Pengusul</th>
                                    <th class="text-center">File</th>
                    				<th><center>Keterangan Upload</center></th>
                                    <th class="text-center">Tanggal Pengajuan</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Upload File</th>
                                    <th class="text-center">Validasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $nomor = 1;
                                if (isset($data_pangkat)) {
                                    while ($row_pangkat = mysqli_fetch_array($data_pangkat)) {
                                ?>
                                        <tr class="odd gradeX">
                                            <td class="text-center"><?php echo $nomor; ?></td>
                                            <td><?php echo !empty($row_pangkat['nama_lengkap']) ? $row_pangkat['nama_lengkap'] : '-'; ?></td>
                                            <td>
                                                <a href="upload_berkas/<?php echo $row_pangkat['file']; ?>">
                                                    <?php echo $row_pangkat['nama']; ?>
                                                </a>
                                            </td>
                                            <td>
    <?php
    echo !empty($row_pangkat['keterangan'])
        ? nl2br(htmlspecialchars($row_pangkat['keterangan']))
        : '-';
    ?>
</td>
                                            <td class="text-center"><?php echo !empty($row_pangkat['tanggal_pengajuan']) ? $row_pangkat['tanggal_pengajuan'] : '-'; ?></td>
                                            
                                            <!-- Kolom Status -->
                                            <td class="text-center">
                                                <span class="badge"><?php echo !empty($row_pangkat['status']) ? $row_pangkat['status'] : '-'; ?></span><br>
                                                <small><?php echo !empty($row_pangkat['tanggal_approve']) ? $row_pangkat['tanggal_approve'] : '-'; ?></small><br>
                                                
                                                <?php if (!empty($row_pangkat['reason'])) { ?>
                                                    <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_pangkat['id']; ?>" class="btn btn-xs btn-info">
                                                        <i class="fa fa-eye"></i> Lihat Keterangan
                                                    </a>
                                                    
                                                    <!-- Modal Reason -->
                                                    <div class="modal fade" id="reasonModal<?php echo $row_pangkat['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog modal-md">
                                                            <div class="modal-content">
                                                                <div class="modal-header bg-aqua">
                                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                    <h4 class="modal-title">Keterangan (Alasan)</h4>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <?php echo nl2br(htmlspecialchars($row_pangkat['reason'])); ?>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php } else { ?>
                                                    <span class="text-muted">Tidak ada keterangan</span>
                                                <?php } ?>
                                            </td>
                                            
                                            <!-- Kolom Upload File -->
                                            <td class="text-center">
                                                <?php if (!empty($row_pangkat['upload'])) { ?>
                                                    <a href="upload_berkas/<?php echo $row_pangkat['upload']; ?>" target="_blank" class="btn btn-xs btn-primary">
                                                        <i class="fa fa-download"></i> Lihat File
                                                    </a>
                                                <?php } else { ?>
                                                    <span class="text-danger">Tidak ada file</span>
                                                <?php } ?>
                                            </td>
                                            
                                            <!-- Kolom Validasi -->
                                            <td class="text-center">
                                                <!-- Tombol Validasi -->
                                                <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#pangkat<?php echo $row_pangkat['id']; ?>" title="Ubah">
                                                    <i class="fa fa-check"></i>
                                                </button>
                                                
                                                <!-- Modal Validasi -->
                                                <div class="modal fade" id="pangkat<?php echo $row_pangkat['id']; ?>">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                <center><h4 class="modal-title">Validasi Pengajuan</h4></center>
                                                            </div>
                                                            
                                                            <form role="form" method="POST" action="index.php?controller=pangkat&method=update_status" enctype="multipart/form-data">
                                                               <table width="100%" class="modal-body">
                                                                  <tr>
                                                                    <td>
                                                                      <div class="modal-body"><label>Status</label></div>
                                                                    </td>
                                                                    <td>
                                                                          <div class="modal-body">
                                                                        <input type="hidden" name="id" value="<?php echo $row_pangkat['id']; ?>">
                                                                        <select class="form-control" name="status" required style="width: 100%;">
                                                                          <option value="Tidak Memenuhi Syarat">Tidak Memenuhi Syarat</option>
                                                                          <option value="Proses Di BKN">Proses Di BKN</option>
                                                                          <option value="Perbaikan Dokumen">Perbaikan Dokumen</option>
                                                                          <option value="Dokumen Tidak Lengkap">Dokumen Tidak Lengkap</option>
                                                                          <option value="Dokumen Tidak Jelas">Dokumen Tidak Jelas</option>
                                                                          <option value="Proses di BKPSDM">Proses di BKPSDM</option>
                                                                          <option value="Proses TTD">Proses TTD</option>
                                                                          <option value="Selesai">Selesai</option>
                                                                        </select>
                                                                      </div>
                                                                    </td>

                                                              </tr>

                                                                    <tr>
                                                                      <td><div class="modal-body"><label>Keterangan</label></div></td>
                                                                      <td>
                                                                        <div class="modal-body">
                                                                          <textarea class="form-control" name="reason" rows="5" style="width: 100%;"></textarea>
                                                                          <br>
                                                                          <small>(Wajib diisi jika Tidak Memenuhi Syarat)</small>
                                                                        </div>
                                                                      </td>
                                                                    </tr>
                                                                    <tr>
                                                                      <td><div class="modal-body"><label>Upload File</label></div></td>
                                                                      <td>
                                                                        <div class="modal-body">
                                                                          <input type="file" name="upload_file" class="form-control">
                                                                          <small class="text-muted">Opsional, boleh dikosongkan</small>
                                                                        </div>
                                                                      </td>
                                                                    </tr>
                                                                </table>
                                                                
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                                                                    <input type="submit" name="submit" class="btn btn-success" value="Simpan">
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- Tombol Hapus -->
                                                <a href="index.php?controller=pangkat&method=delete&id=<?php echo $row_pangkat['id']; ?>" 
                                                   class="btn btn-danger btn-xs" 
                                                   onclick="return confirm('Yakin ingin menghapus data berkas : <?php echo $row_pangkat['nama_lengkap']; ?> ?')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                <?php
                                        $nomor++;
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                        
                    <?php } elseif ($_SESSION['level_simpeg'] == 'user') { ?>
                        <!-- Form Upload untuk User -->
                        <form role="form" method="POST" action="index.php?controller=pangkat&method=insert_pangkat_berkas" enctype="multipart/form-data">
                            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr class="odd bg-gray">
                                      <th width="1%">
                                        <center>No</center>
                                      </th>
                                        <th class="text-center">Nama</th>
                                        <th class="text-center">File</th>
                    					<th><center>Keterangan Upload</center></th>
                                        <th class="text-center">Konfigurasi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $nomor = 1;
                                    if (isset($data_pangkat)) {
                                        while ($row_pangkat = mysqli_fetch_array($data_pangkat)) {
                                    ?>
                                            <tr class="odd gradeX">
                                              <td><?php echo $nomor; ?></td>
                                                <td class="text-center">
                                                    <?php echo $row_pangkat['nama']; ?>
                                                    <input type="hidden" name="nama_file[]" value="<?php echo $row_pangkat['nama']; ?>">
                                                </td>
                                                
                                                <td class="text-center">
                                                    <?php $mb = $row_pangkat['size'] * 1024 * 1024; ?>
                                                    <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $mb; ?>">
                                                    <input type="file" name="file[]" id="file_id" class="form-control" accept="<?php echo $row_pangkat['accept']; ?>" onchange="upload_check()">
                                                </td>
                                              <td>
    <textarea
        name="keterangan[]"
        class="form-control"
        rows="9"
        placeholder="Masukkan Nama/NIP Pegawai yang akan diusulkan"
        required
        oninvalid="this.setCustomValidity('Keterangan wajib diisi')"
        oninput="setCustomValidity('')"></textarea>
</td>
                                                
                                                <td align="center">
                                                  <div><strong class="text-danger">Maks: 900kb</strong>
                                                    <input type="hidden" name="size_file[]" value="<?php echo $row_pangkat['size']; ?>">
                                                  </div><br>
                                                  <div><strong class="text-danger">Ekstensi: <?php echo $row_pangkat['accept']; ?></strong>
                                                    <input type="hidden" name="accept_file[]" value="<?php echo $row_pangkat['accept']; ?>">
                                                  </div>
                                                </td>
                                            </tr>
                                    <?php
                                            $nomor++;
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                            
                            <div class="text-center">
                                <button type="submit" name="submit" class="btn btn-success">
                                    <i class="fa fa-upload"></i> Upload Berkas
                                </button>
                            </div>
                        </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
function upload_check() {
    var upl = document.getElementById("file_id");
    var max = document.getElementById("max_id").value;
    
    if (upl.files && upl.files[0]) {
        if (upl.files[0].size > max) {
            alert("Ukuran File Terlalu Besar");
            upl.value = "";
        }
    }
}
</script>

<?php
} else {
    echo "<script>window.history.back();</script>";
}
?>