<title><?php echo $row_data['nama']; ?> | Pengajuan Pangkat</title>
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin") {
?>


  <!-- INI UNTUK JUDUL -->
  <section class="content-header">
    <h1>
      Data Pengajuan Pangkat
    </h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Pangkat</li>
    </ol>
  </section>
  <section class="content">
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-danger">
      <li class="fa fa-plus"></li> Tambah Data
    </button>
    <br>
    <br>
    <!-- INI UNTUK ISI -->
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Pangkat
          </div>

          <!-- INI BAGIAN ISI UTAMA -->
          <div class="panel-body table-responsive">
            <!-- INI BAGIAN TABEL -->
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%">
                    <center>No</center>
                  </th>
                  <th>
                    <center>Nama</center>
                  </th>
                  <th>
                    <center>Size Maksimal</center>
                  </th>
                  <th>
                    <center>Ekstensi</center>
                  </th>
                  <th>
                    <center>User</center>
                  </th>
                  <th>
                    <center>Aksi</center>
                  </th>
                </tr>
              </thead>
              <!-- INI UNTUK MENERIMA DATA DARI CONTROLLER -->
              <tbody>
                <?php
                // SET NOMOR URUT DATA
                $nomor          =   1;

                // CEK DATA YANG DITERIMA
                if (isset($data_pangkat)) {
                  while ($row_pangkat  = mysqli_fetch_array($data_pangkat)) {
                ?>

                    <tr class="odd gradeX">
                      <td><?php echo $nomor; ?></td>
                      <td><?php echo $row_pangkat['nama']; ?></td>
                      <td><?php echo $row_pangkat['size']; ?></td>
                      <td><?php echo $row_pangkat['accept']; ?></td>
                      <td><?php echo $row_pangkat['nama_karyawan']; ?></td>
                      <td>
                        <center>
                          <!-- <a type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#pengajuan<?php echo $row_pengajuan['id']; ?>" data-toggle="tooltip" data-placement="top" title="Ubah"><i class="fa fa-edit fa-fw"></i></a> -->

                          <!-- <div class="modal fade" id="pengajuan<?php echo $row_pengajuan['id']; ?>">
                            <div class="modal-dialog modal-md">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                  <center>
                                    <h4 class="modal-title">Edit Data Pengajuan</h4>
                                  </center>
                                </div>
                                <form role="form" method="POST" action="index.php?controller=pengajuan&method=update_pengajuan" enctype="multipart/form-data">
                                  <table width="100%" class="modal-body">
                                    <tr>
                                      <td>
                                        <div class="modal-body">
                                          <div class="form-group">
                                            <label>Nama <span class="text-danger">*</span></label>
                                          </div>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          <input type="hidden" name="id" value="<?php echo $row_pengajuan['id']; ?>">
                                          <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama" required oninvalid="this.setCustomValidity('Masukan Nama')" oninput="setCustomValidity('')" value="<?php echo $row_pengajuan['nama']; ?>">
                                        </div>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <div class="modal-body">
                                          <div class="form-group">
                                            <label>Size (mb) <span class="text-danger">*</span></label>
                                          </div>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          <input type="number" name="size" id="size" class="form-control" placeholder="Size" required oninvalid="this.setCustomValidity('Masukan Size')" oninput="setCustomValidity('')" value="<?php echo $row_pengajuan['size']; ?>">
                                        </div>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td>
                                        <div class="modal-body">
                                          <div class="form-group">
                                            <label>Ekstensi <span class="text-danger">*</span></label>
                                          </div>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="modal-body">
                                          <select name="ekstensi[]" id="ekstensi_edit" class="form-control select2" multiple="true" required style="width: 100%;">
                                            <option value="" disabled>Pilih Ekstensi</option>
                                            <option value="pdf">PDF</option>
                                            <option value="ppt">PPT</option>
                                            <option value="word">Word</option>
                                            <option value="excel">Excel</option>
                                            <option value="images">Image (PNG, JPG, JPEG)</option>
                                          </select>
                                        </div>
                                      </td>
                                    </tr>
                                  </table>

                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>

                                    <input id="button" type="submit" name="submit" class="btn btn-outline btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                  </div>
                                </form>
                              </div>
                              
                            </div>
                            
                          </div> -->
                          <!-- /.modal -->

                          <a href="index.php?controller=pangkat&method=delete_pangkat&id=<?php echo $row_pangkat['id']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin hapus?')"> <i class="fa fa-trash fa-fw"></i> </a>
                        </center>

                      </td>
                    </tr>

                <?php
                    // INCREMENT NOMOR URUT
                    $nomor++;
                  }
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    </div>
  </section>


  <!--Modal Untuk Tambah Data -->
  <div class="modal fade" id="modal-danger">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <center>
            <h4 class="modal-title">Tambah Data Pengajuan Pangkat</h4>
          </center>
        </div>
        <form role="form" method="POST" action="index.php?controller=pangkat&method=insert_pangkat" enctype="multipart/form-data">
          <table width="100%" class="modal-body">
            <tr>
              <td>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Nama <span class="text-danger">*</span></label>
                  </div>
                </div>
              </td>
              <td>
                <div class="modal-body">
                  <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama" required oninvalid="this.setCustomValidity('Masukan Nama')" oninput="setCustomValidity('')">
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Size (mb) <span class="text-danger">*</span></label>
                  </div>
                </div>
              </td>
              <td>
                <div class="modal-body">
                  <input type="number" name="size" id="size" class="form-control" placeholder="Size" required oninvalid="this.setCustomValidity('Masukan Size')" oninput="setCustomValidity('')">
                </div>
              </td>
            </tr>

            <tr>
              <td>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Ekstensi <span class="text-danger">*</span></label>
                  </div>
                </div>
              </td>
              <td>
                <div class="modal-body">
                  <select name="ekstensi[]" id="ekstensi" class="form-control select2" multiple="true" required style="width: 100%;">
                    <option value="" disabled>Pilih Ekstensi</option>
                    <option value=".pdf">PDF</option>
                    <option value=".docx">Word</option>
                    <option value=".xlsx, .xls">Excel</option>
                    <option value="image/*">Image (PNG, JPG, JPEG)</option>
                  </select>
                </div>
              </td>
            </tr>

            <tr>
              <td>
                <div class="modal-body">
                  <div class="form-group">
                    <label>User <span class="text-danger">*</span></label>
                  </div>
                </div>
              </td>
              <td>
                <div class="modal-body">
                  <select name="nip" id="nip" class="form-control select2" style="width: 100%;" required>
                    <option value="" disabled>- Pilih NIP -</option>
                    <?php
                    include("config/koneksi.php");
                    $query_status = "select * from pegawai";
                    $status = mysqli_query($koneksi, $query_status);
                    while ($row_status = mysqli_fetch_array($status)) {
                      // MENAMPILKAN OPSI Kategori
                      echo "<option value='$row_status[nip]'>$row_status[nip] - $row_status[nama]</option>";
                    }
                    ?>
                  </select>
                </div>
              </td>
            </tr>

          </table>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
            <input id="button" type="submit" name="submit" class="btn btn-success" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
          </div>
        </form>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

<?php
} else {
  echo "<script>window.history.back(); </script>";
}
?>