<title><?php echo $row_data['nama']; ?> | Pengajuan Pangkat</title>
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin" || $_SESSION['level_simpeg'] == "user") {
?>

  <!-- INI UNTUK JUDUL -->
  <section class="content-header">
    <h1>Data Pengajuan Pangkat</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Pangkat</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Pangkat
          </div>

          <div class="panel-body table-responsive">
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%"><center>No</center></th>
                  <th><center>Pengusul</center></th>
                  <th><center>File</center></th>
				  <th><center>Keterangan Upload</center></th>
                  <th><center>Tanggal Pengajuan</center></th>
                  <th><center>Status</center></th>
                  <th><center>Upload File</center></th>
                  <th><center>Action</center></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $nomor = 1;
                if (isset($data_pangkat)) {
                  while ($row_pangkat = mysqli_fetch_array($data_pangkat)) {

                    // Helper kecil: coba ambil list file jika ada (JSON atau array serialized)
                    $list_files = [];
                    if (!empty($row_pangkat['upload_files_json'])) {
                      $decoded = json_decode($row_pangkat['upload_files_json'], true);
                      if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $list_files = $decoded;
                      }
                    } elseif (!empty($row_pangkat['files'])) {
                      // Jika kolom 'files' sudah berupa array JSON dalam string
                      $decoded = json_decode($row_pangkat['files'], true);
                      if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $list_files = $decoded;
                      }
                    }
                ?>
                <tr class="odd gradeX">
                  <!-- Nomor -->
                  <td align="center"><?php echo $nomor; ?></td>
                  <td align="center">
                    <?php echo $row_pangkat['nama_lengkap'] == '' ? '-' : htmlspecialchars($row_pangkat['nama_lengkap']); ?>
                  </td>

                  <!-- File -->
                  <td align="center">
                    <?php if (!empty($row_pangkat['file'])) { ?>
                      <a href="upload_berkas/<?php echo $row_pangkat['file']; ?>" target="_blank">
                        <?php echo !empty($row_pangkat['nama']) ? htmlspecialchars($row_pangkat['nama']) : htmlspecialchars($row_pangkat['file']); ?>
                      </a>
                    <?php } else { ?>
                      -
                    <?php } ?>
                  </td>
                    
                   <td>
    <?php
    echo !empty($row_pangkat['keterangan'])
        ? nl2br(htmlspecialchars($row_pangkat['keterangan']))
        : '-';
    ?>
</td>

                  <!-- Tanggal Pengajuan -->
                  <td align="center">
                    <?php echo $row_pangkat['tanggal_pengajuan'] == '' ? '-' : htmlspecialchars($row_pangkat['tanggal_pengajuan']); ?>
                  </td>

                  <!-- Status + Tanggal + Alasan -->
                  <td align="center">
                    <span class="badge"><?php echo $row_pangkat['status'] == '' ? '-' : htmlspecialchars($row_pangkat['status']); ?></span><br>
                    <?php echo $row_pangkat['tanggal_approve'] == '' ? '-' : htmlspecialchars($row_pangkat['tanggal_approve']); ?>

                    <?php if (!empty($row_pangkat['reason'])) { ?>
                      <br>
                      <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_pangkat['id']; ?>" class="btn btn-xs btn-info">
                        <i class="fa fa-eye"></i>Lihat Alasan
                      </a>

                      <!-- Modal Reason -->
                      <div class="modal fade" id="reasonModal<?php echo $row_pangkat['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header bg-aqua">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Keterangan (Reason)</h4>
                            </div>
                            <div class="modal-body">
                              <?php echo nl2br(htmlspecialchars($row_pangkat['reason'])); ?>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php } ?>
                  </td>

                  <!-- Action -->
                  <td align="center">
                      <?php if (!empty($row_pangkat['upload'])) { ?>
                        <a href="upload_berkas/<?php echo $row_pangkat['upload']; ?>" target="_blank" class="btn btn-info btn-xs">
                          Lihat File
                        </a>
                      <?php } else { ?>
                        <span class="text-muted">Tidak ada file</span>
                      <?php } ?>
                    </td>

                    <!-- Action: hanya Hapus saat status = 'Upload Berkas', selain itu '-' -->
                    <td align="center">
                      <?php if ($row_pangkat['status'] == 'Upload Berkas') { ?>
                        <a href="index.php?controller=Pangkat&method=delete&id=<?php echo $row_pangkat['id']; ?>"
                           class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete"
                           onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo htmlspecialchars($row_pangkat['nama_lengkap']); ?> ?')">
                          <i class="fa fa-trash fa-fw"></i>
                        </a>
                      <?php } else { ?>
                        -
                      <?php } ?>
                    </td>
                </tr>
                <?php
                      $nomor++;
                    }
                  }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php
} else {
  echo "<script>window.history.back();</script>";
}
?>
