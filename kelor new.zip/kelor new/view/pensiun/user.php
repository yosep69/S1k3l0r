<title><?php echo $row_data['nama']; ?> | Pengajuan Pensiun</title>
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin" || $_SESSION['level_simpeg'] == "user") {
?>


  <!-- INI UNTUK JUDUL -->
  <section class="content-header">
    <h1>
      Data Pengajuan Pensiun
    </h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Pensiun</li>
    </ol>
  </section>
  <section class="content">
    <!-- INI UNTUK ISI -->
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Pensiun
          </div>

          <!-- INI BAGIAN ISI UTAMA -->
          <div class="panel-body table-responsive">
            <!-- INI BAGIAN TABEL -->
            <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
              <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                <thead>
                  <tr class="odd bg-gray">
                    <th width="1%"><center>No</center></th>
                    <th><center>Pengusul</center></th>
                    <th><center>File</center></th>
            		<th><center>Keterangan</center></th>
                    <th><center>Tanggal Pengajuan</center></th>
                    <th><center>Status</center></th>
                    <th><center>Upload File</center></th>
                    <th><center>Validasi</center></th>
                  </tr>
                </thead>
                <!-- INI UNTUK MENERIMA DATA DARI CONTROLLER -->
                <tbody>
                  <?php
                  // SET NOMOR URUT DATA
                  $nomor          =   1;

                  // CEK DATA YANG DITERIMA
                  if (isset($data_pensiun)) {
                    while ($row_pensiun  = mysqli_fetch_array($data_pensiun)) {
                  ?>

                      <tr class="odd gradeX">
                        <td><?php echo $nomor; ?></td>
                        <td align="center"><?php echo $row_pensiun['nama_lengkap'] == '' ? '-' :  $row_pensiun['nama_lengkap']; ?></td>
                        <td align="center"><a href="upload_berkas/pensiun/<?php echo $row_pensiun['file']; ?>"><?php echo $row_pensiun['nama']; ?></a></td>
                        <td>
    <?php
    echo !empty($row_pensiun['keterangan'])
        ? nl2br(htmlspecialchars($row_pensiun['keterangan']))
        : '-';
    ?>
</td>
                        <td align="center"><?php echo $row_pensiun['tanggal_pengajuan'] == '' ? '-' :  $row_pensiun['tanggal_pengajuan']; ?></td>

                        <td align="center">
                          <span class="badge"><?php echo $row_pensiun['status'] == '' ? '-' :  $row_pensiun['status']; ?></span>
                          <br>
                          <?php echo $row_pensiun['tanggal_approve'] == '' ? '-' :  $row_pensiun['tanggal_approve']; ?>

                          <?php if (!empty($row_pensiun['reason'])) { ?>
                            <br>

                            <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_pensiun['id']; ?> " class="btn btn-xs btn-info">
                          <i class="fa fa-eye"></i>Lihat Keterangan
                        </a>

                        <!-- Modal Reason -->
                        <div class="modal fade" id="reasonModal<?php echo $row_pensiun['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                          <div class="modal-dialog modal-md">
                            <div class="modal-content">
                              <div class="modal-header bg-aqua">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Keterangan (Alasan)</h4>
                              </div>
                              <div class="modal-body">
                                <?php echo nl2br(htmlspecialchars($row_pensiun['reason'])); ?>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      <?php } ?>
                    </td>

                    <!-- Kolom Upload File -->
                                            <td class="text-center">
                                                <?php if (!empty($row_pensiun['upload'])) { ?>
                                                    <a href="upload_berkas/pensiun/<?php echo $row_pensiun['upload']; ?>" target="_blank" class="btn btn-xs btn-primary">
                                                        <i class="fa fa-download"></i> Lihat File
                                                    </a>
                                                <?php } else { ?>
                                                    <span class="text-danger">Tidak ada file</span>
                                                <?php } ?>
                                            </td>

                        <td>
                          <center>
                            <a type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#pensiun<?php echo $row_pensiun['id']; ?>" data-toggle="tooltip" data-placement="top" title="Ubah"><i class="fa fa-check"></i></a>

                            <div class="modal fade" id="pensiun<?php echo $row_pensiun['id']; ?>">
                              <div class="modal-dialog modal-md">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span></button>
                                    <center>
                                      <h4 class="modal-title">Validasi Pengajuan Pensiun</h4>
                                    </center>
                                  </div>
                                  <form role="form" method="POST" action="index.php?controller=pensiun&method=update_status" enctype="multipart/form-data">
                                    <table width="100%" class="modal-body">
                                      <tr>
                                        <td>
                                          <div class="modal-body">
                                            <div class="form-group">
                                              <label>Status</label>
                                            </div>
                                          </div>
                                        </td>
                                        <td>
                                          <div class="modal-body">
                                            <input type="hidden" name="id" id="id" value="<?php echo $row_pensiun['id']; ?>" class="form-control">
                                            <select class="form-control" name="status" required style="width: 100%;">
                                              <option value="Tidak Memenuhi Syarat">Tidak Memenuhi Syarat</option>
                                              <option value="Proses Di BKN">Proses Di BKN</option>
                                              <option value="Perbaikan Dokumen">Perbaikan Dokumen</option>
                                              <option value="Dokumen Tidak Lengkap">Dokumen Tidak Lengkap</option>
                                              <option value="Dokumen Tidak Jelas">Dokumen Tidak Jelas</option>
                                              <option value="Proses di BKPSDM">Proses di BKPSDM</option>
                                              <option value="Proses TTD">Proses TTD</option>
                                              <option value="Selesai">Selesai</option>
                                            </select>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          <div class="modal-body">
                                            <div class="form-group">
                                              <label>Keterangan</label>
                                            </div>
                                          </div>
                                        </td>
                                        <td>
                                          <div class="modal-body">
                                            <textarea class="form-control" name="reason" rows="5" style="width: 100%;"></textarea>
                                            <br>
                                            <small>(Wajib diisi jika Pengajuan Belum Selesai)</small>
                                          </div>
                                        </td>
                                        <tr>
                                    <td><div class="modal-body"><label>Upload File</label></div></td>
                                    <td>
                                      <div class="modal-body">
                                        <input type="file" name="upload_file" class="form-control">
                                        <small class="text-muted">Opsional, boleh dikosongkan</small>
                                      </div>
                                    </td>
                                  </tr>
                                      </tr>
                                    </table>

                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>

                                      <input id="button" type="submit" name="submit" class="btn btn-success btn-xl" value="Simpan" data-toggle="tooltip" data-placement="top" title="Simpan">
                                    </div>
                                  </form>
                                </div>
                                <!-- /.modal-content -->
                              </div>
                              <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
                            <a href="index.php?controller=pensiun&method=delete&id=<?php echo $row_pensiun['id']; ?>" class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo $row_pensiun['nama_lengkap']; ?> ?')"> <i class="fa fa-trash fa-fw"></i> </a>
                          </center>
                          
                        </td>
                      </tr>

                  <?php
                      // INCREMENT NOMOR URUT
                      $nomor++;
                    }
                  }
                  ?>
                </tbody>
              </table>
            <?php } elseif ($_SESSION['level_simpeg'] == 'user') {
            ?>
              <form role="form" method="POST" action="index.php?controller=pensiun&method=insert_pensiun_berkas" enctype="multipart/form-data">
                <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                  <thead>
                    <tr class="odd bg-gray">
                      <th width="1%">
                    <center>No</center>
                  </th>
                      <th>
                        <center>Nama</center>
                      </th>
                      <th>
                        <center>File</center>
                      </th>
            		<th><center>Keterangan</center></th>
                      <th>
                        <center>Konfigurasi</center>
                      </th>
                    </tr>
                  </thead>
                  <!-- INI UNTUK MENERIMA DATA DARI CONTROLLER -->

                  <tbody>
                    <?php
                    // SET NOMOR URUT DATA
                    $nomor          =   1;

                    // CEK DATA YANG DITERIMA
                    if (isset($data_pensiun)) {
                      while ($row_pensiun  = mysqli_fetch_array($data_pensiun)) {
                    ?>

                        <tr class="odd gradeX">
                          <td><?php echo $nomor; ?></td>
                          <div class="form-group">
                            <td align="center"><?php echo $row_pensiun['nama']; ?> <input type="hidden" name="nama_file[]" class="form-control" value="<?php echo $row_pensiun['nama']; ?>" /></td>
                            <td align="center"><?php $mb = $row_pensiun['size'] * 1024 * 1024; ?>
                              <input id="max_id" type="hidden" name="MAX_FILE_SIZE" value="<?php echo $mb; ?>" />
                              <input type="file" onchange="upload_check()" name="file[]" id="file_id" class="form-control" accept="<?php echo $row_pensiun['accept']; ?>" />
                            </td>
                          
                          <td>
    <textarea
        name="keterangan[]"
        class="form-control"
        rows="9"
        placeholder="Masukkan Nama/NIP Pegawai yang akan diusulkan"
        required
        oninvalid="this.setCustomValidity('Keterangan wajib diisi')"
        oninput="setCustomValidity('')"></textarea>
</td>

                            <td align="center">
                              <div><strong class="text-danger">Maks: 900kb</strong>
                                <input type="hidden" name="size_file[]" value="<?php echo $row_pensiun['size']; ?>">
                              </div><br>
                              <div><strong class="text-danger">Ekstensi: <?php echo $row_pensiun['accept']; ?></strong>
                                <input type="hidden" name="accept_file[]" value="<?php echo $row_pensiun['accept']; ?>">
                              </div>
                            </td>
                          </div>
                        </tr>



                    <?php
                        // INCREMENT NOMOR URUT
                        $nomor++;
                      }
                    }
                    ?>
                  </tbody>


                </table>
                <center><input type="submit" name="submit" class="btn btn-success" value="Upload Berkas" data-toggle="tooltip" data-placement="top" title="Upload Berkas"></center>
              </form>
            <?php
            } ?>
          </div>
        </div>
      </div>
    </div>
    </div>
  </section>

  <script>
    function upload_check() {
      var upl = document.getElementById("file_id");
      var max = document.getElementById("max_id").value;
      // console.log(upl.files[0].size)
      if (upl.files[0].size > max) {
        alert("Ukuran File Terlalu Besar");
        upl.value = "";
      }
    };
  </script>
<?php
} else {
  echo "<script>window.history.back(); </script>";
}
?>