<title><?php echo isset($row_data['nama']) ? htmlspecialchars($row_data['nama']) : 'Data'; ?> | Pengajuan Pensiun</title>
<?php
if (isset($_SESSION['level_simpeg']) && 
    ($_SESSION['level_simpeg'] == "admin" || 
     $_SESSION['level_simpeg'] == "superadmin" || 
     $_SESSION['level_simpeg'] == "user")) {
?>
  <!-- Header Halaman -->
  <section class="content-header">
    <h1>Data Pengajuan Pensiun</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Pensiun</li>
    </ol>
  </section>

  <!-- Konten Utama -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Pensiun
          </div>
          <div class="panel-body table-responsive">
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%"><center>No</center></th>
                  <th><center>Pengusul</center></th>
                  <th><center>File</center></th>
				  <th><center>Keterangan</center></th>
                  <th><center>Tanggal Pengajuan</center></th>
                  <th><center>Status</center></th>
                  <th><center>Upload File</center></th>
                  <th><center>Action</center></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $nomor = 1;
                if (isset($data_pensiun) && $data_pensiun) {
                  while ($row_pensiun = mysqli_fetch_array($data_pensiun)) {
                ?>
                    <tr class="odd gradeX">
                      <td><?php echo $nomor; ?></td>
                      <td><?php echo !empty($row_pensiun['nama_lengkap']) ? htmlspecialchars($row_pensiun['nama_lengkap']) : '-'; ?></td>
                      
                      <!-- Kolom File -->
                      <td align="center">
                        <?php if (!empty($row_pensiun['file']) && !empty($row_pensiun['nama'])) { ?>
                          <a href="upload_berkas/pensiun/<?php echo htmlspecialchars($row_pensiun['file']); ?>" target="_blank">
                            <?php echo htmlspecialchars($row_pensiun['nama']); ?>
                          </a>
                        <?php } else { ?>
                          -
                        <?php } ?>
                      </td>
                      
                      <td>
    <?php
    echo !empty($row_pensiun['keterangan'])
        ? nl2br(htmlspecialchars($row_pensiun['keterangan']))
        : '-';
    ?>
</td>
                      
                      <td align="center"><?php echo !empty($row_pensiun['tanggal_pengajuan']) ? htmlspecialchars($row_pensiun['tanggal_pengajuan']) : '-'; ?></td>
                      
                      <!-- Kolom Status -->
                      <td align="center">
                        <span class="badge"><?php echo !empty($row_pensiun['status']) ? htmlspecialchars($row_pensiun['status']) : '-'; ?></span><br>
                        <?php echo !empty($row_pensiun['tanggal_approve']) ? htmlspecialchars($row_pensiun['tanggal_approve']) : '-'; ?>
                        
                        <?php if (!empty($row_pensiun['reason'])) { ?>
                          <br>
                          <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_pensiun['id']; ?>" class="btn btn-xs btn-info"></i>Lihat Alasan
                          </a>
                          
                          <!-- Modal untuk menampilkan alasan -->
                          <div class="modal fade" id="reasonModal<?php echo $row_pensiun['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-md">
                              <div class="modal-content">
                                <div class="modal-header bg-aqua">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h4 class="modal-title">Keterangan (Reason)</h4>
                                </div>
                                <div class="modal-body">
                                  <?php echo nl2br(htmlspecialchars($row_pensiun['reason'])); ?>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php } ?>
                      </td>
                      
                      <!-- Kolom Upload File -->
                      <td align="center">
                        <?php if (!empty($row_pensiun['upload'])) { ?>
                          <a href="upload_berkas/pensiun/<?php echo htmlspecialchars($row_pensiun['upload']); ?>" target="_blank" class="btn btn-info btn-xs">
                            <i class="fa fa-download"></i>Lihat File
                          </a>
                        <?php } else { ?>
                          <span class="text-muted">Tidak ada file</span>
                        <?php } ?>
                      </td>
                      
                      <!-- Kolom Aksi -->
                      <td align="center">
                        <?php if ($row_pensiun['status'] == 'Upload Berkas') { ?>
                          <a href="index.php?controller=pensiun&method=delete&id=<?php echo $row_pensiun['id']; ?>"
                             class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete"
                             onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo htmlspecialchars($row_pensiun['nama_lengkap']); ?> ?')">
                            <i class="fa fa-trash fa-fw"></i>
                          </a>
                        <?php } else { ?>
                          -
                        <?php } ?>
                      </td>
                    </tr>
                <?php
                    $nomor++;
                  }
                } else {
                  // Tampilkan pesan jika tidak ada data
                  echo '<tr><td colspan="7" align="center">Tidak ada data pengajuan pensiun tersedia</td></tr>';
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  
<?php
} else {
  // Redirect jika tidak memiliki hak akses
  echo "<script>window.history.back(); </script>";
}
?>