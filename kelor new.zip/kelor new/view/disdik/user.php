<title><?php echo isset($row_disdik['nama']) ? htmlspecialchars($row_disdik['nama']) : 'Data'; ?> | Data Disdik</title>
<?php
if (isset($_SESSION['level_simpeg']) && 
    ($_SESSION['level_simpeg'] == "admin" || 
     $_SESSION['level_simpeg'] == "superadmin" || 
     $_SESSION['level_simpeg'] == "user")) {
?>

  <!-- Header Halaman -->
  <section class="content-header">
    <h1>Data Disdik</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Disdik</li>
    </ol>
  </section>

  <section class="content">
    <br><br>
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Disdik
          </div>
          <div class="panel-body table-responsive">

            <!-- Tabel Admin/Superadmin -->
            <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
              <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                <thead>
                  <tr class="odd bg-gray">
                    <th width="1%"><center>No</center></th>
                    <th><center>Pengusul</center></th>
                    <th><center>File</center></th>
            		<th><center>Keterangan</center></th>
                    <th><center>Tanggal Pengajuan</center></th>
                    <th><center>Status</center></th>
                    <th><center>Upload File</center></th>
                    <th><center>Validasi</center></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $nomor = 1;
                  if (isset($data_disdik)) {
                    while ($row_disdik = mysqli_fetch_array($data_disdik)) {
                  ?>
                      <tr class="odd gradeX">
                        <td><?php echo $nomor; ?></td>
                        <td align="center"><?php echo $row_disdik['nama_lengkap'] ?: '-'; ?></td>
                        <td align="center">
                          <a href="surat/disdik/<?php echo htmlspecialchars($row_disdik['file']); ?>" target="_blank">
                            <?php echo htmlspecialchars($row_disdik['nama']); ?>
                          </a>
                        </td>
                        <td>
    <?php
    echo !empty($row_disdik['keterangan'])
        ? nl2br(htmlspecialchars($row_disdik['keterangan']))
        : '-';
    ?>
</td>
                        <td align="center"><?php echo $row_disdik['tanggal_pengajuan'] ?: '-'; ?></td>

                        <td align="center">
                          <span class="badge"><?php echo $row_disdik['status'] ?: '-'; ?></span><br>
                          <?php echo $row_disdik['tanggal_approve'] ?: '-'; ?>

                          <?php if (!empty($row_disdik['reason'])) { ?>
                            <br>
                            <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_disdik['id']; ?>" class="btn btn-xs btn-info">
                              <i class="fa fa-eye"></i> Lihat Keterangan
                            </a>
                            <!-- Modal Reason -->
                            <div class="modal fade" id="reasonModal<?php echo $row_disdik['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                              <div class="modal-dialog modal-md">
                                <div class="modal-content">
                                  <div class="modal-header bg-aqua">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Keterangan (Alasan)</h4>
                                  </div>
                                  <div class="modal-body">
                                    <?php echo nl2br(htmlspecialchars($row_disdik['reason'])); ?>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          <?php } ?>
                        </td>

                        <td class="text-center">
                          <?php if (!empty($row_disdik['upload'])) { ?>
                            <a href="surat/disdik/<?php echo htmlspecialchars($row_disdik['upload']); ?>" target="_blank" class="btn btn-xs btn-primary">
                              <i class="fa fa-download"></i> Lihat File
                            </a>
                          <?php } else { ?>
                            <span class="text-danger">Tidak ada file</span>
                          <?php } ?>
                        </td>

                        <td>
                          <center>
                            <a type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#disdik<?php echo $row_disdik['id']; ?>" title="Validasi"><i class="fa fa-check"></i></a>

                            <div class="modal fade" id="disdik<?php echo $row_disdik['id']; ?>">
                              <div class="modal-dialog modal-md">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <center>
                                        <h4 class="modal-title">Validasi Disdik</h4></center>
                                  </div>
                                  <form role="form" method="POST" action="index.php?controller=disdik&method=update_status" enctype="multipart/form-data">
                                    <table width="100%" class="modal-body">
                                      <tr>
                                        <td class="modal-body">
                                            <td class="modal-body">
                                            <label>Status</label>
                                            </td>
                                        </td>
                                        
                                        <td>
                                          <input type="hidden" name="id" value="<?php echo $row_disdik['id']; ?>" />
                                          <select class="form-control" name="status" required style="width: 90%;>
                                            <option value="Tidak Memenuhi Syarat">Tidak Memenuhi Syarat</option>
                                            <option value="Proses Di BKN">Proses Di BKN</option>
                                            <option value="Perbaikan Dokumen">Perbaikan Dokumen</option>
                                            <option value="Dokumen Tidak Lengkap">Dokumen Tidak Lengkap</option>
                                            <option value="Dokumen Tidak Jelas">Dokumen Tidak Jelas</option>
                                            <option value="Proses di BKPSDM">Proses di BKPSDM</option>
                                            <option value="Proses di Inspektorat">Proses di Inspektorat</option>
                                            <option value="Proses TTD">Proses TTD</option>
                                            <option value="Selesai">Selesai</option>
                                          </select>
                                          <br>
                                          <small>(status)</small>
                                        </td>
                                      </tr>
                                      
                                      <tr>
                                        <td class="modal-body">
                                        <td class="form-group"><label>Reason</label></td>
                                        </td>
                                        <td>
                                          <textarea class="form-control" name="reason" rows="5" style="width: 90%;"></textarea>
                                          <br>
                                          <small>(Wajib diisi jika Reject berkas)</small>
                                        </td>
                                      </tr>
                                      
                                      <tr>
                                      <td>
                                        <td class="modal-body"><label>Upload File</label></td>
                                      </td>
                                        <td>
                                          <input type="file" name="upload_file" class="form-control">
                                          <small class="text-muted">Opsional</small>
                                        </td>
                                      </tr>
                                    </table>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                                      <input type="submit" name="submit" class="btn btn-success" value="Simpan">
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <a href="index.php?controller=disdik&method=delete&id=<?php echo $row_disdik['id']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Yakin hapus <?php echo $row_disdik['nama_lengkap']; ?>?')"><i class="fa fa-trash fa-fw"></i></a>
                          </center>
                        </td>
                      </tr>
                  <?php
                      $nomor++;
                    }
                  }
                  ?>
                </tbody>
              </table>
            <?php } elseif ($_SESSION['level_simpeg'] == 'user') { ?>
              <!-- Tabel User -->
              <form method="POST" action="index.php?controller=disdik&method=insert_disdik_berkas" enctype="multipart/form-data">
                <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                  <thead>
                    <tr class="odd bg-gray">
                      <th width="1%"><center>No</center></th>
                      <th><center>Nama</center></th>
                      <th><center>File</center></th>
                      <th><center>Keterangan</center></th>
                      <th><center>Konfigurasi</center></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $nomor = 1;
                    if (isset($data_disdik)) {
                      while ($row_disdik = mysqli_fetch_array($data_disdik)) {
                    ?>
                        <tr>
                            <td><?php echo $nomor; ?></td>
                          <td align="center">
                              
                            <?php echo htmlspecialchars($row_disdik['nama']); ?>
                            <input type="hidden" name="nama_file[]" value="<?php echo htmlspecialchars($row_disdik['nama']); ?>" />
                          </td>
                          <td align="center">
                            <?php $mb = $row_disdik['size'] * 1024 * 1024; ?>
                            <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $mb; ?>" />
                            <input type="file" name="file[]" class="form-control" accept="<?php echo $row_disdik['accept']; ?>" onchange="upload_check(this, <?php echo $mb; ?>)">
                          </td>
                          <td>
    <textarea
        name="keterangan[]"
        class="form-control"
        rows="9"
        placeholder="Masukkan Nama/NIP Pegawai yang akan diusulkan"
        required
        oninvalid="this.setCustomValidity('Keterangan wajib diisi')"
        oninput="setCustomValidity('')"></textarea>
</td>
                          <td align="center">
                            <small class="text-danger">maks: <?php echo $row_disdik['size']; ?> Mb</small><br>
                            <small class="text-danger">ekstensi: <?php echo $row_disdik['accept']; ?></small>
                            <input type="hidden" name="size_file[]" value="<?php echo $row_disdik['size']; ?>" />
                            <input type="hidden" name="accept_file[]" value="<?php echo $row_disdik['accept']; ?>" />
                          </td>
                        </tr>
                    <?php
                      }
                    }
                    ?>
                  </tbody>
                </table>
                <center><input type="submit" name="submit" class="btn btn-success" value="Upload Berkas"></center>
              </form>
            <?php } ?>

          </div>
        </div>
      </div>
    </div>
  </section>

<script>
function upload_check(input, max_size) {
    if (input.files[0].size > max_size) {
        alert("Ukuran File Terlalu Besar");
        input.value = "";
    }
}
</script>

<?php
} else {
    echo "<script>window.history.back();</script>";
}
?>
