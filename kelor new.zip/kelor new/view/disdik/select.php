<title><?php echo isset($row_disdik['nama']) ? htmlspecialchars($row_disdik['nama']) : 'Data'; ?> | Data Disdik</title> 
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin") {
?>

  <!-- INI UNTUK JUDUL -->
  <section class="content-header">
    <h1>Data Disdik</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Disdik</li>
    </ol>
  </section>
  <section class="content">
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-add">
      <li class="fa fa-plus"></li> Tambah Data
    </button>
    <br><br>
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Disdik
          </div>
          <div class="panel-body table-responsive">
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%"><center>No</center></th>
                  <th><center>Nama</center></th>
                  <th><center>Size Maksimal</center></th>
                  <th><center>Ekstensi</center></th>
                  <th><center>User</center></th>
                  <th><center>Aksi</center></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $nomor = 1;
                if (isset($data_disdik)) {
                  while ($row_disdik = mysqli_fetch_array($data_disdik)) {
                ?>
                    <tr class="odd gradeX">
                      <td><?php echo $nomor; ?></td>
                      <td><?php echo htmlspecialchars($row_disdik['nama']); ?></td>
                      <td><?php echo htmlspecialchars($row_disdik['size']); ?></td>
                      <td><?php echo htmlspecialchars($row_disdik['accept']); ?></td>
                      <td><?php echo htmlspecialchars($row_disdik['nama_karyawan']); ?></td>
                      <td>
                        <center>
                          <a href="index.php?controller=disdik&method=delete_disdik&id=<?php echo $row_disdik['id']; ?>" 
                             class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete" 
                             onClick="return confirm('Yakin hapus data: <?php echo htmlspecialchars($row_disdik['nama']); ?> ?')">
                            <i class="fa fa-trash fa-fw"></i>
                          </a>
                        </center>
                      </td>
                    </tr>
                <?php
                    $nomor++;
                  }
                } else {
                  echo '<tr><td colspan="6" align="center">Tidak ada data disdik tersedia</td></tr>';
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Modal Tambah Data -->
  <div class="modal fade" id="modal-add">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <center><h4 class="modal-title">Tambah Data Disdik</h4></center>
        </div>
        <form role="form" method="POST" action="index.php?controller=disdik&method=insert_disdik" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="form-group">
              <label>Nama <span class="text-danger">*</span></label>
              <input type="text" name="nama" class="form-control" placeholder="Nama" required>
            </div>
            <div class="form-group">
              <label>Size (mb) <span class="text-danger">*</span></label>
              <input type="number" name="size" class="form-control" placeholder="Size" required>
            </div>
            <div class="form-group">
              <label>Ekstensi <span class="text-danger">*</span></label>
              <select name="ekstensi[]" class="form-control select2" multiple required style="width: 100%;">
                <option value="" disabled>Pilih Ekstensi</option>
                <option value=".pdf">PDF</option>
                <option value=".docx">Word</option>
                <option value=".xlsx, .xls">Excel</option>
                <option value="image/*">Image (PNG, JPG, JPEG)</option>
              </select>
            </div>
            <div class="form-group">
              <label>User <span class="text-danger">*</span></label>
              <select name="nip" class="form-control select2" style="width: 100%;" required>
                <option value="" disabled>- Pilih NIP -</option>
                <?php
                include("config/koneksi.php");
                $query_status = "SELECT * FROM pegawai";
                $status = mysqli_query($koneksi, $query_status);
                while ($row_status = mysqli_fetch_array($status)) {
                  echo "<option value='{$row_status['nip']}'>{$row_status['nip']} - {$row_status['nama']}</option>";
                }
                ?>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
            <input type="submit" name="submit" class="btn btn-success" value="Simpan">
          </div>
        </form>
      </div>
    </div>
  </div>

<?php
} else {
  echo "<script>window.history.back(); </script>";
}
?>
