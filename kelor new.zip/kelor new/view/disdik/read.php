<title><?php echo isset($row_disdik['nama']) ? htmlspecialchars($row_disdik['nama']) : 'Data'; ?> | Data Disdik</title>   
<?php
if (isset($_SESSION['level_simpeg']) && 
    ($_SESSION['level_simpeg'] == "admin" || 
     $_SESSION['level_simpeg'] == "superadmin" ||
     $_SESSION['level_simpeg'] == "koordinator" ||
     $_SESSION['level_simpeg'] == "user")) {
?>
  <!-- Header Halaman -->
  <section class="content-header">
    <h1>Data Disdik</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Disdik</li>
    </ol>
  </section>

  <!-- Konten Utama -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Disdik
          </div>
          <div class="panel-body table-responsive">
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%"><center>No</center></th>
                  <th><center>Pengusul</center></th>
                  <th><center>File</center></th>
				  <th><center>Keterangan</center></th>
                  <th><center>Tanggal Pengajuan</center></th>
                  <th><center>Status</center></th>
                  <th><center>Download</center></th>
                  <th><center>Action</center></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $nomor = 1;
                if (isset($data_disdik) && $data_disdik) {
                  while ($row_disdik = mysqli_fetch_array($data_disdik)) {
                ?>
                    <tr class="odd gradeX">
                      <td><?php echo $nomor; ?></td>
                      <td align="center"><?php echo !empty($row_disdik['nama_lengkap']) ? htmlspecialchars($row_disdik['nama_lengkap']) : '-'; ?></td>
                      
                      <!-- Kolom File -->
                      <td align="center">
                        <?php if (!empty($row_disdik['file']) && !empty($row_disdik['nama'])) { ?>
                          <a href="surat/disdik/<?php echo htmlspecialchars($row_disdik['file']); ?>" target="_blank">
                            <?php echo htmlspecialchars($row_disdik['nama']); ?>
                          </a>
                        <?php } else { ?>
                          -
                        <?php } ?>
                      </td>
                      <td>
    <?php
    echo !empty($row_disdik['keterangan'])
        ? nl2br(htmlspecialchars($row_disdik['keterangan']))
        : '-';
    ?>
</td>
                      
                      <td align="center"><?php echo !empty($row_disdik['tanggal_pengajuan']) ? htmlspecialchars($row_disdik['tanggal_pengajuan']) : '-'; ?></td>
                      
                      <!-- Kolom Status -->
                      <td align="center">
                        <span class="badge"><?php echo !empty($row_disdik['status']) ? htmlspecialchars($row_disdik['status']) : '-'; ?></span><br>
                        <?php echo !empty($row_disdik['tanggal_approve']) ? htmlspecialchars($row_disdik['tanggal_approve']) : '-'; ?>
                        
                        <?php if (!empty($row_disdik['reason'])) { ?>
                          <br>
                          <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_disdik['id']; ?>" class="btn btn-xs btn-info">Lihat Alasan</a>
                          
                          <!-- Modal untuk menampilkan alasan -->
                          <div class="modal fade" id="reasonModal<?php echo $row_disdik['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-md">
                              <div class="modal-content">
                                <div class="modal-header bg-aqua">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h4 class="modal-title">Keterangan (Reason)</h4>
                                </div>
                                <div class="modal-body">
                                  <?php echo nl2br(htmlspecialchars($row_disdik['reason'])); ?>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php } ?>
                      </td>
                      
                      <!-- Kolom Upload File -->
                      <td align="center">
                        <?php if (!empty($row_disdik['upload'])) { ?>
                          <a href="surat/disdik/<?php echo htmlspecialchars($row_disdik['upload']); ?>" target="_blank" class="btn btn-info btn-xs">
                            <i class="fa fa-download"></i> Lihat File
                          </a>
                        <?php } else { ?>
                          <span class="text-muted">Tidak ada file</span>
                        <?php } ?>
                      </td>
                      
                      <!-- Kolom Aksi -->
                      <td align="center">
                        <?php if ($row_disdik['status'] == 'surat/disdik/') { ?>
                          <a href="index.php?controller=disdik&method=delete&id=<?php echo $row_disdik['id']; ?>"
                             class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete"
                             onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo htmlspecialchars($row_disdik['nama_lengkap']); ?> ?')">
                            <i class="fa fa-trash fa-fw"></i>
                          </a>
                        <?php } else { ?>
                          -
                        <?php } ?>
                      </td>
                    </tr>
                <?php
                    $nomor++;
                  }
                } else {
                  echo '<tr><td colspan="7" align="center">Tidak ada data disdik tersedia</td></tr>';
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  
<?php
} else {
  echo "<script>window.history.back(); </script>";
}
?>
