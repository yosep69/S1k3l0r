<title><?php echo isset($row_data['nama']) ? htmlspecialchars($row_data['nama']) : 'Data'; ?> | Pengajuan Dinkes</title>
<?php
if (isset($_SESSION['level_simpeg']) && 
    in_array($_SESSION['level_simpeg'], ['superadmin','admin','user','koordinator'])) {
?>

<section class="content-header">
    <h1>Data Pengajuan Dinkes</h1>
    <ol class="breadcrumb">
        <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Data Pengajuan Dinkes</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading bg-aqua">
                    <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Dinkes
                </div>
                <div class="panel-body table-responsive">
                    <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr class="odd bg-gray">
                                <th width="1%"><center>No</center></th>
                                <th><center>Pengusul</center></th>
                                <th><center>File</center></th>
								<th><center>Keterangan</center></th>
                                <th><center>Tanggal Pengajuan</center></th>
                                <th><center>Status</center></th>
                                <th><center>Upload File</center></th>
                                <th><center>Action</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $nomor = 1;
                            if (isset($data_dinkes) && $data_dinkes) {
                                while ($row_dinkes = mysqli_fetch_array($data_dinkes)) {
                            ?>
                            <tr>
                                <td><?php echo $nomor; ?></td>
                                <td><?php echo !empty($row_dinkes['nama_lengkap']) ? htmlspecialchars($row_dinkes['nama_lengkap']) : '-'; ?></td>
                                <td align="center">
                                    <?php if (!empty($row_dinkes['file'])) { ?>
                                        <a href="surat/dinkes/<?php echo htmlspecialchars($row_dinkes['file']); ?>" target="_blank">
                                            <?php echo htmlspecialchars($row_dinkes['nama']); ?>
                                        </a>
                                    <?php } else { echo '-'; } ?>
                                </td>
                                <td>
    <?php
    echo !empty($row_dinkes['keterangan'])
        ? nl2br(htmlspecialchars($row_dinkes['keterangan']))
        : '-';
    ?>
</td>
                                <td align="center"><?php echo !empty($row_dinkes['tanggal_pengajuan']) ? htmlspecialchars($row_dinkes['tanggal_pengajuan']) : '-'; ?></td>
                                <td align="center">
                                    <span class="badge"><?php echo !empty($row_dinkes['status']) ? htmlspecialchars($row_dinkes['status']) : '-'; ?></span><br>
                                    <?php echo !empty($row_dinkes['tanggal_approve']) ? htmlspecialchars($row_dinkes['tanggal_approve']) : '-'; ?>
                                    <?php if (!empty($row_dinkes['reason'])) { ?>
                                        <br><a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_dinkes['id']; ?>" class="btn btn-xs btn-info">Lihat Alasan</a>
                                        <div class="modal fade" id="reasonModal<?php echo $row_dinkes['id']; ?>">
                                            <div class="modal-dialog modal-md">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-aqua">
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title">Keterangan (Reason)</h4>
                                                    </div>
                                                    <div class="modal-body"><?php echo nl2br(htmlspecialchars($row_dinkes['reason'])); ?></div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </td>
                                <td class="text-center">
                                    <?php if (!empty($row_dinkes['upload'])) { ?>
                                        <a href="surat/dinkes/<?php echo htmlspecialchars($row_dinkes['upload']); ?>" target="_blank" class="btn btn-xs btn-primary">
                                            <i class="fa fa-download"></i> Lihat File
                                        </a>
                                    <?php } else { echo '<span class="text-muted">Tidak ada file</span>'; } ?>
                                </td>
                                <td align="center">
                                    <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
                                        <a href="index.php?controller=dinkes&method=delete&id=<?php echo $row_dinkes['id']; ?>" class="btn btn-danger btn-xs" onClick="return confirm('Yakin ingin menghapus data berkas ini?')">
                                            <i class="fa fa-trash fa-fw"></i>
                                        </a>
                                    <?php } else { echo '-'; } ?>
                                </td>
                            </tr>
                            <?php $nomor++; } } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
} else {
    echo "<script>window.history.back();</script>";
}
?>
