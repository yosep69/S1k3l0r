<title><?php echo $row_data['nama']; ?> | Pengajuan Dinkes</title>
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin" || $_SESSION['level_simpeg'] == "user") {
?>

<section class="content-header">
    <h1>Data Pengajuan Dinkes</h1>
    <ol class="breadcrumb">
        <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Data Pengajuan Dinkes</li>
    </ol>
</section>

<section class="content">
    <br><br>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading bg-aqua">
                    <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Dinkes
                </div>

                <div class="panel-body table-responsive">
                    <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
                        <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr class="odd bg-gray">
                                    <th width="1%"><center>No</center></th>
                                    <th><center>Pengusul</center></th>
                                    <th><center>File</center></th>
                    				<th><center>Keterangan</center></th>
                                    <th><center>Tanggal Pengajuan</center></th>
                                    <th><center>Status</center></th>
                                    <th><center>Upload File</center></th>
                                    <th><center>Validasi</center></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $nomor = 1;
                                if (isset($data_dinkes)) {
                                    while ($row_dinkes = mysqli_fetch_array($data_dinkes)) {
                                ?>
                                <tr class="odd gradeX">
                                    <td><?php echo $nomor; ?></td>
                                    <td><?php echo $row_dinkes['nama_lengkap'] ?: '-'; ?></td>
                                    <td align="center">
                                        <a href="surat/dinkes/<?php echo $row_dinkes['file']; ?>"><?php echo $row_dinkes['nama']; ?></a>
                                    </td>
                                    <td>
    <?php
    echo !empty($row_dinkes['keterangan'])
        ? nl2br(htmlspecialchars($row_dinkes['keterangan']))
        : '-';
    ?>
</td>
                                    <td align="center"><?php echo $row_dinkes['tanggal_pengajuan'] ?: '-'; ?></td>
                                    <td align="center">
                                        <span class="badge"><?php echo $row_dinkes['status'] ?: '-'; ?></span><br>
                                        <?php echo $row_dinkes['tanggal_approve'] ?: '-'; ?>
                                        <?php if (!empty($row_dinkes['reason'])) { ?>
                                        <br>
                                        <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_dinkes['id']; ?>" class="btn btn-xs btn-info">
                                            <i class="fa fa-eye"></i> Lihat Keterangan
                                        </a>
                                        <div class="modal fade" id="reasonModal<?php echo $row_dinkes['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog modal-md">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-aqua">
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title">Keterangan (Alasan)</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php echo nl2br(htmlspecialchars($row_dinkes['reason'])); ?>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if (!empty($row_dinkes['upload'])) { ?>
                                            <a href="surat/dinkes/<?php echo $row_dinkes['upload']; ?>" target="_blank" class="btn btn-xs btn-primary">
                                                <i class="fa fa-download"></i> Lihat File
                                            </a>
                                        <?php } else { ?>
                                            <span class="text-danger">Tidak ada file</span>
                                        <?php } ?>
                                    </td>
                                    <td>
                                        <center>
                                            <a type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#dinkes<?php echo $row_dinkes['id']; ?>"><i class="fa fa-check"></i></a>
                                            <div class="modal fade" id="dinkes<?php echo $row_dinkes['id']; ?>">
                                                <div class="modal-dialog modal-md">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span></button>
                                                            <center><h4 class="modal-title">Validasi Pengajuan Dinkes</h4></center>
                                                        </div>
                                                        <form role="form" method="POST" action="index.php?controller=dinkes&method=update_status" enctype="multipart/form-data">
                                                            <table width="100%" class="modal-body">
                                                                <tr>
                                                                    <td><label>Status</label></td>
                                                                    <td>
                                                                        <input type="hidden" name="id" value="<?php echo $row_dinkes['id']; ?>">
                                                                        <select class="form-control" name="status" required style="width: 100%;">
                                                                            <option value="Tidak Memenuhi Syarat">Tidak Memenuhi Syarat</option>
                                                                            <option value="Proses Di BKN">Proses Di BKN</option>
                                                                            <option value="Perbaikan Dokumen">Perbaikan Dokumen</option>
                                                                            <option value="Dokumen Tidak Lengkap">Dokumen Tidak Lengkap</option>
                                                                            <option value="Dokumen Tidak Jelas">Dokumen Tidak Jelas</option>
                                                                            <option value="Proses di BKPSDM">Proses di BKPSDM</option>
                                                                			<option value="Proses di Inpektorat">Proses di Inspektorat</option>
                                                                            <option value="Proses TTD">Proses TTD</option>
                                                                            <option value="Selesai">Selesai</option>
                                                                        </select>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label>Reason</label></td>
                                                                    <td><textarea class="form-control" name="reason" rows="5" style="width: 100%;"></textarea>
                                                                        <br><small>(Wajib diisi jika Reject berkas)</small>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label>Upload File</label></td>
                                                                    <td>
                                                                        <input type="file" name="upload_file" class="form-control">
                                                                        <small class="text-muted">Opsional, boleh dikosongkan</small>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                                                                <input type="submit" name="submit" class="btn btn-success btn-xl" value="Simpan">
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="index.php?controller=dinkes&method=delete&id=<?php echo $row_dinkes['id']; ?>" class="btn btn-danger btn-xs" onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo $row_dinkes['nama_lengkap']; ?> ?')"><i class="fa fa-trash fa-fw"></i></a>
                                        </center>
                                    </td>
                                </tr>
                                <?php $nomor++; } } ?>
                            </tbody>
                        </table>
                    <?php } elseif ($_SESSION['level_simpeg'] == 'user') { ?>
                        <form role="form" method="POST" action="index.php?controller=dinkes&method=insert_dinkes_berkas" enctype="multipart/form-data">
                            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr class="odd bg-gray">
                                        <th width="1%"><center>No</center></th>
                                        <th><center>Nama</center></th>
                                        <th><center>File</center></th>
                    					<th><center>Keterangan Upload</center></th>
                                        <th><center>Konfigurasi</center></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $nomor = 1;
                                    if (isset($data_dinkes)) {
                                        foreach ($data_dinkes as $row_dinkes) {
                                            $mb = $row_dinkes['size'] * 1024 * 1024;
                                    ?>
                                    <tr>
                                        <td><?php echo $nomor; ?></td>
                                        <td align="center"><?php echo $row_dinkes['nama']; ?><input type="hidden" name="nama_file[]" value="<?php echo $row_dinkes['nama']; ?>"></td>
                                        <td align="center">
                                            <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $mb; ?>">
                                            <input type="file" name="file[]" class="form-control" accept="<?php echo $row_dinkes['accept']; ?>">
                                        </td>
                                        <td>
    <textarea
        name="keterangan[]"
        class="form-control"
        rows="3"
        placeholder="Masukkan Nama/NIP Pegawai yang akan diusulkan"
        required
        oninvalid="this.setCustomValidity('Keterangan wajib diisi')"
        oninput="setCustomValidity('')"></textarea>
</td>
                                        <td align="center">
                                            <small class="text-danger">maks: <?php echo $row_dinkes['size']; ?> Mb</small><br>
                                            <small class="text-danger">ekstensi: <?php echo $row_dinkes['accept']; ?></small>
                                            <input type="hidden" name="size_file[]" value="<?php echo $row_dinkes['size']; ?>">
                                            <input type="hidden" name="accept_file[]" value="<?php echo $row_dinkes['accept']; ?>">
                                        </td>
                                    </tr>
                                    <?php } } ?>
                                </tbody>
                            </table>
                            <center><input type="submit" name="submit" class="btn btn-success" value="Upload Berkas"></center>
                        </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
} else {
    echo "<script>window.history.back(); </script>";
}
?>
``
