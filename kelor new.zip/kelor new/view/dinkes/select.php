<title><?php echo isset($row_data['nama']) ? htmlspecialchars($row_data['nama']) : 'Data'; ?> | Pengajuan Dinkes</title>
<?php
if (isset($_SESSION['level_simpeg']) &&
    in_array($_SESSION['level_simpeg'], ['superadmin','admin','user','koordinator'])) {
?>

<section class="content-header">
    <h1>Data Pengajuan Dinkes</h1>
    <ol class="breadcrumb">
        <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Data Pengajuan Dinkes</li>
    </ol>
</section>

<section class="content">
    <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-tambah">
            <li class="fa fa-plus"></li> Tambah Data
        </button>
        <br><br>
    <?php } ?>

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading bg-aqua">
                    <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Dinkes
                </div>
                <div class="panel-body table-responsive">
                    <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr class="odd bg-gray">
                                <th width="1%"><center>No</center></th>
                                <th><center>Nama</center></th>
                                <th><center>Size Maksimal</center></th>
                                <th><center>Ekstensi</center></th>
                                <th><center>User</center></th>
                                <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
                                    <th><center>Aksi</center></th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $nomor = 1;
                            if (isset($data_dinkes)) {
                                foreach ($data_dinkes as $row_dinkes) {
                            ?>
                            <tr class="odd gradeX">
                                <td><?php echo $nomor; ?></td>
                                <td><?php echo htmlspecialchars($row_dinkes['nama']); ?></td>
                                <td><?php echo htmlspecialchars($row_dinkes['size']); ?></td>
                                <td><?php echo htmlspecialchars($row_dinkes['accept']); ?></td>
                                <td><?php echo htmlspecialchars($row_dinkes['nama_karyawan']); ?></td>
                                <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
                                <td>
                                    <center>
                                        <a href="index.php?controller=dinkes&method=delete_dinkes&id=<?php echo $row_dinkes['id']; ?>" 
                                           class="btn btn-danger btn-xs" onClick="return confirm('Yakin hapus?')"> 
                                            <i class="fa fa-trash fa-fw"></i>
                                        </a>
                                    </center>
                                </td>
                                <?php } ?>
                            </tr>
                            <?php $nomor++; } } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
<!-- Modal Tambah Data -->
<div class="modal fade" id="modal-tambah">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-aqua">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center">Tambah Data Pengajuan Dinkes</h4>
            </div>
            <form method="POST" action="index.php?controller=dinkes&method=insert_dinkes" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nama <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama" required>
                    </div>
                    <div class="form-group">
                        <label>Size (Mb) <span class="text-danger">*</span></label>
                        <input type="number" name="size" class="form-control" placeholder="Size" required>
                    </div>
                    <div class="form-group">
                        <label>Ekstensi <span class="text-danger">*</span></label>
                        <select name="ekstensi[]" class="form-control select2" multiple required style="width:100%;">
                            <option value=".pdf">PDF</option>
                            <option value="image/*">Image (PNG, JPG, JPEG)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>User <span class="text-danger">*</span></label>
                        <select name="nip" class="form-control select2" required style="width:100%;">
                            <option value="" disabled>- Pilih NIP -</option>
                            <?php
                            include("config/koneksi.php");
                            $query_status = "SELECT * FROM pegawai";
                            $status = mysqli_query($koneksi, $query_status);
                            while ($row_status = mysqli_fetch_array($status)) {
                                echo "<option value='{$row_status['nip']}'>{$row_status['nip']} - {$row_status['nama']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>
            </form>
        </div>
    </div>
</div>
<?php } ?>

<?php
} else {
    echo "<script>window.history.back();</script>";
}
?>
