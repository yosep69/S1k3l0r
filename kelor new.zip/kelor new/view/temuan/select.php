<title>Pengajuan Temuan</title>
<?php
if (isset($_SESSION['level_simpeg']) && 
   ($_SESSION['level_simpeg'] === "admin" || $_SESSION['level_simpeg'] === "superadmin")) {
?>

  <!-- Header -->
  <section class="content-header">
    <h1>Data Pengajuan Temuan</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Temuan</li>
    </ol>
  </section>

  <!-- Konten -->
  <section class="content">
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-tambah">
      <i class="fa fa-plus"></i> Tambah Data
    </button>
    <br><br>

    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Temuan
          </div>

          <div class="panel-body table-responsive">
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%"><center>No</center></th>
                  <th><center>Nama</center></th>
                  <th><center>Size Maksimal</center></th>
                  <th><center>Ekstensi</center></th>
                  <th><center>User</center></th>
                  <th><center>Aksi</center></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $nomor = 1;
                if (!empty($data_temuan) && mysqli_num_rows($data_temuan) > 0) {
                  while ($row_temuan = mysqli_fetch_assoc($data_temuan)) {
                ?>
                    <tr>
                      <td><?php echo $nomor++; ?></td>
                      <td><?php echo htmlspecialchars($row_temuan['nama']); ?></td>
                      <td><?php echo htmlspecialchars($row_temuan['size']); ?> MB</td>
                      <td><?php echo htmlspecialchars($row_temuan['accept']); ?></td>
                      <td><?php echo htmlspecialchars($row_temuan['nama_karyawan']); ?></td>
                      <td>
                        <center>
                          <a href="index.php?controller=temuan&method=delete_temuan&id=<?php echo (int)$row_temuan['id']; ?>" 
                             class="btn btn-danger btn-xs" data-toggle="tooltip" title="Delete"
                             onClick="return confirm('Yakin ingin menghapus data ini?')">
                            <i class="fa fa-trash fa-fw"></i>
                          </a>
                        </center>
                      </td>
                    </tr>
                <?php
                  }
                } else {
                  echo '<tr><td colspan="6" align="center">Tidak ada data konfigurasi temuan</td></tr>';
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Modal Tambah Data -->
  <div class="modal fade" id="modal-tambah">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST" action="index.php?controller=temuan&method=insert_temuan">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Tambah Data Pengajuan Temuan</h4>
          </div>

          <div class="modal-body">
            <div class="form-group">
              <label>Nama <span class="text-danger">*</span></label>
              <input type="text" name="nama" class="form-control" placeholder="Nama" required>
            </div>

            <div class="form-group">
              <label>Size (MB) <span class="text-danger">*</span></label>
              <input type="number" name="size" class="form-control" placeholder="Size" required>
            </div>
            <tr>
            <td>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Ekstensi <span class="text-danger">*</span></label>
                  </div>
                </div>
              </td>
              <td>
                <div class="modal-body">
                  <select name="ekstensi[]" id="ekstensi" class="form-control select2" multiple="true" required style="width: 100%;">
                    <option value="" disabled>Pilih Ekstensi</option>
                    <option value=".pdf">PDF</option>
                    <option value="image/*">Image (PNG, JPG, JPEG)</option>
                  </select>
                </div>
              </td>
              </tr
            <tr>
            <div class="form-group">
              <label>User <span class="text-danger">*</span></label>
              <select name="nip" id="nip" class="form-control select2" style="width: 100%;" required>
                    <option value="" disabled>- Pilih NIP -</option>
                    <?php
                    include("config/koneksi.php");
                    $query_status = "SELECT * FROM pegawai";
                    $status = mysqli_query($koneksi, $query_status);
                    while ($row_status = mysqli_fetch_array($status)) {
                      echo "<option value='$row_status[nip]'>$row_status[nip] - $row_status[nama]</option>";
                    }
                    ?>
                  </select>
            </div>
            </tr>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php
} else {
  echo "<script>window.history.back();</script>";
}
?>
