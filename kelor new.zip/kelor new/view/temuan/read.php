<title><?php echo isset($row_data['nama']) ? htmlspecialchars($row_data['nama']) : 'Data'; ?> | Pengajuan Temuan</title> 
<?php
if (isset($_SESSION['level_simpeg']) && 
   ($_SESSION['level_simpeg'] === "admin" || 
    $_SESSION['level_simpeg'] === "superadmin" || 
    $_SESSION['level_simpeg'] === "user")) {
?>
  <!-- Header Halaman -->
  <section class="content-header">
    <h1>Data Pengajuan Temuan</h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Temuan</li>
    </ol>
  </section>

  <!-- Konten Utama -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Temuan
          </div>
          <div class="panel-body table-responsive">
            <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
              <thead>
                <tr class="odd bg-gray">
                  <th width="1%"><center>No</center></th>
                  <th><center>Pengusul</center></th>
                  <th><center>File</center></th>
				  <th><center>Keterangan</center></th>
                  <th><center>Tanggal Pengajuan</center></th>
                  <th><center>Status</center></th>
                  <th><center>Upload File</center></th>
                  <th><center>Action</center></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $nomor = 1;
                if (!empty($data_temuan) && mysqli_num_rows($data_temuan) > 0) {
                  while ($row_temuan = mysqli_fetch_assoc($data_temuan)) {
                ?>
                    <tr>
                      <td><?php echo $nomor++; ?></td>
                      <td align="center"><?php echo !empty($row_temuan['nama_lengkap']) ? htmlspecialchars($row_temuan['nama_lengkap']) : '-'; ?></td>
                      
                      <!-- Kolom File -->
                      <td align="center">
                        <?php if (!empty($row_temuan['file']) && !empty($row_temuan['nama'])) { ?>
                          <a href="upload_berkas/temuan/<?php echo rawurlencode($row_temuan['file']); ?>" target="_blank">
                            <?php echo htmlspecialchars($row_temuan['nama']); ?>
                          </a>
                        <?php } else { ?>
                          -
                        <?php } ?>
                      </td>
                      <td>
    <?php
    echo !empty($row_temuan['keterangan'])
        ? nl2br(htmlspecialchars($row_temuan['keterangan']))
        : '-';
    ?>
</td>
                      
                      <!-- Kolom Tanggal -->
                      <td align="center"><?php echo !empty($row_temuan['tanggal_pengajuan']) ? htmlspecialchars($row_temuan['tanggal_pengajuan']) : '-'; ?></td>
                      
                      <!-- Kolom Status -->
                      <td align="center">
                        <span class="badge"><?php echo !empty($row_temuan['status']) ? htmlspecialchars($row_temuan['status']) : '-'; ?></span><br>
                        <?php echo !empty($row_temuan['tanggal_approve']) ? htmlspecialchars($row_temuan['tanggal_approve']) : '-'; ?>
                        
                        <?php if (!empty($row_temuan['reason'])) { ?>
                          <br>
                          <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo (int)$row_temuan['id']; ?>" class="btn btn-xs btn-info">Lihat Alasan</a>
                          
                          <!-- Modal untuk menampilkan alasan -->
                          <div class="modal fade" id="reasonModal<?php echo (int)$row_temuan['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-md">
                              <div class="modal-content">
                                <div class="modal-header bg-aqua">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h4 class="modal-title">Keterangan (Reason)</h4>
                                </div>
                                <div class="modal-body">
                                  <?php echo nl2br(htmlspecialchars($row_temuan['reason'])); ?>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php } ?>
                      </td>
                      
                      <!-- Kolom Upload File -->
                      <td align="center">
                        <?php if (!empty($row_temuan['upload'])) { ?>
                          <a href="upload_berkas/temuan/<?php echo rawurlencode($row_temuan['upload']); ?>" target="_blank" class="btn btn-info btn-xs">
                            <i class="fa fa-download"></i> Lihat File
                          </a>
                        <?php } else { ?>
                          <span class="text-muted">Tidak ada file</span>
                        <?php } ?>
                      </td>
                      
                      <!-- Kolom Aksi -->
                      <td align="center">
                        <?php if ($row_temuan['status'] === 'Upload Berkas') { ?>
                          <a href="index.php?controller=temuan&method=delete&id=<?php echo (int)$row_temuan['id']; ?>"
                             class="btn btn-danger btn-xs" role="button" data-toggle="tooltip" data-placement="top" title="Delete"
                             onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo addslashes($row_temuan['nama_lengkap']); ?> ?')">
                            <i class="fa fa-trash fa-fw"></i>
                          </a>
                        <?php } else { ?>
                          -
                        <?php } ?>
                      </td>
                    </tr>
                <?php
                  }
                } else {
                  echo '<tr><td colspan="7" align="center">Tidak ada data pengajuan temuan tersedia</td></tr>';
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  
<?php
} else {
  echo "<script>window.history.back(); </script>";
}
?>
