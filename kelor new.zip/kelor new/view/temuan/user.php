<title><?php echo $row_data['nama']; ?> | Pengajuan Temuan</title>
<?php
if ($_SESSION['level_simpeg'] == "admin" || $_SESSION['level_simpeg'] == "superadmin" || $_SESSION['level_simpeg'] == "user") {
?>

  <!-- INI UNTUK JUDUL -->
  <section class="content-header">
    <h1>
      Data Pengajuan Temuan
    </h1>
    <ol class="breadcrumb">
      <li><a href="?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Data Pengajuan Temuan</li>
    </ol>
  </section>
  <section class="content">
    <br><br>
    <!-- INI UNTUK ISI -->
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
          <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
          <div class="panel-heading bg-aqua">
            <i class="fa fa-sitemap fa-fw"></i> Data Pengajuan Temuan
          </div>

          <!-- INI BAGIAN ISI UTAMA -->
          <div class="panel-body table-responsive">
            <?php if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') { ?>
              <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                <thead>
                  <tr class="odd bg-gray">
                    <th width="1%"><center>No</center></th>
                    <th><center>Pengusul</center></th>
                    <th><center>File</center></th>
            		<th><center>Keterangan</center></th>
                    <th><center>Tanggal Pengajuan</center></th>
                    <th><center>Status</center></th>
                    <th><center>Upload File</center></th>
                    <th><center>Validasi</center></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $nomor = 1;
                  if (isset($data_temuan)) {
                    while ($row_temuan = mysqli_fetch_array($data_temuan)) {
                  ?>
                      <tr class="odd gradeX">
                        <td><?php echo $nomor; ?></td>
                        <td align="left"><?php echo $row_temuan['nama_lengkap'] == '' ? '-' :  $row_temuan['nama_lengkap']; ?></td>
                        <td align="left"><a href="upload_berkas/temuan/<?php echo $row_temuan['file']; ?>"><?php echo $row_temuan['nama']; ?></a></td>
                        <td>
    <?php
    echo !empty($row_temuan['keterangan'])
        ? nl2br(htmlspecialchars($row_temuan['keterangan']))
        : '-';
    ?>
</td>
                        <td align="center"><?php echo $row_temuan['tanggal_pengajuan'] == '' ? '-' :  $row_temuan['tanggal_pengajuan']; ?></td>

                        <td align="center">
                          <span class="badge"><?php echo $row_temuan['status'] == '' ? '-' :  $row_temuan['status']; ?></span><br>
                          <?php echo $row_temuan['tanggal_approve'] == '' ? '-' :  $row_temuan['tanggal_approve']; ?>

                          <?php if (!empty($row_temuan['reason'])) { ?>
                            <br>
                            <a href="#" data-toggle="modal" data-target="#reasonModal<?php echo $row_temuan['id']; ?>" class="btn btn-xs btn-info">
                              <i class="fa fa-eye"></i> Lihat Keterangan
                            </a>

                            <!-- Modal Reason -->
                            <div class="modal fade" id="reasonModal<?php echo $row_temuan['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                              <div class="modal-dialog modal-md">
                                <div class="modal-content">
                                  <div class="modal-header bg-aqua">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Keterangan (Alasan)</h4>
                                  </div>
                                  <div class="modal-body">
                                    <?php echo nl2br(htmlspecialchars($row_temuan['reason'])); ?>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          <?php } ?>
                        </td>

                        <!-- Kolom Upload File -->
                        <td class="text-center">
                          <?php if (!empty($row_temuan['upload'])) { ?>
                            <a href="upload_berkas/temuan/<?php echo $row_temuan['upload']; ?>" target="_blank" class="btn btn-xs btn-primary">
                              <i class="fa fa-download"></i> Lihat File
                            </a>
                          <?php } else { ?>
                            <span class="text-danger">Tidak ada file</span>
                          <?php } ?>
                        </td>

                        <td>
                          <center>
                            <a type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#temuan<?php echo $row_temuan['id']; ?>" title="Ubah"><i class="fa fa-check"></i></a>

                            <div class="modal fade" id="temuan<?php echo $row_temuan['id']; ?>">
                              <div class="modal-dialog modal-md">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    <center><h4 class="modal-title">Validasi Pengajuan Temuan</h4></center>
                                  </div>
                                  <form role="form" method="POST" action="index.php?controller=temuan&method=update_status" enctype="multipart/form-data">
                                    <table width="100%" class="modal-body">
                                      <tr>
                                        <td><div class="modal-body"><label>Status</label></div></td>
                                        <td>
                                          <div class="modal-body">
                                            <input type="hidden" name="id" value="<?php echo $row_temuan['id']; ?>">
                                            <select class="form-control" name="status" required style="width: 100%;">
                                              <option value="Tidak Memenuhi Syarat">Tidak Memenuhi Syarat</option>
                                              <option value="Proses Di BKN">Proses Di BKN</option>
                                              <option value="Perbaikan Dokumen">Perbaikan Dokumen</option>
                                              <option value="Dokumen Tidak Lengkap">Dokumen Tidak Lengkap</option>
                                              <option value="Dokumen Tidak Jelas">Dokumen Tidak Jelas</option>
                                              <option value="Proses di BKPSDM">Proses di BKPSDM</option>
                                              <option value="Proses TTD">Proses TTD</option>
                                              <option value="Selesai">Selesai</option>
                                            </select>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td><div class="modal-body"><label>Keterangan</label></div></td>
                                        <td>
                                          <div class="modal-body">
                                            <textarea class="form-control" name="reason" rows="5" style="width: 100%;"></textarea>
                                            <br><small>(Wajib diisi jika Pengajuan Belum Selesai)</small>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td><div class="modal-body"><label>Upload File</label></div></td>
                                        <td>
                                          <div class="modal-body">
                                            <input type="file" name="upload_file" class="form-control">
                                            <small class="text-muted">Opsional</small>
                                          </div>
                                        </td>
                                      </tr>
                                    </table>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                                      <input type="submit" name="submit" class="btn btn-success btn-xl" value="Simpan">
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <a href="index.php?controller=temuan&method=delete&id=<?php echo $row_temuan['id']; ?>" class="btn btn-danger btn-xs" onClick="return confirm('Yakin ingin menghapus data berkas : <?php echo $row_temuan['nama_lengkap']; ?> ?')">
                              <i class="fa fa-trash fa-fw"></i>
                            </a>
                          </center>
                        </td>
                      </tr>
                  <?php
                      $nomor++;
                    }
                  }
                  ?>
                </tbody>
              </table>
            <?php } elseif ($_SESSION['level_simpeg'] == 'user') { ?>
              <form role="form" method="POST" action="index.php?controller=temuan&method=insert_temuan_berkas" enctype="multipart/form-data">
                <table width="100%" id="tabel" class="table table-striped table-bordered table-hover">
                  <thead>
                    <tr class="odd bg-gray">
                      <th><center>Nama</center></th>
                      <th><center>File</center></th>
            		  <th><center>Keterangan</center></th>
                      <th><center>Konfigurasi</center></th>
                    </tr>
                  </thead>
            
                  <tbody>
                    <?php
                    $nomor = 1;
                    if (isset($data_temuan)) {
                      while ($row_temuan = mysqli_fetch_array($data_temuan)) {
                    ?>
                        <tr class="odd gradeX">
                          <td align="center">
                            <?php echo $row_temuan['nama']; ?>
                            <input type="hidden" name="nama_file[]" value="<?php echo $row_temuan['nama']; ?>" />
                          </td>
                          <td align="center">
                            <?php $mb = $row_temuan['size'] * 1024 * 1024; ?>
                            <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $mb; ?>" />
                            <input type="file" onchange="upload_check()" name="file[]" id="file_id" class="form-control" accept="<?php echo $row_temuan['accept']; ?>" />
                          </td>
                    
                    	  <td>
    <textarea
        name="keterangan[]"
        class="form-control"
        rows="9"
        placeholder="Masukkan Nama/NIP Pegawai yang akan diusulkan"
        required
        oninvalid="this.setCustomValidity('Keterangan wajib diisi')"
        oninput="setCustomValidity('')"></textarea>
</td>
                          <td align="center">
                            <small class="text-danger">maks : <?php echo $row_temuan['size']; ?> Mb</small>
                            <input type="hidden" name="size_file[]" value="<?php echo $row_temuan['size']; ?>" />
                            <br>
                            <small class="text-danger">ekstensi : <?php echo $row_temuan['accept']; ?></small>
                            <input type="hidden" name="accept_file[]" value="<?php echo $row_temuan['accept']; ?>" />
                          </td>
                        </tr>
                    <?php
                        $nomor++;
                      }
                    }
                    ?>
                  </tbody>
                </table>
                     <p class="keterangan-template">
  <strong>Contoh Template:</strong> 
  Silakan gunakan format ini sebagai acuan upload permohonan korwil 
  <a href="files/template/korwil.pdf" download>Unduh Template</a>
</p>
  <p class="keterangan-template">
  <strong>Contoh Template:</strong> 
  Silakan gunakan format ini sebagai acuan upload permohonan bebas temuan Kecamatan & Dinas 
  <a href="files/template/dinas.pdf" download>Unduh Template</a>
</p>
                <center><input type="submit" name="submit" class="btn btn-success" value="Upload Berkas"></center>
              </form>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </section>
           

  <script>
    function upload_check() {
      var upl = document.getElementById("file_id");
      var max = document.getElementById("max_id").value;
      if (upl.files[0].size > max) {
        alert("Ukuran File Terlalu Besar");
        upl.value = "";
      }
    };
  </script>
<?php
} else {
  echo "<script>window.history.back(); </script>";
}
?>
