<?php $home = mysqli_fetch_array($data); ?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $home['nama'];?> | Login </title>

    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bootstrap/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bootstrap/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bootstrap/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="bootstrap/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="bootstrap/dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link rel="shortcut icon" href="logo/sikelor.png">

</head>
<body class="hold-transition login-page" 
  style="background: linear-gradient(to right, rgba(255, 215, 0, 0.4), rgba(0, 0, 0, 0.7)), 
         url('logo/bg21.jpg') no-repeat center center fixed;
         background-size: cover;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         color: #fff; margin: 0; padding: 0;">

<br>


<div style="max-width: 100%; margin: 0 auto;">
  <table style="width: 100%;">
    <tr>
      <td style="text-align: left; width: 30%; padding-left: 220px;">
        <img src="logo/b.png" style="max-width: 100%; height: auto; width: 120px;">
      </td>
      <td style="text-align: center; width: 40%;">
        <img src="logo/LOGO SIK.png" style="max-width: 100%; height: auto; width: 350px;">
      </td>
      <td style="text-align: right; width: 30%; padding-right: 220px;">
        <img src="logo/logo2.png" style="max-width: 100%; height: auto; width: 150px;">
      </td>
    </tr>
  </table>
</div>






<div style="text-align: center;">
  <table align="center" style="width: 100%;">
    <tr>
      <td style="text-align: center;">
        <h2 style="color: white; margin: 0;">
          <b><?php echo $home['nama']; ?><br>
          <?php echo $home['instansi']; ?></b>
        </h2>
        <br>
        <!--<p style="color: black; text-shadow: 0 0 5px white; margin: 0;">
          <b><?php echo $home['alamat']; ?></b>
        </p>-->
      </td>
    </tr>
  </table>
</div>



<div class="col-md-4 col-lg-4"></div>
<div class="col-md-4 col-lg-4">
  <!-- /.login-logo -->
  <div class="box box-info">
            <div class="box-header with-border bg-blue">
             <center> <h3 class="box-title">Form Login</h3></center>
            </div>
            <br>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" method="post" action="proses?valid=sistem&method=validasi">
  <div class="box-body" style="background-color: rgba(255, 255, 255, 0.9); border-radius: 10px; padding: 30px;">
    
    <div class="form-group">
      <label for="username" class="control-label col-sm-3" style="text-align: left;"></label>
      <div class="col-sm-9">
        <div class="input-group">
          <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
          <input type="text" name="username" id="username" class="form-control"
                 placeholder="Masukkan Username"
                 required oninvalid="this.setCustomValidity('Masukkan Username Terlebih Dahulu')"
                 oninput="setCustomValidity('')"
                 style="background-color: #f9f9f9;">
        </div>
      </div>
    </div>

    <div class="form-group">
      <label for="password" class="control-label col-sm-3" style="text-align: left;"><b>Password</b></label>
      <div class="col-sm-9">
        <div class="input-group">
          <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
          <input type="password" name="password" id="password" class="form-control"
                 placeholder="Masukkan Password"
                 required oninvalid="this.setCustomValidity('Masukkan Password Terlebih Dahulu')"
                 oninput="setCustomValidity('')"
                 style="background-color: #f9f9f9;">
        </div>
      </div>
    </div>

    <div class="form-group text-center" style="margin-top: 20px;">
      <button type="submit" class="btn btn-primary btn-block" style="width: 50%; margin: 0 auto;">Masuk</button>
      <hr>
      <!-- <a href="daftar/" class="pull-left">Buat Akun</a>-->
      <a href="lost/" class="text-center">Lupa Password?</a>
    </div>

  </div>
</form>


          </div>
  <!-- /.login-box-body -->
  <div class="text-center" style="color: white; margin-top: 30px;">
  <p>
    Copyright © <?php echo $home['nama']; ?> - <?php echo $home['instansi']; ?> <br>
    <small>
      <?php 
        $a = 2020;
        $b = date('Y');
        echo ($b == $a) ? "2020" : "2023 - $b";
      ?>
    </small>
  </p>
</div>
</div>
<!-- /.login-box -->


<!-- jQuery 3 -->
<script src="bootstrap/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
</html>
