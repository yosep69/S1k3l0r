<title><?php echo $row_data['nama'];?> | Detail Gaji</title>
<?php
if ($_SESSION['level_simpeg']=="admin" || $_SESSION['level_simpeg'] == 'superadmin') {
?>
<?php
date_default_timezone_set('Asia/Jakarta');
    $tahun=$_GET['y'];
    $bulan=$_GET['m'];
    $row_pegawai  = mysqli_fetch_array($data_pegawai);
    $row_gaji  = mysqli_fetch_array($data_gaji);
?>
            <!-- INI UNTUK JUDUL -->
            <section class="content-header">
              <h1>
                Data Detail Gaji 
              </h1>
              <ol class="breadcrumb">
                <li><a href="index.php?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="index.php?controller=tpp&method=select"> Data TPP</a></li>
                <li class="active">Data Detail</li>
              </ol>
            </section>

            <section class="content">
             <a href="index.php?controller=tpp&method=select" class="btn btn-md btn-success" data-toggle="tooltip" data-placement="top" title="Data Pegawai"><i class="fa fa-chevron-left fa-fw"></i>Back</a>
             <br>
             <br>
            <!-- INI UNTUK ISI -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
                        <div class="panel-heading bg-aqua">
                            <i class="fa fa-money fa-fw"></i> 

                            <div class="pull-right">
                                <label class="label" style="font-size: 15px;"> Pegawai : <?php echo $row_pegawai['nama'];?>
                                </label>
                            </div>
                        </div>

                        <!-- INI BAGIAN ISI UTAMA -->
                        <div class="panel-body table-responsive">
                            <!-- INI BAGIAN TABEL -->
                            <div class="">
                                <label>Data Detail TPP Bulan ||
                             <?php
                                            if ($bulan=="01") {
                                                echo "Januari";
                                             }
                                            elseif ($bulan=="02") {
                                                echo "Februari";
                                             }
                                            elseif ($bulan=="03") {
                                                echo "Maret";
                                             }
                                            elseif ($bulan=="04") {
                                                echo "April";
                                             }
                                            elseif ($bulan=="05") {
                                                echo "Mei";
                                             }
                                            elseif ($bulan=="06") {
                                                echo "Juni";
                                             }
                                            elseif ($bulan=="07") {
                                                echo "Juli";
                                             }
                                            elseif ($bulan=="08") {
                                                echo "Agustus";
                                             }
                                            elseif ($bulan=="09") {
                                                echo "September";
                                             }
                                            elseif ($bulan=="10") {
                                                echo "Oktober";
                                             }
                                            elseif ($bulan=="11") {
                                                echo "November";
                                             }
                                            elseif ($bulan=="12") {
                                                echo "Desember";
                                             }
                                echo " / ".$tahun;?> || </label><br>
                                <label class="label" style="font-size: 15px;color: black;">NIP: <?php echo $row_pegawai['nip'];?> / <?php echo $row_pegawai['nama'];?>
                                </label>
                                <div class="pull-right">
                                <!-- <form action="laporan/slip_gaji.php" method="post" target="_blank">
                                    <input type="hidden" name="nip" value="<?php echo $row_pegawai['nip'];?>"></input>
                                    <input type="hidden" name="bulan" value="<?php echo $bulan;?>"></input>
                                    <input type="hidden" name="tahun" value="<?php echo $tahun;?>"></input>
                                    <button class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="top" title="Cetak"><i class="fa fa-print"></i></button>
                                </form> -->
                                </div>
                                <!-- <div class="pull-right" style="padding-right: 20px;">
                                    <a href="index.php?controller=gaji&method=edit&nip=<?php echo $row_pegawai['nip'];?>&id=<?php echo $row_gaji['id'];?>"  data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit fa-fw fa-fw"></i>Edit</a>
                                </div> -->
                            </div>
                <form action="index.php?controller=tpp&method=insert_data" method="post">

                <input name="nip" type="hidden" value="<?php echo $row_pegawai['nip'];?>"></input>
                <input name="tgl" type="hidden" value="<?php echo $tahun.'-'.$bulan.'-'.'01';?>"></input>
                <input name="bulan" type="hidden" value="<?php echo $bulan;?>"></input>
                <input name="tahun" type="hidden" value="<?php echo $tahun;?>"></input>
                    <table width="100%">
                        <hr>
                            <tr style="height: 30px;">
                                <td colspan="4" align="center" class="bg-success">
                                    <label>Nilai TPP</label>
                                </td>
                                <td colspan="4" class="bg-warning" align="center">
                                    <label>Potongan</label>
                                </td>
                            </tr>
                            <tr style="height: 30px;">
                                
                            </tr>
                            <!--baris 1-->
                            <tr>
                                <td width="17%">
                                    <div class="form-group">
                                    Nilai TPP
                                    </div>
                                </td>
                                <td width="3%" >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td width="30%" align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['nilai_tpp'],0,"",".");?>
                                    </div>
                                </td>
                                <td width="1%" ></td>
                                <td width="22%">
                                    <div class="form-group">
                                    Pengurangan Produktivitas
                                    </div>
                                </td>
                                <td width="3%" >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td width="23%" align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['pengurangan_produk'],0,"",".");?>
                                    </div>
                                </td>
                            </tr>
                            <!--baris 2-->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    Total Produktivitas Kerja
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                       <?php echo number_format($row_gaji['produk_kerja'],0,"",".");?>
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    Potongan Disiplin Kerja 
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['tot_peng_kerja'],0,"",".");?>
                                    </div>
                                </td>
                            </tr>
                            <!-- baris 3 -->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    Total Disiplin Kerja
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['disiplin_kerja'],0,"",".");?>
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    Pot PPH 21
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group">
                                    <?php echo number_format($row_gaji['pot_pph_21'],0,"",".");?>
                                    </div>
                                </td>
                            </tr>
                            <!-- baris 4 -->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    TPP
                                    </div>
                                </td>
                                <td >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['tpp'],0,"",".");?>
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    Pot Jamkes 1%
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group">
                                    <?php echo number_format($row_gaji['jamkes'],0,"",".");?>
                                    </div>
                                </td>
                            </tr>
                            <!-- baris 5 -->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    Kelebihan TPP
                                    </div>
                                </td>
                                <td >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['kelebihan_tpp'],0,"",".");?>
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    
                                </td>
                            </tr>
                            <tr>
                                <td colspan="8">
                                    <hr>
                                </td>
                            </tr>
                            <!-- baris 6  -->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    Jumlah Produktivitas Kerja
                                    </div>
                                </td>
                                <td >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['jml_produktivitas'],0,"",".");?>
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    Jumlah Disiplin Kerja
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group">
                                    <?php echo number_format($row_gaji['jml_disiplin'],0,"",".");?>
                                    </div>
                                </td>
                            </tr>
                            <!-- baris 6  -->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    Jumlah Sebelum PPH
                                    </div>
                                </td>
                                <td >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group input-group">
                                        <?php echo number_format($row_gaji['jml_sebelum_pph'],0,"",".");?>
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    Jumlah Setelah PPH
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group">
                                    <?php echo number_format($row_gaji['jml_setelah_pph'],0,"",".");?>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="8">
                                    <hr>
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>JUMLAH BERSIH</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td align="right" style="padding-right:10%;">
                                    <div class="form-group">
                                    <b>
                                    <?php echo number_format($row_gaji['jml_bersih'],0,"",".");?>
                                    </b>
                                    </div>
                                </td>
                            </tr>
                        </table>
                        <hr>
                        </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
    </section>

<?php 
}
else
{
    echo "<script>window.history.back(); </script>";
}
?>