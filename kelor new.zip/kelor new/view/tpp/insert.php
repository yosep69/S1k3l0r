<title><?php echo $row_data['nama'];?> | Detail Gaji</title>

<?php
date_default_timezone_set('Asia/Jakarta');
    $tahun=$_GET['y'];
    $bulan=$_GET['m'];
    $row_pegawai  = mysqli_fetch_array($data_pegawai);
?>

<?php
if ($_SESSION['level_simpeg']=="admin" || $_SESSION['level_simpeg'] == 'superadmin') {
?>
            <!-- INI UNTUK JUDUL -->
            <section class="content-header">
              <h1>
                Data Detail TPP 
              </h1>
              <ol class="breadcrumb">
                <li><a href="index.php?controller=sistem&method=home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="index.php?controller=tpp&method=select"> Data TPP</a></li>
                <li class="active">Data Detail</li>
              </ol>
            </section>

            <section class="content">
             <a href="index.php?controller=tpp&method=select" class="btn btn-md btn-success" data-toggle="tooltip" data-placement="top" title="Data Pegawai"><i class="fa fa-chevron-left fa-fw"></i>Back</a>
             <br>
             <br>
            <!-- INI UNTUK ISI -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- INI BAGIAN ISI UNTUK JUDUL TABEL -->
                        <div class="panel-heading bg-aqua">
                            <i class="fa fa-money fa-fw"></i> 

                            <div class="pull-right">
                                <label class="label" style="font-size: 15px;"> Pegawai : <?php echo $row_pegawai['nama'];?>
                                </label>
                            </div>
                        </div>

                        <!-- INI BAGIAN ISI UTAMA -->
                        <div class="panel-body table-responsive">
                            <!-- INI BAGIAN TABEL -->
                            <div class="">
                                <label>Data Detail TPP Bulan ||
                             <?php
                                            if ($bulan=="01") {
                                                echo "Januari";
                                             }
                                            elseif ($bulan=="02") {
                                                echo "Februari";
                                             }
                                            elseif ($bulan=="03") {
                                                echo "Maret";
                                             }
                                            elseif ($bulan=="04") {
                                                echo "April";
                                             }
                                            elseif ($bulan=="05") {
                                                echo "Mei";
                                             }
                                            elseif ($bulan=="06") {
                                                echo "Juni";
                                             }
                                            elseif ($bulan=="07") {
                                                echo "Juli";
                                             }
                                            elseif ($bulan=="08") {
                                                echo "Agustus";
                                             }
                                            elseif ($bulan=="09") {
                                                echo "September";
                                             }
                                            elseif ($bulan=="10") {
                                                echo "Oktober";
                                             }
                                            elseif ($bulan=="11") {
                                                echo "November";
                                             }
                                            elseif ($bulan=="12") {
                                                echo "Desember";
                                             }
                                echo " / ".$tahun;?> || </label><br>
                                <label class="label" style="font-size: 15px;color: black;">NIP: <?php echo $row_pegawai['nip'];?> / <?php echo $row_pegawai['nama'];?>
                                </label>
                            </div>
                <form action="index.php?controller=tpp&method=insert_data" method="post">

                <input name="nip" type="hidden" value="<?php echo $row_pegawai['nip'];?>"></input>
                <input name="tgl" type="hidden" value="<?php echo $tahun.'-'.$bulan.'-'.'01';?>"></input>
                <input name="bulan" type="hidden" value="<?php echo $bulan;?>"></input>
                <input name="tahun" type="hidden" value="<?php echo $tahun;?>"></input>
                    <table width="100%">
                        <hr>
                            <!--baris 1-->
                            <tr>
                            <td width="17%">
                                    <div class="form-group">
                                    Nilai TPP
                                    </div>
                                </td>
                                <td width="3%" >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td width="30%">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="nilai_tpp" id="nilai_tpp" class="form-control" placeholder="Nilai TPP" style="text-align: right;width: 70%;" min="0" onkeyup="produktivitas()">
                                    </div>
                                </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td width="17%">
                                    <div class="form-group">
                                    TPP Produktivitas Kerja
                                    </div>
                                </td>
                                <td width="3%" >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td width="30%">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="produk_kerja" id="produk_kerja" readonly class="form-control" placeholder="TPP Produktivitas Kerja" style="text-align: right;width: 70%;"  min="0">
                                    </div>
                                </td>
                                <td width="1%" ></td>
                                <td width="22%">
                                    <div class="form-group">
                                    Total Pengurangan Produktivitas
                                    </div>
                                </td>
                                <td width="3%" >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td width="23%">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="pengurangan_produk" id="pengurangan_produk" class="form-control" placeholder="Total Pengurangan Produktivitas" onkeyup="fixValueProduktivitas();" style="text-align: right;" >
                                    </div>
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>JUMLAH TPP PRODUKTIVITAS KERJA</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="jml_produktivitas" id="jml_produktivitas" class="form-control" placeholder="JUMLAH TPP PRODUKTIVITAS KERJA" style="text-align: right;" readonly="" >
                                    </div>
                                    </div>
                                </td>
                            </tr>
                            
                            <!--baris 2-->
                            <tr>
                                <td>
                                    <div class="form-group">
                                    TPP Disiplin Kerja
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="disiplin_kerja" id="disiplin_kerja" class="form-control" placeholder="TPP Disiplin Kerja" style="text-align: right;width: 70%"  > 
                                    </div>
                                </td>
                                <td ></td>
                                <td>
                                    <div class="form-group">
                                    Total Pengurangan Disiplin Kerja
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="tot_peng_kerja" id="tot_peng_kerja" class="form-control" placeholder="Total Pengurangan Disiplin Kerja" style="text-align: right;" onkeyup="fixValueDisplin();" >
                                    </div>
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>JUMLAH TPP DISIPLIN KERJA</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="jml_disiplin" id="jml_disiplin" class="form-control" placeholder="JUMLAH TPP DISIPLIN KERJA" style="text-align: right;" readonly="" >
                                    </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- baris 3 -->
                            <tr>
                                <td colspan="8">
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>TPP</b>
                                    </div>
                                </td>
                                <td >
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="tpp" id="tpp" class="form-control" placeholder="TPP" style="text-align: right;" readonly>
                                    </div>
                                    </div>
                                </td>
                                <td ></td>
                            </tr>
                            

                            <tr>
                                <td colspan="8">
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    KELEBIHAN TPP
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="kelebihan_tpp" id="kelebihan_tpp" class="form-control" placeholder="KELEBIHAN TPP" style="text-align: right;" onkeyup="kelebihan_tpp1();" >
                                    </div>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="8">
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>TOTAL TPP SEBELUM PPH</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="jml_sebelum_pph" id="jml_sebelum_pph" class="form-control" placeholder="TOTAL TPP SEBELUM PPH" style="text-align: right;" readonly >
                                    </div>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="8">
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    POT PPH 21
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="pot_pph_21" id="pot_pph_21" class="form-control" placeholder="POT PPH 21" style="text-align: right;" onkeyup="pph_21();" >
                                    </div>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>TOTAL TPP SETELAH PPH</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="jml_setelah_pph" id="jml_setelah_pph" class="form-control" placeholder="TOTAL TPP SETELAH PPH" style="text-align: right;" readonly >
                                    </div>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="8">
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    Potongan Jamkes 1%
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="jamkes" id="jamkes" class="form-control" placeholder="Potongan Jamkes 1%" style="text-align: right;" readonly="" >
                                    </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="8">
                                </td>
                            </tr>
                            <!-- <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>POTONGAN</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="potongan" id="potongan" class="form-control" placeholder="POTONGAN" onkeypress="return angka(event);" style="text-align: right;" readonly="" >
                                    </div>
                                    </div>
                                </td>
                            </tr> -->
                            <tr>
                                <td colspan="8">
                                    <hr>
                                </td>
                            </tr>
                            <tr><td colspan="4"></td>
                                <td>
                                    <div class="form-group">
                                    <b>TPP BERSIH</b>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    :
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">Rp</span>
                                        <input name="jml_bersih" id="jml_bersih" class="form-control" placeholder="TPP Bersih"  style="text-align: right;" readonly="" >
                                    </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                        <hr>
                        <div>
                            
                            <button class="btn btn-primary btn-md pull-right"><i class="fa fa-download fa-fw"></i> Simpan</button>
                            <a href="index.php?controller=tpp&method=select" class="btn btn-success btn-md pull-left"><i class="fa fa-close fa-fw"></i>Batal</a>

                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
    </section>
<script type="text/javascript">
  function angka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
</script>


<script type="text/javascript">
        
    /* Tunjangan */
    //gaji pokok
    var produk_kerja = document.getElementById('produk_kerja');
    produk_kerja.addEventListener('keyup', function(e)
    {
        produk_kerja.value = formatRupiah(this.value);
    });
    //disiplin_kerja
    var disiplin_kerja = document.getElementById('disiplin_kerja');
    disiplin_kerja.addEventListener('keyup', function(e)
    {
        disiplin_kerja.value = formatRupiah(this.value);
    });
    //pot_pph_21
    var pot_pph_21 = document.getElementById('pot_pph_21');
    pot_pph_21.addEventListener('keyup', function(e)
    {
        pot_pph_21.value = formatRupiah(this.value);
    });
    //jamkes
    var jamkes = document.getElementById('jamkes');
    jamkes.addEventListener('keyup', function(e)
    {
        jamkes.value = formatRupiah(this.value);
    });
    //tunj Kusus
    var nilai_tpp = document.getElementById('nilai_tpp');
    nilai_tpp.addEventListener('keyup', function(e)
    {
        nilai_tpp.value = formatRupiah(this.value);
    });
    //jml bersih
    var kelebihan_tpp = document.getElementById('kelebihan_tpp');
    kelebihan_tpp.addEventListener('keyup', function(e)
    {
        kelebihan_tpp.value = formatRupiah(this.value);
    });




    /* Potongan */
    //pot pajak
    var pengurangan_produk = document.getElementById('pengurangan_produk');
    pengurangan_produk.addEventListener('keyup', function(e)
    {
        pengurangan_produk.value = formatRupiah(this.value);
    });
    //pot bpjs
    var tot_peng_kerja = document.getElementById('tot_peng_kerja');
    tot_peng_kerja.addEventListener('keyup', function(e)
    {
        tot_peng_kerja.value = formatRupiah(this.value);
    });
    
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    // menghitung nilai produktivitas kerja dan disiplin kerja
    function produktivitas()
    {
        var nilai_tpp = document.getElementById('nilai_tpp').value;
        if (nilai_tpp=="") {
            var nilai_tpp =0;
        }else{
            var nilai_tpp = parseInt(nilai_tpp.split(".").join("")); 
        }
        var produk_sum = nilai_tpp * 0.6;
        var disiplin_sum = nilai_tpp * 0.4;
        if(!isNaN(produk_sum)){
            document.getElementById('produk_kerja').value = produk_sum.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }
        if(!isNaN(disiplin_sum)){
            document.getElementById('disiplin_kerja').value = disiplin_sum.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }
    }
    // menghitung jumlah  produktivitas kerja
    function fixValueProduktivitas () {
        var pengurangan_produk = document.getElementById('pengurangan_produk').value;
        if (pengurangan_produk=="") {
            var pengurangan_produk =0;
        }else{
            var pengurangan_produk = parseInt(pengurangan_produk.split(".").join("")); 
        }

        var produk_kerja = document.getElementById('produk_kerja').value;
        if (produk_kerja=="") {
            var produk_kerja =0;
        }else{
            var produk_kerja = parseInt(produk_kerja.split(".").join("")); 
        
        }
        var totalProduktivitas = produk_kerja - (produk_kerja * pengurangan_produk / 1)
        if(!isNaN(totalProduktivitas)){
            document.getElementById('jml_produktivitas').value = totalProduktivitas.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }
    }
    // menghitung jumlah disiplin kerja
    function fixValueDisplin () {
        
        var tot_peng_kerja = document.getElementById('tot_peng_kerja').value;
        if (tot_peng_kerja=="") {
            var tot_peng_kerja =0;
        }else{
            var tot_peng_kerja = parseInt(tot_peng_kerja.split(".").join("")); 
        }

        var disiplin_kerja = document.getElementById('disiplin_kerja').value;
        if (disiplin_kerja=="") {
            var disiplin_kerja =0;
        }else{
            var disiplin_kerja = parseInt(disiplin_kerja.split(".").join("")); 
        }

        var totalDisiplin = disiplin_kerja - (disiplin_kerja * tot_peng_kerja / 1)
        if(!isNaN(totalDisiplin)){
            document.getElementById('jml_disiplin').value = totalDisiplin.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }

        // menghitung nilai TPP
        var totalProduktivitas = document.getElementById('jml_produktivitas').value;
        if (totalProduktivitas=="") {
            var totalProduktivitas =0;
        }else{
            var totalProduktivitas = parseInt(totalProduktivitas.split(".").join("")); 
        }
        var fixTPP = (totalProduktivitas + totalDisiplin)
        if(!isNaN(fixTPP)){
                document.getElementById('tpp').value = fixTPP.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }
    }
    
    // menghitung total TPP SEBELUM PPH
    function kelebihan_tpp1 () {
        var kelebihan_tpp = document.getElementById('kelebihan_tpp').value;
        if (kelebihan_tpp=="") {
            var kelebihan_tpp =0;
        }else{
            var kelebihan_tpp = parseInt(kelebihan_tpp.split(".").join("")); 
        }

        var tpp = document.getElementById('tpp').value;
        if (tpp=="") {
            var tpp =0;
        }else{
            var tpp = parseInt(tpp.split(".").join("")); 
        }

        var kelebihanTPP = (kelebihan_tpp + tpp)
        if(!isNaN(kelebihanTPP)){
            document.getElementById('jml_sebelum_pph').value = kelebihanTPP.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }

    }

    // menghitung total setelah PPH
    function pph_21 () {
        
        var jml_sebelum_pph = document.getElementById('jml_sebelum_pph').value;
        if (jml_sebelum_pph=="") {
            var jml_sebelum_pph =0;
        }else{
            var jml_sebelum_pph = parseInt(jml_sebelum_pph.split(".").join("")); 
        }
        var pot_pph_21 = document.getElementById('pot_pph_21').value;
        if (pot_pph_21=="") {
            var pot_pph_21 =0;
        }else{
            var pot_pph_21 = parseInt(pot_pph_21.split(".").join("")); 
        }
        var PPH = (jml_sebelum_pph - pot_pph_21)
        if(!isNaN(PPH)){
            document.getElementById('jml_setelah_pph').value = PPH.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }
        var potonganJamkes = PPH * 0.01
        
        if(!isNaN(potonganJamkes)){
            document.getElementById('jamkes').value = potonganJamkes.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }

        var grandTotal = (PPH - potonganJamkes)
        if(!isNaN(grandTotal)){
            document.getElementById('jml_bersih').value = grandTotal.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }
    }
    function sum()
    {
        //tunjangan
        var produk_kerja = document.getElementById('produk_kerja').value;
        var disiplin_kerja = document.getElementById('disiplin_kerja').value;
        var pot_pph_21 = document.getElementById('pot_pph_21').value;
        var jamkes = document.getElementById('jamkes').value;
        var nilai_tpp = document.getElementById('nilai_tpp').value;
        var pengurangan_produk = document.getElementById('pengurangan_produk').value;
        var tot_peng_kerja = document.getElementById('tot_peng_kerja').value;

    //gaji pokok
    if(produk_kerja=="")
    {
        var gaji = 0;
    }else{
        var gaji = parseInt(produk_kerja.split(".").join(""));
    }
    // tunjangan istri
    if(disiplin_kerja=="")
    {
        var istri =0;
    }else{
        var istri = parseInt(disiplin_kerja.split(".").join(""));
    }
    //tunjangan anak
    if (pot_pph_21=="") {
        var anak =0;
    } else{
        var anak = parseInt(pot_pph_21.split(".").join(""));
    }
    // tunjangan hselon
    if (jamkes=="") {
        var hselon =0;
    }else{
        var hselon = parseInt(jamkes.split(".").join(""));
    }
    if (nilai_tpp=="") {
        var nilai_tpp =0;
    }else{
       var nilai_tpp = parseInt(nilai_tpp.split(".").join("")); 
    }
    



    // total potongan
    //potongan pajak
    if (pengurangan_produk=="") {
        var pengurangan_produk=0;
    }else{
        var pengurangan_produk = parseInt(pengurangan_produk.split(".").join(""));
    }
    //potongan bpjs
    if (tot_peng_kerja=="") {
        var tot_peng_kerja=0;
    }else{
        var tot_peng_kerja = parseInt(tot_peng_kerja.split(".").join(""));
    }


    
    // Gaji Kotor
    // var kotor = gaji+istri+anak+hselon+fung_umum+fungsional+kusus+terpencil+tkd+beras+pajak+bpjs+jkk+jkm+pembulatan;

    // if(!isNaN(kotor)){
    //         document.getElementById('jml_kotor').value = kotor.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    //     }
    
    // Total Potongan
    // var jml_potongan = pengurangan_produk+tot_peng_kerja+pot_iwp_21+pot_iwp_81+pot_tapebum+pot_jkk+pot_jkm+hutang+bulog+sewa;

    // if(!isNaN(jml_potongan)){
    //         document.getElementById('potongan').value = jml_potongan.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    //     }

    
    // var jml_total = parseInt(kotor) - parseInt(jml_potongan);
    //     if(!isNaN(jml_total)){
    //         document.getElementById('jml_bersih').value = jml_total.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    //     }
    
    }

</script>

<?php 
}
else
{
    echo "<script>window.history.back(); </script>";
}
?>