<?php $home = mysqli_fetch_array($data); ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $home['nama'];?> | Lupa Password</title>

    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="bootstrap/css/animate.css" rel="stylesheet">
    <link href="bootstrap/css/style.css" rel="stylesheet">

    <link rel="shortcut icon" href="logo/sikelor.png">
</head>

<body class="hold-transition login-page" 
  style="background: linear-gradient(to right, rgba(255, 215, 0, 0.4), rgba(0, 0, 0, 0.7)), 
         url('logo/bg21.jpg') no-repeat center center fixed;
         background-size: cover;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         color: #fff; margin: 0; padding: 0;">

<!-- Header Logos -->
<div style="max-width: 100%; margin: 0 auto;">
  <table style="width: 100%;">
    <tr>
      <td style="text-align: left; width: 30%; padding-left: 220px;">
        <img src="logo/b.png" style="max-width: 100%; height: auto; width: 120px;">
      </td>
      <td style="text-align: center; width: 40%;">
        <img src="logo/sikelor.png" style="max-width: 100%; height: auto; width: 350px;">
      </td>
      <td style="text-align: right; width: 30%; padding-right: 220px;">
        <img src="logo/logo2.png" style="max-width: 100%; height: auto; width: 150px;">
      </td>
    </tr>
  </table>
</div>

<!-- Title -->
<div style="text-align: center; margin-top: 20px;">
  <h2 style="color: white; margin: 0;"><b><?php echo $home['nama']; ?><br><?php echo $home['instansi']; ?></b></h2>
</div>

<!-- Form Container -->
<div style="display: flex; justify-content: center; align-items: center; height: 80vh;">
  <div class="middle-box text-center loginscreen animated fadeInDown" style="width: 100%; max-width: 500px;">
    <div class="row" style="border-radius: 8px; background: teal; padding: 20px;">
      <h3 style="color: white;"><b>Lupa Password</b></h3>
      <div class="ibox-content">
        <form class="m-t" role="form" method="post" action="?controller=sistem&method=ubah_pass" onsubmit="return validasi_input(this)">
          <div class="form-group has-feedback">
            <label class="control-label text-left" style="float:left; color: white;">Username</label>
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input type="text" name="username" class="form-control" placeholder="Username"
                     required oninvalid="this.setCustomValidity('Masukan Username Terlebih Dahulu')"
                     oninput="setCustomValidity('')" autocomplete="off">
            </div>
          </div>

          <div class="form-group has-feedback">
            <label class="control-label text-left" style="float:left; color: white;">Password Baru</label>
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
              <input type="password" name="password" class="form-control" placeholder="Password"
                     required oninvalid="this.setCustomValidity('Masukan Password Terlebih Dahulu')"
                     oninput="setCustomValidity('')" autocomplete="off">
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-block">Proses</button>
          <a href="https://sikelor.parigimoutongkab.go.id/" style="display: inline-block; margin-top: 10px; color: #fff;">Kembali</a>
        </form>
      </div>
    </div>

    <!-- Footer -->
    <div class="row text-center" style="margin-top: 20px; color: white;">
      <div class="text-center">
        Copyright <?php echo $home['nama'];?><br>
        <?php echo $home['instansi'];?><br>
        <small>© 
          <?php 
            $a = 2020;
            $b = date('Y');
            echo ($b == $a) ? $a : "$a - $b";
          ?>
        </small>
      </div>
    </div>
  </div>
</div>

</body>
</html>

<script type="text/javascript">
function validasi_input(form){
  var pola_username = /^[a-zA-Z0-9_\-]{6,100}$/;
  if (!pola_username.test(form.username.value)){
    alert('Username minimal 6 karakter dan hanya boleh Huruf atau Angka!');
    form.username.focus();
    return false;
  }

  var minchar = 6;
  if (form.password.value.length < minchar){
    alert("Password Minimal 6 Karakter!");
    form.password.focus();
    return false;
  }

  if (form.re_password && form.re_password.value.length < minchar){
    alert("Password Minimal 6 Karakter!");
    form.re_password.focus();
    return false;
  }

  return true;
}
</script>
