<?php
	
	// CLASS MODEL PENDUDUK
	class model_mutasi extends database {
		// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
			
		
		// METHOD
		// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
			function __construct() {
				// INSTANSIASI CLASS KONEKSI 
				parent::__construct();	

			}
			
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
			function dataSelect()
	{
		$koneksi = $this->koneksi;
		$instansi = $_SESSION['instansi'];
		
		// SQL
		if($_SESSION['level_simpeg'] == "superadmin"){
			$query			= "SELECT * FROM pegawai 
							   		ORDER BY id DESC";
		}else{
			$query			= "SELECT * FROM pegawai 
			WHERE kebangsaan = '{$instansi}'
							   		ORDER BY id DESC";
		}
		// print_r($query);exit;

		$sql			= mysqli_query($koneksi, $query);

		return $sql;
	}

		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
			function dataDetail($nip) {
				$koneksi = $this->koneksi;
				// SQL
				$query			= "SELECT * FROM pegawai WHERE nip ='$nip'";
				
				$sql			= mysqli_query($koneksi,$query);
				
				return $sql;
			}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
			function dataUpdate($nip,$pangkat,$tmt_pangkat,$gaji,$tmt_gaji,$pensiun,$tmt_pensiun,$ijasah,$tmt_ijasah) {
				$koneksi = $this->koneksi;
              	$cek = "SELECT nip FROM mutasi  WHERE nip	= '$nip'";
              	$sqlCek		= mysqli_query($koneksi,$cek);
             	$num		= mysqli_num_rows($sqlCek);

              	// CEK SQL
				if($num > 0) {
					// SQL
                    $query		= "UPDATE mutasi SET
                                    kenaikan_pangkat		= '$pangkat',
                                    tmt_kenaikan 			= '$tmt_pangkat',
                                    kenaikan_gaji 			= '$gaji',
                                    tmt_gaji				= '$tmt_gaji',
                                    pensiun 				= '$pensiun',
                                    tmt_pensiun 			= '$tmt_pensiun',
                                    ijasah 					= '$ijasah',
                                    tmt_ijasah 				= '$tmt_ijasah'
                                   WHERE nip	= '$nip'
                                   ";

                    $sql		= mysqli_query($koneksi,$query);

                    // CEK SQL
                    if($sql == TRUE) {
                        return TRUE;
                    } 
                    else {
                        return FALSE;
                    }
				} 
				else {
					// SQL
                    $query		= "INSERT INTO mutasi (kenaikan_pangkat, tmt_kenaikan, kenaikan_gaji, tmt_gaji, pensiun, tmt_pensiun, ijasah, tmt_ijasah, nip)
                    VALUES ('$pangkat', '$tmt_pangkat', '$gaji', '$tmt_gaji', '$pensiun', '$tmt_pensiun', '$ijasah', '$tmt_ijasah', '$nip')
                                   ";

                    $sql		= mysqli_query($koneksi,$query);

                    // CEK SQL
                    if($sql == TRUE) {
                        return TRUE;
                    } 
                    else {
                        return FALSE;
                    }
				}
				
			}
		
		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function dataDelete($nip) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "DELETE FROM mutasi
							   WHERE nip = '$nip'";
				
				$sql		= mysqli_query($koneksi,$query);
				$sql2		= mysqli_query($koneksi,$query2);
				$sql3		= mysqli_query($koneksi,$query3);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
				if($sql2 == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
				if($sql3 == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}

	}
?>