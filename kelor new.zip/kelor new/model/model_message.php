<?php
class model_message extends database
{

    // METHOD
    // FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
    function __construct()
    {
        // INSTANSIASI CLASS KONEKSI 
        parent::__construct();
    }

    public function send_message($sender, $receiver, $messageContent)
    {
        $query = "INSERT INTO messages (sender, receiver, message_content, sent_at) 
                  VALUES ('$sender', '$receiver', '$messageContent', NOW())";
        $result = mysqli_query($this->koneksi, $query);
        return $result;
    }

    public function get_messages($getUser)
    {
        $with = $_SESSION['kontak'];
        $query = "SELECT *
                  FROM messages
                  
              WHERE (sender = '$getUser' AND receiver = '$with')
                 OR (sender = '$with' AND receiver = '$getUser')
              ORDER BY sent_at ASC";

        $result = mysqli_query($this->koneksi, $query);

        if (!$result) {
            die("Error in executing query: " . mysqli_error($this->koneksi));
        }
        $conversations = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $conversation = array(
                    'message_id' => $row['message_id'],
                    'sender' => $row['sender'],
                    'receiver' => $row['receiver'],
                    'message_content' => $row['message_content'],
                    'sent_at' => $row['sent_at']
                );
                $conversations[] = $conversation;
            }
        }

        return $conversations;
    }

    public function get_messages_list($getUser)
    {
        $query = "SELECT m.*
          FROM messages m
          INNER JOIN (
              SELECT IF(sender = '$getUser', receiver, sender) AS correspondent, MAX(sent_at) AS max_sent_at
              FROM messages
              WHERE sender = '$getUser' OR receiver = '$getUser'
              GROUP BY correspondent
          ) t ON (m.sender = '$getUser' AND m.receiver = t.correspondent) OR (m.sender = t.correspondent AND m.receiver = '$getUser')
          WHERE m.sent_at = t.max_sent_at
          ORDER BY m.sent_at DESC";


        $result = mysqli_query($this->koneksi, $query);

        if (!$result) {
            die("Error in executing query: " . mysqli_error($this->koneksi));
        }
        $conversations = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $conversation = array(
                    'message_id' => $row['message_id'],
                    'sender' => $row['sender'],
                    'receiver' => $row['receiver'],
                    'message_content' => $row['message_content'],
                    'sent_at' => $row['sent_at']
                );
                $conversations[] = $conversation;
            }
        }

        return $conversations;
    }

    public function getPenerima($with)
    {
        
		$query = "SELECT * FROM user WHERE username = '$with'";
        $sql= mysqli_query($this->koneksi, $query);

		return $sql;
    }
}
