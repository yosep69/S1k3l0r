<?php
	
	// CLASS MODEL PENDUDUK
	class model_kategori extends database {
		// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
			
		
		// METHOD
		// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
			function __construct() {
				// INSTANSIASI CLASS KONEKSI 
				parent::__construct();	

			}
			
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
			function dataPangkat() {
				$koneksi = $this->koneksi;
				// SQL
				$query			= "SELECT * FROM jabatan WHERE jenis ='pangkat'";
				
				$sql			= mysqli_query($koneksi,$query);
				
				return $sql;
			}
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataInstansi() {
			$koneksi = $this->koneksi;
			// SQL
			$query			= "SELECT * FROM instansi";
			
			$sql			= mysqli_query($koneksi,$query);
			
			return $sql;
		}

		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
		function dataInsert_Instansi($instansi) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "INSERT INTO instansi VALUES
						   (null,'$instansi')";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
		function dataUpdate_Instansi($id,$instansi) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "UPDATE instansi SET
							nama_instansi		= '$instansi'
						   WHERE id 	= '$id'
						   ";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
		function dataDeleteInstansi($id) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "DELETE FROM instansi
						   WHERE id = '$id'";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataSimpeg() {
			$koneksi = $this->koneksi;
			// SQL
			$query			= "SELECT * FROM linkSimpeg";
			
			$sql			= mysqli_query($koneksi,$query);
			
			return $sql;
		}
			
		
		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
			function dataInsert_Pangkat($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "INSERT INTO jabatan VALUES
							   (null,'$pangkat','pangkat')";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
		function dataInsert_Simpeg($nama, $link) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "INSERT INTO linkSimpeg VALUES
						   (null,'$nama','$link')";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}
			
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
			function dataUpdate_Pangkat($pangkat,$pangkat_baru) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "UPDATE jabatan SET
								nama		= '$pangkat_baru'
							   WHERE nama 	= '$pangkat'
							   ";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function dataDeletePangkat($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "DELETE FROM jabatan
							   WHERE nama = '$pangkat'";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}

		// QUERY UNTUK MENGUBAH DATA (UPDATE)
		function dataUpdate_Simpeg($id,$nama_simpeg,$link_simpeg) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "UPDATE linkSimpeg SET
							nama_simpeg		= '$nama_simpeg',
							link_simpeg		= '$link_simpeg'
						   WHERE id 	= '$id'
						   ";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
		function dataDeleteSimpeg($id) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "DELETE FROM linkSimpeg
						   WHERE id = '$id'";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}
			

		// QUERY UNTUK MENAMPILKAN DATA (SELECT) DATA JABATAN
			function dataJabatan() {
				$koneksi = $this->koneksi;
				// SQL
				$query			= "SELECT * FROM jabatan WHERE jenis ='jabatan'";
				
				$sql			= mysqli_query($koneksi,$query);
				
				return $sql;
			}
		
		
		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
			function dataInsert_Jabatan($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "INSERT INTO jabatan VALUES
							   (null,'$pangkat','jabatan')";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
			function dataUpdate_Jabatan($pangkat,$pangkat_baru) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "UPDATE jabatan SET
								nama		= '$pangkat_baru'
							   WHERE nama 	= '$pangkat'
							   ";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function dataDeleteJabatan($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "DELETE FROM jabatan
							   WHERE nama = '$pangkat'";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}

		// QUERY UNTUK MENAMPILKAN DATA (SELECT) DATA JENIS
			function dataJenis() {
				$koneksi = $this->koneksi;
				// SQL
				$query			= "SELECT * FROM jabatan WHERE jenis ='jenis'";
				
				$sql			= mysqli_query($koneksi,$query);
				
				return $sql;
			}
		
		
		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
			function dataInsert_Jenis($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "INSERT INTO jabatan VALUES
							   (null,'$pangkat','jenis')";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
			function dataUpdate_Jenis($pangkat,$pangkat_baru) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "UPDATE jabatan SET
								nama		= '$pangkat_baru'
							   WHERE nama 	= '$pangkat'
							   ";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function dataDeleteJenis($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "DELETE FROM jabatan
							   WHERE nama = '$pangkat'";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}


		// QUERY UNTUK MENAMPILKAN DATA (SELECT) DATA STATUS
			function dataStatus() {
				$koneksi = $this->koneksi;
				// SQL
				$query			= "SELECT * FROM jabatan WHERE jenis ='status'";
				
				$sql			= mysqli_query($koneksi,$query);
				
				return $sql;
			}
		
		
		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
			function dataInsert_Status($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "INSERT INTO jabatan VALUES
							   (null,'$pangkat','status')";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
			function dataUpdate_Status($pangkat,$pangkat_baru) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "UPDATE jabatan SET
								nama		= '$pangkat_baru'
							   WHERE nama 	= '$pangkat'
							   ";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
		
		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function dataDeleteStatus($pangkat) {
				$koneksi = $this->koneksi;
				// SQL
				$query		= "DELETE FROM jabatan
							   WHERE nama = '$pangkat'";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}
	}
?>