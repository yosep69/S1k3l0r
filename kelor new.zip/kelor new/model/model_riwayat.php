<?php

// CLASS MODEL RIWAYAT
class model_riwayat extends database
{
    // DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI


    // METHOD
    // FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL
    function __construct()
    {
        // INSTANSIASI CLASS KONEKSI
        parent::__construct();
    }


    public function dataInsertJabatan($nip, $jabatan, $jabatan_tmt, $keterangan, $file_sk) {
        $koneksi = $this->koneksi;

        $nip          = $koneksi->real_escape_string($nip);
        $jabatan      = $koneksi->real_escape_string($jabatan);
        $jabatan_tmt  = $koneksi->real_escape_string($jabatan_tmt);
        $keterangan   = $koneksi->real_escape_string($keterangan);
        $file_sk      = $koneksi->real_escape_string($file_sk);

        $sql = "INSERT INTO riwayat_jabatan (nip, jabatan, jabatan_tmt, keterangan, file_sk) 
                VALUES ('$nip', '$jabatan', '$jabatan_tmt', '$keterangan', '$file_sk')";

        // Debug query (optional)
        // echo "<pre>DEBUG QUERY: $sql</pre>";

        return $koneksi->query($sql);
    }

    public function dataUpdateJabatan($id, $nip, $jabatan, $jabatan_tmt, $keterangan, $file_sk) {
        $koneksi = $this->koneksi;

        $nip          = $koneksi->real_escape_string($nip);
        $jabatan      = $koneksi->real_escape_string($jabatan);
        $jabatan_tmt  = $koneksi->real_escape_string($jabatan_tmt);
        $keterangan   = $koneksi->real_escape_string($keterangan);

        $sql = "UPDATE riwayat_jabatan SET 
                    nip = '$nip',
                    jabatan = '$jabatan',
                    jabatan_tmt = '$jabatan_tmt',
                    keterangan = '$keterangan'";

        if (!empty($file_sk)) {
            $file_sk_esc = $koneksi->real_escape_string($file_sk);
            $sql .= ", file_sk = '$file_sk_esc'";
        }

        $sql .= " WHERE id = $id";

        // Debug query (optional)
        // echo "<pre>DEBUG QUERY: $sql</pre>";

        return $koneksi->query($sql);
    }




    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteJabatan($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_jabatan WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }

    // RIWAYAT BERKALA table : riwayat_berkala
// QUERY UNTUK MEMASUKKAN DATA (INSERT)
function dataInsertBerkala($nip, $jabatan, $jabatan_tmt, $keterangan, $file_sk) {
    $koneksi = $this->koneksi;

    $nip          = $koneksi->real_escape_string($nip);
    $jabatan      = $koneksi->real_escape_string($jabatan);
    $jabatan_tmt  = $koneksi->real_escape_string($jabatan_tmt);
    $keterangan   = $koneksi->real_escape_string($keterangan);
    $file_sk      = $koneksi->real_escape_string($file_sk);

    $sql = "INSERT INTO riwayat_berkala (nip, jabatan, jabatan_tmt, keterangan, file_sk) 
            VALUES ('$nip', '$jabatan', '$jabatan_tmt', '$keterangan', '$file_sk')";

    return $koneksi->query($sql);
}

// QUERY UNTUK MENGUBAH DATA (UPDATE)
function dataUpdateBerkala($id, $nip, $jabatan, $jabatan_tmt, $keterangan, $file_sk) {
    $koneksi = $this->koneksi;

    $nip          = $koneksi->real_escape_string($nip);
    $jabatan      = $koneksi->real_escape_string($jabatan);
    $jabatan_tmt  = $koneksi->real_escape_string($jabatan_tmt);
    $keterangan   = $koneksi->real_escape_string($keterangan);

    $sql = "UPDATE riwayat_berkala SET 
                nip = '$nip',
                jabatan = '$jabatan',
                jabatan_tmt = '$jabatan_tmt',
                keterangan = '$keterangan'";

    if (!empty($file_sk)) {
        $file_sk_esc = $koneksi->real_escape_string($file_sk);
        $sql .= ", file_sk = '$file_sk_esc'";
    }

    $sql .= " WHERE id = $id";

    return $koneksi->query($sql);
}

// QUERY UNTUK MENGHAPUS DATA (DELETE)
function dataDeleteBerkala($nip, $id) {
    $koneksi = $this->koneksi;
    $sql = "DELETE FROM riwayat_berkala WHERE nip='$nip' AND id=$id";
    return $koneksi->query($sql);
}






    // RIWAYAT GOLONGAN table : riwayat_golongan
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsertGolongan($nip, $id_golongan, $golongan_tmt, $keterangan, $file_sk)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "INSERT INTO riwayat_golongan (nip, id_golongan, golongan_tmt, keterangan, file_sk)
                VALUES ('$nip', '$id_golongan', '$golongan_tmt', '$keterangan', '$file_sk')";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }

    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdateGolongan($id, $nip, $id_golongan, $golongan_tmt, $keterangan, $file_sk)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "UPDATE riwayat_golongan 
                SET nip='$nip', id_golongan='$id_golongan', golongan_tmt='$golongan_tmt', keterangan='$keterangan', file_sk='$file_sk' 
                WHERE id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }

    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteGolongan($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_golongan WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }

      // RIWAYAT JABATAN table : riwayat_jabatan
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    // INSERT JABATAN
// INSERT JABATAN


   



        // RIWAYAT JABATAN table : riwayat_diklat_pimpinan
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
   function dataInsertDiklatPimpinan($nip, $nama_diklat, $tahun, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    
    // Cek koneksi
    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }
    
    // Handle NULL file_sk dengan prepared statement
    $sql = "INSERT INTO riwayat_diklat_pimpinan 
            (nip, nama_diklat, tahun, keterangan, file_sk)
            VALUES 
            (?, ?, ?, ?, ?)";

    $stmt = $koneksi->prepare($sql);
    if ($stmt === false) {
        die("Error dalam prepared statement: " . $koneksi->error);
    }
    
    // Bind parameter
    if (empty($file_sk)) {
        $stmt->bind_param("sssss", $nip, $nama_diklat, $tahun, $keterangan, $file_sk);
    } else {
        $stmt->bind_param("sssss", $nip, $nama_diklat, $tahun, $keterangan, $file_sk);
    }
    
    // Eksekusi
    $result = $stmt->execute();
    
    // Tutup statement
    $stmt->close();
    
    return $result;
}

function dataUpdateDiklatPimpinan($id, $nip, $nama_diklat, $tahun, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    
    // Cek koneksi
    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }
    
    // Gunakan prepared statement
    if (!empty($file_sk)) {
        $sql = "UPDATE riwayat_diklat_pimpinan 
                SET nip = ?, 
                    nama_diklat = ?, 
                    tahun = ?, 
                    keterangan = ?,
                    file_sk = ?
                WHERE id = ?";
    } else {
        $sql = "UPDATE riwayat_diklat_pimpinan 
                SET nip = ?, 
                    nama_diklat = ?, 
                    tahun = ?, 
                    keterangan = ?
                WHERE id = ?";
    }
    
    $stmt = $koneksi->prepare($sql);
    if ($stmt === false) {
        die("Error dalam prepared statement: " . $koneksi->error);
    }
    
    // Bind parameter
    if (!empty($file_sk)) {
        $stmt->bind_param("sssssi", $nip, $nama_diklat, $tahun, $keterangan, $file_sk, $id);
    } else {
        $stmt->bind_param("ssssi", $nip, $nama_diklat, $tahun, $keterangan, $id);
    }
    
    // Eksekusi
    $result = $stmt->execute();
    
    // Tutup statement
    $stmt->close();
    
    return $result;
}

    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteDiklatPimpinan($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_diklat_pimpinan WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }
    
    // RIWAYAT GOLONGAN table : riwayat_pendidikan
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
   function dataInsertPendidikan($nip, $nama_pendidikan, $tahun_pendidikan, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;

    $sql = "INSERT INTO riwayat_pendidikan (nip, nama_pendidikan, tahun_pendidikan, keterangan, file_sk)
            VALUES ('$nip', '$nama_pendidikan', '$tahun_pendidikan', '$keterangan', '$file_sk')";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGUBAH DATA (UPDATE)
   function dataUpdatePendidikan($id, $nip, $nama_pendidikan, $tahun_pendidikan, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    $file_sk_name = '';

    if ($file_sk['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'upload_berkas/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($file_sk["name"], PATHINFO_EXTENSION);
        $file_sk_name = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $file_sk_name;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array(strtolower($ext), $allowed)) {
            throw new Exception("Tipe file tidak didukung");
        }

        if ($file_sk['size'] > $max_size) {
            throw new Exception("Ukuran file maksimal 900KB");
        }

        if (!move_uploaded_file($file_sk["tmp_name"], $target_file)) {
            throw new Exception("Gagal upload file SK Pendidikan");
        }
    }

    $sql = "UPDATE riwayat_pendidikan 
            SET nip = '$nip', 
                nama_pendidikan = '$nama_pendidikan', 
                tahun_pendidikan = '$tahun_pendidikan',
                keterangan = '$keterangan'";

    if (!empty($file_sk_name)) {
        $sql .= ", file_sk = '$file_sk_name'";
    }

    $sql .= " WHERE id = $id";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeletePendidikan($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_pendidikan WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }


    // RIWAYAT KETERANGAN KELUARGA table : riwayat_keterangan_keluarga
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsertKeteranganKeluarga($nip, $keterangan, $no, $nama_keluarga, $file_sk)
{
    $koneksi = $this->koneksi;

    $sql = "INSERT INTO riwayat_keterangan_keluarga (nip, keterangan, no, nama_keluarga, file_sk)
            VALUES ('$nip', '$keterangan', '$no', '$nama_keluarga', '$file_sk')";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdateKeteranganKeluarga($id, $nip, $keterangan, $no, $nama_keluarga, $file_sk)
{
    $koneksi = $this->koneksi;
    $file_sk_name = '';

    if ($file_sk['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'upload_berkas/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($file_sk["name"], PATHINFO_EXTENSION);
        $file_sk_name = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $file_sk_name;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array(strtolower($ext), $allowed)) {
            throw new Exception("Tipe file tidak didukung");
        }

        if ($file_sk['size'] > $max_size) {
            throw new Exception("Ukuran file maksimal 900KB");
        }

        if (!move_uploaded_file($file_sk["tmp_name"], $target_file)) {
            throw new Exception("Gagal upload file SK");
        }
    }

    $sql = "UPDATE riwayat_keterangan_keluarga 
            SET nip = '$nip',
                keterangan = '$keterangan',
                no = '$no',
                nama_keluarga = '$nama_keluarga'";

    if (!empty($file_sk_name)) {
        $sql .= ", file_sk = '$file_sk_name'";
    }

    $sql .= " WHERE id = $id";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteKeteranganKeluarga($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_keterangan_keluarga WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }


    // RIWAYAT KURSUS table : riwayat_kursus
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsertKursus($nip, $nama_kursus, $tahun, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;

    $sql = "INSERT INTO riwayat_kursus (nip, nama_kursus, tahun, keterangan, file_sk)
            VALUES ('$nip', '$nama_kursus', $tahun, '$keterangan', '$file_sk')";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdateKursus($id, $nip, $nama_kursus, $tahun, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    $file_sk_name = '';

    if ($file_sk['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'upload_berkas/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($file_sk["name"], PATHINFO_EXTENSION);
        $file_sk_name = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $file_sk_name;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array(strtolower($ext), $allowed)) {
            throw new Exception("Tipe file tidak didukung");
        }

        if ($file_sk['size'] > $max_size) {
            throw new Exception("Ukuran file maksimal 900KB");
        }

        if (!move_uploaded_file($file_sk["tmp_name"], $target_file)) {
            throw new Exception("Gagal upload file SK Kursus");
        }
    }

    $sql = "UPDATE riwayat_kursus 
            SET nip = '$nip', 
                nama_kursus = '$nama_kursus', 
                tahun = $tahun, 
                keterangan = '$keterangan'";

    if (!empty($file_sk_name)) {
        $sql .= ", file_sk = '$file_sk_name'";
    }

    $sql .= " WHERE id = $id";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteKursus($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_kursus WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }


    // RIWAYAT PENGHARGAAN table : riwayat_penghargaan
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsertPenghargaan($nip, $jenis_penghargaan, $tahun, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;

    $sql = "INSERT INTO riwayat_penghargaan (nip, jenis_penghargaan, tahun, keterangan, file_sk)
            VALUES ('$nip', '$jenis_penghargaan', $tahun, '$keterangan', '$file_sk')";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdatePenghargaan($id, $nip, $jenis_penghargaan, $tahun, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    $file_sk_name = '';

    if ($file_sk['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'upload_berkas/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($file_sk["name"], PATHINFO_EXTENSION);
        $file_sk_name = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $file_sk_name;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array(strtolower($ext), $allowed)) {
            throw new Exception("Tipe file tidak didukung");
        }

        if ($file_sk['size'] > $max_size) {
            throw new Exception("Ukuran file maksimal 900KB");
        }

        if (!move_uploaded_file($file_sk["tmp_name"], $target_file)) {
            throw new Exception("Gagal upload file SK Penghargaan");
        }
    }

    $sql = "UPDATE riwayat_penghargaan 
            SET nip = '$nip', 
                jenis_penghargaan = '$jenis_penghargaan', 
                tahun = $tahun, 
                keterangan = '$keterangan'";

    if (!empty($file_sk_name)) {
        $sql .= ", file_sk = '$file_sk_name'";
    }

    $sql .= " WHERE id = $id";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeletePenghargaan($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_penghargaan WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }


    // RIWAYAT DP3 table : riwayat_dp3
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsertDP3($nip, $tahun, $nilai_rata_rata, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;

    // Amankan nilai input
    $nip = mysqli_real_escape_string($koneksi, $nip);
    $tahun = (int)$tahun;
    $nilai_rata_rata = mysqli_real_escape_string($koneksi, $nilai_rata_rata);
    $keterangan = mysqli_real_escape_string($koneksi, $keterangan);
    $file_sk = mysqli_real_escape_string($koneksi, $file_sk);

    $sql = "INSERT INTO riwayat_dp3 (nip, tahun, nilai_rata_rata, keterangan, file_sk)
            VALUES ('$nip', $tahun, '$nilai_rata_rata', '$keterangan', '$file_sk')";

    return $koneksi->query($sql);
}



    // QUERY UNTUK MENGUBAH DATA (UPDATE)
   function dataUpdateDP3($id, $nip, $tahun, $nilai_rata_rata, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;

    // Escape input
    $nip = mysqli_real_escape_string($koneksi, $nip);
    $tahun = (int)$tahun;
    $nilai_rata_rata = mysqli_real_escape_string($koneksi, $nilai_rata_rata);
    $keterangan = mysqli_real_escape_string($koneksi, $keterangan);

    $file_sk_name = '';

    if ($file_sk['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'upload_berkas/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($file_sk["name"], PATHINFO_EXTENSION);
        $file_sk_name = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $file_sk_name;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array(strtolower($ext), $allowed)) {
            throw new Exception("Tipe file tidak didukung");
        }

        if ($file_sk['size'] > $max_size) {
            throw new Exception("Ukuran file maksimal 900KB");
        }

        if (!move_uploaded_file($file_sk["tmp_name"], $target_file)) {
            throw new Exception("Gagal upload file SK DP3");
        }
    }

    $sql = "UPDATE riwayat_dp3 
            SET nip='$nip', 
                tahun=$tahun, 
                nilai_rata_rata='$nilai_rata_rata', 
                keterangan='$keterangan'";

    if (!empty($file_sk_name)) {
        $sql .= ", file_sk='$file_sk_name'";
    }

    $sql .= " WHERE id=" . (int)$id;

    return $koneksi->query($sql);
}



    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteDP3($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_dp3 WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }


    // RIWAYAT ANGKA KREDIT table : riwayat_angka_kredit
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)

    // INSERT DATA
    function dataInsertAngkaKredit($nip, $tanggal_sk, $ak_utama, $ak_penunjang, $ak_total, $file_sk)
    {
        $koneksi = $this->koneksi;

        // Escaping nilai untuk keamanan SQL Injection
        $nip = $koneksi->real_escape_string($nip);
        $tanggal_sk = $koneksi->real_escape_string($tanggal_sk);
        $file_sk = $koneksi->real_escape_string($file_sk);

        // SQL Query insert data + file_sk
        $sql = "INSERT INTO riwayat_angka_kredit 
                (nip, tanggal_sk, ak_utama, ak_penunjang, ak_total, file_sk)
                VALUES ('$nip', '$tanggal_sk', '$ak_utama', '$ak_penunjang', '$ak_total', '$file_sk')";

        return $koneksi->query($sql);
    }

    // UPDATE DATA
    function dataUpdateAngkaKredit($id, $nip, $tanggal_sk, $ak_utama, $ak_penunjang, $ak_total)
    {
        $koneksi = $this->koneksi;

        $nip = $koneksi->real_escape_string($nip);
        $tanggal_sk = $koneksi->real_escape_string($tanggal_sk);

        // SQL Query update data (catatan: jika ingin update file juga, tambahkan field file_sk)
        $sql = "UPDATE riwayat_angka_kredit 
                SET tanggal_sk='$tanggal_sk', ak_utama='$ak_utama', ak_penunjang='$ak_penunjang', ak_total='$ak_total' 
                WHERE id=$id AND nip='$nip'";

        return $koneksi->query($sql);
    }

    // DELETE DATA
    function dataDeleteAngkaKredit($nip, $id)
    {
        $koneksi = $this->koneksi;
        $nip = $koneksi->real_escape_string($nip);

        $sql = "DELETE FROM riwayat_angka_kredit WHERE nip='$nip' AND id=$id";

        return $koneksi->query($sql);
    }



    // RIWAYAT HUKUMAN DISIPLIN table : riwayat_hukuman_disiplin
    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
   function dataInsertHukumanDisiplin($nip, $jenis_hukuman, $tgl_hukuman, $tgl_akhir, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    $sql = "INSERT INTO riwayat_hukuman_disiplin 
            (nip, jenis_hukuman, tgl_hukuman, tgl_akhir, keterangan, file_sk)
            VALUES ('$nip', '$jenis_hukuman', '$tgl_hukuman', '$tgl_akhir', '$keterangan', '$file_sk')";

    return $koneksi->query($sql);
}

    

    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdateHukumanDisiplin($id, $nip, $jenis_hukuman, $tgl_hukuman, $tgl_akhir, $keterangan, $file_sk)
{
    $koneksi = $this->koneksi;
    $file_sk_name = '';

    if ($file_sk['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'upload_berkas/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($file_sk["name"], PATHINFO_EXTENSION);
        $file_sk_name = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $file_sk_name;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array(strtolower($ext), $allowed)) {
            throw new Exception("Tipe file tidak didukung");
        }

        if ($file_sk['size'] > $max_size) {
            throw new Exception("Ukuran file maksimal 900KB");
        }

        if (!move_uploaded_file($file_sk["tmp_name"], $target_file)) {
            throw new Exception("Gagal upload file SK Hukuman");
        }
    }

    $sql = "UPDATE riwayat_hukuman_disiplin 
            SET nip='$nip', 
                jenis_hukuman='$jenis_hukuman', 
                tgl_hukuman='$tgl_hukuman', 
                tgl_akhir='$tgl_akhir',
                keterangan='$keterangan'";

    if (!empty($file_sk_name)) {
        $sql .= ", file_sk='$file_sk_name'";
    }

    $sql .= " WHERE id=$id";

    return $koneksi->query($sql);
}


    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteHukumanDisiplin($nip, $id)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "DELETE FROM riwayat_hukuman_disiplin WHERE nip='$nip' AND id=$id";

        // Eksekusi Query
        $result = $koneksi->query($sql);

        // Return hasil eksekusi query
        return $result;
    }


    // RIWAYAT GOLONGAN table : riwayat_golongan
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatGolongan($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT rg.*, j.nama AS nama_golongan 
        FROM riwayat_golongan rg
        LEFT JOIN jabatan j ON rg.id_golongan = j.50
        WHERE rg.nip='$nip'
        ORDER BY rg.golongan_tmt ASC";


		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    // RIWAYAT PENDIDIKAN table : riwayat_pendidikan
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatPendidikan($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_pendidikan WHERE nip='$nip' ORDER BY tahun_pendidikan ASC";
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    // RIWAYAT KETERANGAN KELUARGA table : riwayat_keterangan_keluarga
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatKeteranganKeluarga($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_keterangan_keluarga WHERE nip='$nip'";

        // Eksekusi Query
        $result = $koneksi->query($sql);
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }
 
    // RIWAYAT KURSUS table : riwayat_kursus
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatKursus($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_kursus WHERE nip='$nip'";

        // Eksekusi Query
        $result = $koneksi->query($sql);
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    // RIWAYAT PENGHARGAAN table : riwayat_penghargaan
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatPenghargaan($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_penghargaan WHERE nip='$nip'";

        // Eksekusi Query
        $result = $koneksi->query($sql);
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    // RIWAYAT DP3 table : riwayat_dp3
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatDP3($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_dp3 WHERE nip='$nip'";

        // Eksekusi Query
        $result = $koneksi->query($sql);
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    // RIWAYAT ANGKA KREDIT table : riwayat_angka_kredit
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatAngkaKredit($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_angka_kredit WHERE nip='$nip' ORDER BY tanggal_sk DESC";

        // Eksekusi Query
        $result = $koneksi->query($sql);       
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    // RIWAYAT HUKUMAN DISIPLIN table : riwayat_hukuman_disiplin
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatHukumanDisiplin($nip)
    {
        $koneksi = $this->koneksi; 
        // SQL Query
        $sql = "SELECT * FROM riwayat_hukuman_disiplin WHERE nip='$nip' ORDER BY tgl_hukuman DESC";
        // Eksekusi Query
        $result = $koneksi->query($sql);
        return $result;
    }

    // RIWAYAT HUKUMAN DISIPLIN table : riwayat_hukuman_disiplin
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
   function dataRiwayatJabatan($nip)
{
    $koneksi = $this->koneksi;
    $nip = $koneksi->real_escape_string($nip);

    $sql = "SELECT 
                id,
                nip,
                jabatan,
                jabatan_tmt,
                keterangan,
                file_sk
            FROM riwayat_jabatan
            WHERE nip = '$nip'
            ORDER BY jabatan_tmt DESC, id DESC";

    $result = mysqli_query($koneksi, $sql);
    return $result;
}


   // QUERY UNTUK MENAMPILKAN DATA (SELECT)
function dataRiwayatBerkala($nip) {
    $koneksi = $this->koneksi;
    $nip = $koneksi->real_escape_string($nip);

    $sql = "SELECT * FROM riwayat_berkala WHERE nip = '$nip' ORDER BY jabatan_tmt DESC";
    return mysqli_query($koneksi, $sql);
}


    

     // RIWAYAT HUKUMAN DISIPLIN table : riwayat_diklat_pimpinan
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataRiwayatDiklatPimpinan($nip)
    {
        $koneksi = $this->koneksi;
        // SQL Query
        $sql = "SELECT * FROM riwayat_diklat_pimpinan WHERE nip='$nip' ORDER BY tahun ASC";
		$result			= mysqli_query($koneksi, $sql);
        return $result;
    }

    
    
}
