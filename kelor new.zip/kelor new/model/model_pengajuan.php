<?php
	
	// CLASS MODEL PENDUDUK
	class model_pengajuan extends database {
		// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
			
		
		// METHOD
		// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
		function __construct() {
			// INSTANSIASI CLASS KONEKSI 
			parent::__construct();	
		}
			
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataPengajuan() {
			$koneksi = $this->koneksi;
			$nip = $_SESSION['nip'];
			if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
				$query = "SELECT a.*, b.nama as nama_lengkap FROM pengajuan a LEFT JOIN pegawai b ON a.user_pengajuan = b.nip WHERE a.file != ''";
			} elseif ($_SESSION['level_simpeg'] == 'user') {
				$query = "SELECT * FROM konfigurasi WHERE nip = '{$nip}' AND jenis_pengajuan = 'pengajuan'";
			}
			
			$sql = mysqli_query($koneksi,$query);
			return $sql;
		}

		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataPengajuanKonfigurasi() {
			$koneksi = $this->koneksi;
			$query = "SELECT * FROM konfigurasi WHERE jenis_pengajuan = 'pengajuan'";
			$sql = mysqli_query($koneksi, $query);
			return $sql;
		}

		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataPengajuanUser() {
			$koneksi = $this->koneksi;
			$nip = $_SESSION['nip'];
			$query = "SELECT a.*,b.nama as nama_lengkap FROM pengajuan a LEFT JOIN pegawai b ON a.user_pengajuan = b.nip WHERE a.user_pengajuan = '{$nip}' AND a.file != ''";
			
			$sql = mysqli_query($koneksi,$query);
			return $sql;
		}

		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
		function dataInsert_Pengajuan($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan) {
			$koneksi = $this->koneksi;
			$query = "INSERT INTO konfigurasi (nama, size, accept, nama_karyawan, nip, jenis_pengajuan)
					  VALUES ('$nama', '$size', '$ekstensi', '$karyawan', '$nip', '$jenis_pengajuan')";
			$sql = mysqli_query($koneksi, $query);
			return $sql ? TRUE : FALSE;
		}

		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
		function dataInsert_PengajuanBerkas($nama_file, $size_file, $ekstensi, $filename, $nip, $tanggal, $status, $keterangan) {
			$koneksi = $this->koneksi;
			$query = "INSERT INTO pengajuan (nama,size,accept, user_pengajuan, tanggal_pengajuan, status, file, keterangan) VALUES
					  ('$nama_file','$size_file','$ekstensi','$nip','$tanggal','$status','$filename', '$keterangan')";
			$sql = mysqli_query($koneksi,$query);
			if($sql == TRUE) {
				return TRUE;
			} else {
				return FALSE;
			}
		}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE) + tambahkan upload
		function dataUpdate_Pengajuan($id,$status,$reason,$tanggal,$upload_file = null) {
			$koneksi = $this->koneksi;
			
			// Jika ada file upload, ikut diupdate
			if ($upload_file != null && $upload_file != '') {
				$query = "UPDATE pengajuan SET
							status          = '$status',
							reason          = '$reason',
							tanggal_approve = '$tanggal',
							upload          = '$upload_file'
						  WHERE id = '$id'";
			} else {
				$query = "UPDATE pengajuan SET
							status          = '$status',
							reason          = '$reason',
							tanggal_approve = '$tanggal'
						  WHERE id = '$id'";
			}
			
			$sql = mysqli_query($koneksi,$query);
			if($sql == TRUE) {
				return TRUE;
			} else {
				return FALSE;
			}
		}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
		function dataDeletePengajuan($id) {
			$koneksi = $this->koneksi;
			$query = "DELETE FROM konfigurasi
					  WHERE id = '$id'";
			$sql = mysqli_query($koneksi,$query);
			if($sql == TRUE) {
				return TRUE;
			} else {
				return FALSE;
			}
		}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
		function dataDeletePengajuanBerkas($id) {
			$koneksi = $this->koneksi;
			$query = "DELETE FROM pengajuan
					  WHERE id = '$id'";
			$sql = mysqli_query($koneksi,$query);
			if($sql == TRUE) {
				return TRUE;
			} else {
				return FALSE;
			}
		}
	}
?>
