<?php
	
	// CLASS MODEL PENDUDUK
	class model_pangkat extends database {
		// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
			
		
		// METHOD
		// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
			function __construct() {
				// INSTANSIASI CLASS KONEKSI 
				parent::__construct();	

			}
			
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataPangkat() {
			 $koneksi = $this->koneksi;
    $nip = $_SESSION['nip'];
    if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
        $query = "SELECT a.*, b.nama as nama_lengkap FROM pangkat a LEFT JOIN pegawai b ON a.user_pengajuan = b.nip WHERE a.file != ''";
    } elseif ($_SESSION['level_simpeg'] == 'user') {
        $query = "SELECT * FROM konfigurasi WHERE nip = '{$nip}' AND jenis_pengajuan = 'pangkat'";
    }
			
			$sql			= mysqli_query($koneksi,$query);
			
			return $sql;
		}
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataPangkatKonfigurasi() {
    $koneksi = $this->koneksi;
    $query = "SELECT * FROM konfigurasi WHERE jenis_pengajuan = 'pangkat'";
    $sql = mysqli_query($koneksi, $query);
    return $sql;
}
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
		function dataPangkatUser() {
			$koneksi = $this->koneksi;
			// SQL
			$nip = $_SESSION['nip'];
			$query			= "SELECT a.*,b.nama as nama_lengkap FROM pangkat a LEFT JOIN pegawai b ON a.user_pengajuan = b.nip WHERE a.user_pengajuan = '{$nip}' AND a.file != ''";
			
			$sql			= mysqli_query($koneksi,$query);
			
			return $sql;
		}

		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
		function dataInsert_Pangkat($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan) {
    $koneksi = $this->koneksi;
    $query = "INSERT INTO konfigurasi (nama, size, accept, nama_karyawan, nip, jenis_pengajuan)
              VALUES ('$nama', '$size', '$ekstensi', '$karyawan', '$nip', '$jenis_pengajuan')";
    $sql = mysqli_query($koneksi, $query);
    return $sql ? TRUE : FALSE;
}


		
		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
		function dataInsert_PangkatBerkas($nama_file, $size_file, $ekstensi, $filename, $nip, $tanggal, $status, $keterangan) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "INSERT INTO pangkat (`nama`, `size`, `accept`, `user_pengajuan`, `tanggal_pengajuan`, `status`, `file`, `keterangan`) VALUES
						   ('$nama_file','$size_file','$ekstensi','$nip','$tanggal','$status','$filename', '$keterangan')";
			$sql		= mysqli_query($koneksi,$query);
			// $sql2		= mysqli_query($koneksi,$query2);
			//echo $query;exit;
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}
		
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
		// QUERY UNTUK MENGUBAH DATA (UPDATE)
function dataUpdate_Pangkat($id,$status,$reason,$tanggal,$upload_file = null) {
    $koneksi = $this->koneksi;
    // SQL
    if ($upload_file != null && $upload_file != '') {
        $query = "UPDATE pangkat SET 
                  status = '$status',
                  reason = '$reason',
                  tanggal_approve = '$tanggal',
                  upload = '$upload_file'
                  WHERE id = '$id'";
    } else {
        $query = "UPDATE pangkat SET 
                  status = '$status',
                  reason = '$reason',
                  tanggal_approve = '$tanggal'
                  WHERE id = '$id'";
    }
    
    $sql = mysqli_query($koneksi, $query);
    
    // CEK SQL
    if($sql == TRUE) {
        return TRUE;
    } 
    else {
        return FALSE;
    }
}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
		function dataDeletePangkat($id) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "DELETE FROM konfigurasi
						   WHERE id = '$id'";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}
		// QUERY UNTUK MENGHAPUS DATA (DELETE)
		function dataDeletePangkatBerkas($id) {
			$koneksi = $this->koneksi;
			// SQL
			$query		= "DELETE FROM pangkat
						   WHERE id = '$id'";
			
			$sql		= mysqli_query($koneksi,$query);
			
			// CEK SQL
			if($sql == TRUE) {
				return TRUE;
			} 
			else {
				return FALSE;
			}
		}

	}
?>