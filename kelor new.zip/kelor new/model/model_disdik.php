<?php
// CLASS MODEL DISDIK
class model_disdik extends database {
    // CONSTRUCT
    function __construct() {
        parent::__construct();    
    }

    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataDisdik() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];

        if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
            $query = "SELECT a.*, b.nama as nama_lengkap 
                      FROM disdik a 
                      LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                      WHERE a.file != ''";
        } elseif ($_SESSION['level_simpeg'] == 'user' || $_SESSION['level_simpeg'] == 'koordinator') {
            $query = "SELECT * FROM konfigurasi 
                      WHERE nip = '{$nip}' 
                      AND jenis_pengajuan = 'disdik'";
        }

        $sql = mysqli_query($koneksi, $query);
        return $sql;
    }

    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataDisdikKonfigurasi() {
        $koneksi = $this->koneksi;
        $query = "SELECT * FROM konfigurasi WHERE jenis_pengajuan = 'disdik'";
        $sql = mysqli_query($koneksi, $query);
        return $sql;
    }

    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataDisdikUser() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];

        $query = "SELECT a.*, b.nama as nama_lengkap 
                  FROM disdik a 
                  LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                  WHERE a.user_pengajuan = '{$nip}' 
                  AND a.file != ''";

        $sql = mysqli_query($koneksi, $query);
        return $sql;
    }

    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsert_Disdik($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan) {
        $koneksi = $this->koneksi;
        $query = "INSERT INTO konfigurasi (nama, size, accept, nama_karyawan, nip, jenis_pengajuan)
                  VALUES ('$nama', '$size', '$ekstensi', '$karyawan', '$nip', '$jenis_pengajuan')";
        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsert_DisdikBerkas($nama_file, $size_file, $ekstensi, $filename, $nip, $tanggal, $status, $keterangan) {
    $koneksi = $this->koneksi;
    $query = "INSERT INTO disdik (`nama`, `size`, `accept`, `user_pengajuan`, `tanggal_pengajuan`, `status`, `file`, `keterangan`) 
              VALUES ('$nama_file','$size_file','$ekstensi','$nip','$tanggal','$status','$filename', '$keterangan')";
    
    $sql = mysqli_query($koneksi, $query);

    // Debug error jika query gagal
    if (!$sql) {
        echo "SQL Error: " . mysqli_error($koneksi) . "<br>";
        echo "Query: " . $query . "<br>";
    }

    return $sql ? TRUE : FALSE;
}


    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdate_Disdik($id, $status, $reason, $tanggal, $upload_file = null) {
        $koneksi = $this->koneksi;

        if ($upload_file != null && $upload_file != '') {
            $query = "UPDATE disdik SET
                        status = '$status',
                        reason = '$reason',
                        tanggal_approve = '$tanggal',
                        upload = '$upload_file'
                      WHERE id = '$id'";
        } else {
            $query = "UPDATE disdik SET
                        status = '$status',
                        reason = '$reason',
                        tanggal_approve = '$tanggal'
                      WHERE id = '$id'";
        }

        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteDisdik($id) {
        $koneksi = $this->koneksi;
        $query = "DELETE FROM konfigurasi WHERE id = '$id'";
        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteDisdikBerkas($id) {
        $koneksi = $this->koneksi;
        $query = "DELETE FROM disdik WHERE id = '$id'";
        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }
}
?>
