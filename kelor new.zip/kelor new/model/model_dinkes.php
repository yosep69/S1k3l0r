<?php 
// CLASS MODEL DINKES
class model_dinkes extends database {
    
    // CONSTRUCT
    function __construct() {
        parent::__construct();    
    }
    
    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataDinkes() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];
        if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
            $query = "SELECT a.*, b.nama as nama_lengkap 
                      FROM dinkes a 
                      LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                      WHERE a.file != ''";
        } elseif ($_SESSION['level_simpeg'] == 'user') {
            $query = "SELECT * FROM konfigurasi 
                      WHERE nip = '{$nip}' AND jenis_pengajuan = 'dinkes'";
        }
        
        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }
    
    function dataDinkesKonfigurasi() {
        $koneksi = $this->koneksi;
        $query = "SELECT * FROM konfigurasi WHERE jenis_pengajuan = 'dinkes'";
        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }
    
    function dataDinkesUser() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];
        $query = "SELECT a.*, b.nama as nama_lengkap 
                  FROM dinkes a 
                  LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                  WHERE a.user_pengajuan = '{$nip}' AND a.file != ''";
        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }

    function dataDinkesKoordinator() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];
        $query = "SELECT a.*, b.nama as nama_lengkap 
                  FROM dinkes a 
                  LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                  WHERE a.user_pengajuan = '{$nip}' AND a.file != ''";
        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }
    
    // QUERY UNTUK INSERT DATA KONFIGURASI
    function dataInsert_Dinkes($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan) {
        $koneksi = $this->koneksi;
        $query = "INSERT INTO konfigurasi (nama, size, accept, nama_karyawan, nip, jenis_pengajuan)
                  VALUES ('$nama', '$size', '$ekstensi', '$karyawan', '$nip', '$jenis_pengajuan')";
        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK INSERT BERKAS
    function dataInsert_DinkesBerkas($nama_file, $size_file, $ekstensi, $filename, $nip, $tanggal, $status, $keterangan) {
        $koneksi = $this->koneksi;
        $query = "INSERT INTO dinkes (`nama`, `size`, `accept`, `user_pengajuan`, `tanggal_pengajuan`, `status`, `file`, `keterangan`) VALUES
                 ('$nama_file','$size_file','$ekstensi','$nip','$tanggal','$status','$filename', '$keterangan')";
        $sql = mysqli_query($koneksi,$query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK UPDATE DATA
    function dataUpdate_Dinkes($id, $status, $reason, $tanggal, $upload_file = null) {
        $koneksi = $this->koneksi;
        
        if ($upload_file != null && $upload_file != '') {
            $query = "UPDATE dinkes SET
                        status = '$status',
                        reason = '$reason',
                        tanggal_approve = '$tanggal',
                        upload = '$upload_file'
                      WHERE id = '$id'";
        } else {
            $query = "UPDATE dinkes SET
                        status = '$status',
                        reason = '$reason',
                        tanggal_approve = '$tanggal'
                      WHERE id = '$id'";
        }
        
        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK DELETE KONFIGURASI
    function dataDeleteDinkes($id) {
        $koneksi = $this->koneksi;
        $query = "DELETE FROM konfigurasi WHERE id = '$id'";
        $sql = mysqli_query($koneksi,$query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK DELETE BERKAS
    function dataDeleteDinkesBerkas($id) {
        $koneksi = $this->koneksi;
        $query = "DELETE FROM dinkes WHERE id = '$id'";
        $sql = mysqli_query($koneksi,$query);
        return $sql ? TRUE : FALSE;
    }
}
?>
