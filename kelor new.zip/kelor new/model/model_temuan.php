<?php
// CLASS MODEL TEMUAN
class model_temuan extends database {
    // CONSTRUCTOR
    function __construct() {
        parent::__construct();    
    }

    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataTemuan() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];
        if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
            $query = "SELECT a.*, b.nama as nama_lengkap 
                      FROM temuan a 
                      LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                      WHERE a.file != ''";
        } elseif ($_SESSION['level_simpeg'] == 'user') {
            $query = "SELECT * FROM konfigurasi 
                      WHERE nip = '{$nip}' 
                      AND jenis_pengajuan = 'temuan'";
        }

        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }

    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataTemuanKonfigurasi() {
        $koneksi = $this->koneksi;
        $query = "SELECT * FROM konfigurasi WHERE jenis_pengajuan = 'temuan'";
        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }

    // QUERY UNTUK MENAMPILKAN DATA (SELECT)
    function dataTemuanUser() {
        $koneksi = $this->koneksi;
        $nip = $_SESSION['nip'];
        $query = "SELECT a.*,b.nama as nama_lengkap 
                  FROM temuan a 
                  LEFT JOIN pegawai b ON a.user_pengajuan = b.nip 
                  WHERE a.user_pengajuan = '{$nip}' AND a.file != ''";
        $sql = mysqli_query($koneksi,$query);
        return $sql;
    }

    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsert_Temuan($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan) {
        $koneksi = $this->koneksi;
        $query = "INSERT INTO konfigurasi (nama, size, accept, nama_karyawan, nip, jenis_pengajuan)
                  VALUES ('$nama', '$size', '$ekstensi', '$karyawan', '$nip', '$jenis_pengajuan')";
        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MEMASUKKAN DATA (INSERT)
    function dataInsert_TemuanBerkas($nama_file, $size_file, $ekstensi, $filename, $nip, $tanggal, $status, $keterangan) {
        $koneksi = $this->koneksi;
        $query = "INSERT INTO temuan (`nama`, `size`, `accept`, `user_pengajuan`, `tanggal_pengajuan`, `status`, `file`, `keterangan`) 
                  VALUES ('$nama_file','$size_file','$ekstensi','$nip','$tanggal','$status','$filename', '$keterangan')";
        $sql = mysqli_query($koneksi,$query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MENGUBAH DATA (UPDATE)
    function dataUpdate_Temuan($id, $status, $reason, $tanggal, $upload_file = null) {
        $koneksi = $this->koneksi;
        
        if ($upload_file != null && $upload_file != '') {
            $query = "UPDATE temuan SET
                        status = '$status',
                        reason = '$reason',
                        tanggal_approve = '$tanggal',
                        upload = '$upload_file'
                      WHERE id = '$id'";
        } else {
            $query = "UPDATE temuan SET
                        status = '$status',
                        reason = '$reason',
                        tanggal_approve = '$tanggal'
                      WHERE id = '$id'";
        }

        $sql = mysqli_query($koneksi, $query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteTemuan($id) {
        $koneksi = $this->koneksi;
        $query = "DELETE FROM konfigurasi WHERE id = '$id'";
        $sql = mysqli_query($koneksi,$query);
        return $sql ? TRUE : FALSE;
    }

    // QUERY UNTUK MENGHAPUS DATA (DELETE)
    function dataDeleteTemuanBerkas($id) {
        $koneksi = $this->koneksi;
        $query = "DELETE FROM temuan WHERE id = '$id'";
        $sql = mysqli_query($koneksi,$query);
        return $sql ? TRUE : FALSE;
    }
}
?>
