<?php
	// CLASS MODEL SISTEM
	class model_sistem extends database{
		// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
			
		
		// METHOD
		// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
			function __construct() {
				// INSTANSIASI CLASS KONEKSI 
				parent::__construct();	

			}
			
		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
			function dataHome() {
				$koneksi = $this->koneksi;

				$query		= "SELECT * FROM profil";
				
				$sql		= mysqli_query($koneksi,$query);
				
				return $sql;
			}


		// QUERY UNTUK MEMASUKKAN DATA (INSERT)
			function dataDaftar($username,$nip,$pswd,$nama,$gender) {

    $koneksi = $this->koneksi;

    $query = "INSERT INTO user
              (username,nip,password,nama,level,gender,foto,status)
              VALUES (?,?,?,?,?,?,?,?)";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    $level = 'user';
    $foto = null;
    $status = 'Aktif';

    mysqli_stmt_bind_param(
        $stmt,
        "ssssssss",
        $username,
        $nip,
        $pswd,
        $nama,
        $level,
        $gender,
        $foto,
        $status
    );

    $sql = mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    return $sql ? TRUE : FALSE;
}


		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function UpdateData($username,$nama,$password,$foto,$gender,$lokasi) {
				$koneksi = $this->koneksi;


				if(empty($foto))
				  {
					$query 	= "UPDATE user SET
								nama            = '$nama',
								gender 			= '$gender',
								password 		= '$password'
							   WHERE username	= '$username'";

					$sql		= mysqli_query($koneksi,$query);
					// CEK SQL
					if($sql == TRUE) {
						return TRUE;
					} 
					else {
						return FALSE;
					}
				  }
				else
				  {
				// SQL
					$query2  = "SELECT * FROM user WHERE username = '$username'";
					$sql2	= mysqli_query($koneksi,$query2);
					$dt  	= mysqli_fetch_array($sql2);

					
					if($dt['foto']=="")
					{
						move_uploaded_file($lokasi, "../logo/".$foto);
					}else
					  {
					  //nama field foto
						$tag		= $dt['foto'];
						// alamat folder foto
						$hapus		= "../logo/$tag";
						// script hapus gambar dari foleder
						
						unlink($hapus);
						// simpan foto baru
						move_uploaded_file($lokasi, "../logo/".$foto);
					}
					

					//SQL
					$query3 	= "UPDATE user SET
								nama            = '$nama',
								password			= '$password',
								foto 			= '$foto',
								gender 			= '$gender'
							   WHERE username	= '$username'";

					$sql3		= mysqli_query($koneksi,$query3);
					// CEK SQL
						if($sql3 == TRUE) {
							return TRUE;
						} 
						else {
							return FALSE;
						}
					}
			}

		// QUERY UNTUK MENGUBAH DATA (UPDATE)
			function dataUpdate($id,$nama_profil,$judul,$provinsi,$kota,$alamat,$foto,$lokasi,$fb,$twitter,$ig,$fotox) {
    $koneksi = $this->koneksi;

    if (empty($fotox)) {
        $query = "UPDATE profil SET
                    nama      = '$nama_profil',
                    instansi  = '$judul',
                    alamat    = '$alamat',
                    provinsi  = '$provinsi',
                    kota      = '$kota',
                    fb        = '$fb',
                    twitter   = '$twitter',
                    ig        = '$ig'
                  WHERE id = '$id'";

        $sql = mysqli_query($koneksi, $query);

        return ($sql == TRUE) ? TRUE : FALSE;
    }

    /*
     * =====================================================
     * VALIDASI FILE UPLOAD
     * =====================================================
     */

    // 1. Pastikan file benar-benar berasal dari upload PHP
    if (!is_uploaded_file($lokasi)) {
        return FALSE;
    }

    // 2. Pastikan file ada
    if (!is_file($lokasi)) {
        return FALSE;
    }

    // 3. Batas ukuran file: 2 MB
    $max_size = 2 * 1024 * 1024;

    if (filesize($lokasi) > $max_size) {
        return FALSE;
    }

    // 4. Ambil extension dari nama file
    $extension = strtolower(pathinfo($foto, PATHINFO_EXTENSION));

    // 5. Whitelist extension
    $allowed_extensions = array(
        'jpg',
        'jpeg',
        'png',
        'gif'
    );

    if (!in_array($extension, $allowed_extensions, TRUE)) {
        return FALSE;
    }

    // 6. Validasi MIME berdasarkan isi file
    if (!class_exists('finfo')) {
        return FALSE;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($lokasi);

    $allowed_mimes = array(
        'image/jpeg',
        'image/png',
        'image/gif'
    );

    if (!in_array($mime, $allowed_mimes, TRUE)) {
        return FALSE;
    }

    // 7. Pastikan benar-benar merupakan gambar
    $image_info = @getimagesize($lokasi);

    if ($image_info === FALSE) {
        return FALSE;
    }

    // 8. Pastikan MIME hasil getimagesize juga sesuai
    if (!isset($image_info['mime']) ||
        !in_array($image_info['mime'], $allowed_mimes, TRUE)) {
        return FALSE;
    }

    /*
     * =====================================================
     * BUAT NAMA FILE SERVER-SIDE
     * =====================================================
     */

    // Jangan menggunakan nama file asli pengguna.
    try {
        $random_name = bin2hex(
            openssl_random_pseudo_bytes(16)
        );
    } catch (Exception $e) {
        $random_name = sha1(
            uniqid(mt_rand(), TRUE)
        );
    }

    $id_f = $random_name . '.' . $extension;

    /*
     * =====================================================
     * DIREKTORI UPLOAD
     * =====================================================
     */

    $upload_dir = __DIR__ . '/../logo/';

    if (!is_dir($upload_dir)) {
        return FALSE;
    }

    if (!is_writable($upload_dir)) {
        return FALSE;
    }

    $target = $upload_dir . $id_f;

    /*
     * =====================================================
     * AMBIL LOGO LAMA
     * =====================================================
     */

    $query2 = "SELECT * FROM profil WHERE id = '$id' LIMIT 1";
    $sql2 = mysqli_query($koneksi, $query2);

    if (!$sql2) {
        return FALSE;
    }

    $dt = mysqli_fetch_array($sql2);

    if (!$dt) {
        return FALSE;
    }

    $old_logo = '';

    if (isset($dt['logo'])) {
        $old_logo = basename($dt['logo']);
    }

    /*
     * =====================================================
     * SIMPAN FILE BARU
     * =====================================================
     */

    if (!move_uploaded_file($lokasi, $target)) {
        return FALSE;
    }

    /*
     * =====================================================
     * UPDATE DATABASE
     * =====================================================
     */

    $query = "UPDATE profil SET
                nama      = '$nama_profil',
                instansi  = '$judul',
                alamat    = '$alamat',
                provinsi  = '$provinsi',
                kota      = '$kota',
                logo      = '$id_f',
                fb        = '$fb',
                twitter   = '$twitter',
                ig        = '$ig'
              WHERE id = '$id'";

    $sql = mysqli_query($koneksi, $query);

    /*
     * =====================================================
     * JIKA DATABASE GAGAL
     * HAPUS FILE BARU
     * =====================================================
     */

    if ($sql != TRUE) {

        if (is_file($target)) {
            unlink($target);
        }

        return FALSE;
    }

    /*
     * =====================================================
     * HAPUS LOGO LAMA SETELAH DB BERHASIL
     * =====================================================
     */

    if (!empty($old_logo)) {

        $old_file = $upload_dir . $old_logo;

        if (is_file($old_file)) {
            unlink($old_file);
        }
    }

    return TRUE;
}

		// QUERY UNTUK MELAKUKAN VALIDASI LOGIN
			function dataValidasi($username) {

    $koneksi = $this->koneksi;

    $query = "SELECT a.*, b.kebangsaan
              FROM user a
              LEFT JOIN pegawai b ON a.nip = b.nip
              WHERE a.username = ?
              AND a.status = 'Aktif'";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $username);

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $data = mysqli_fetch_array($result);

    mysqli_stmt_close($stmt);

    if ($data) {
        return $data;
    }

    return FALSE;
}

		// QUERY UNTUK MELAKUKAN VALIDASI LOGIN
			function dataValidasi_app($username) {

    $koneksi = $this->koneksi;

    $query = "SELECT *
              FROM user
              WHERE username = ?
              AND status = 'Aktif'
              AND level = 'user'";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $username);

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $data = mysqli_fetch_array($result);

    mysqli_stmt_close($stmt);

    return $data ? $data : FALSE;
}

		// QUERY UNTUK MELAKUKAN VALIDASI LOGIN
			function dataCek($username) {

    $koneksi = $this->koneksi;

    $query = "SELECT *
              FROM user
              WHERE username = ?";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $username);

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $data = mysqli_fetch_array($result);

    mysqli_stmt_close($stmt);

    return $data ? $data : FALSE;
}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function UpdateLupaPassword($username,$pswd) {

    $koneksi = $this->koneksi;

    $query = "UPDATE user
              SET password = ?
              WHERE username = ?";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "ss", $pswd, $username);

    $sql = mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    return $sql ? TRUE : FALSE;
}

		// QUERY UNTUK MENGHAPUS DATA (OFF Akun)
			function UserOff($username) {

    $koneksi = $this->koneksi;

    $query = "UPDATE user
              SET status = 'Tidak Aktif'
              WHERE username = ?";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $username);

    $sql = mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    return $sql ? TRUE : FALSE;
}
		// QUERY UNTUK MENGHAPUS DATA (OFF Akun)
			function UserOn($username) {

    $koneksi = $this->koneksi;

    $query = "UPDATE user
              SET status = 'Aktif'
              WHERE username = ?";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $username);

    $sql = mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    return $sql ? TRUE : FALSE;
}

		// QUERY UNTUK MENGHAPUS DATA (DELETE)
			function DeleteLogo() {
				$koneksi = $this->koneksi;

				$query2  = "SELECT * FROM profil";
					$sql2	= mysqli_query($koneksi,$query2);
					$dt  	= mysqli_fetch_array($sql2);

					  //nama field foto
						$tag		= $dt['logo'];
						// alamat folder foto
						$hapus		= "logo/$tag";
						// script hapus gambar dari foleder
						
						unlink($hapus);
				
				// SQL
				$query		= "UPDATE profil SET
								logo =''
								WHERE id	= '1'";
				
				$sql		= mysqli_query($koneksi,$query);
				
				// CEK SQL
				if($sql == TRUE) {
					return TRUE;
				} 
				else {
					return FALSE;
				}
			}

		// QUERY UNTUK MELAKUKAN VALIDASI LOGIN
			function dataCekNip($nip) {

    $koneksi = $this->koneksi;

    $query = "SELECT *
              FROM pegawai
              WHERE nip = ?";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $nip);

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $data = mysqli_fetch_array($result);

    mysqli_stmt_close($stmt);

    return $data ? $data : FALSE;
}

		// QUERY UNTUK MENAMPILKAN DATA (SELECT)
			function dataCekNip1($nip) {

    $koneksi = $this->koneksi;

    $query = "SELECT *
              FROM user
              WHERE nip = ?
              AND status = 'Aktif'";

    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        return FALSE;
    }

    mysqli_stmt_bind_param($stmt, "s", $nip);

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        mysqli_stmt_close($stmt);
        return FALSE;
    }

    $data = mysqli_fetch_array($result);

    mysqli_stmt_close($stmt);

    return $data ? $data : FALSE;
}
	}
?>