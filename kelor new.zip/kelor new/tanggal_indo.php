<?php
function TanggalIndo($tanggal, $cetak_hari = false)
{
    // Validasi tanggal kosong atau format aneh
    if (empty($tanggal) || $tanggal == '0000-00-00' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
        return '-';
    }

    $hari = array(
        1 => 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'
    );

    $bulan = array(
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    );

    $split = explode('-', $tanggal);

    // Cek apakah hasil explode menghasilkan 3 elemen
    if (count($split) != 3) {
        return '-';
    }

    $tahun = $split[0];
    $bulan_angka = (int)$split[1];
    $hari_tgl = (int)$split[2];

    // Validasi bulan
    if ($bulan_angka < 1 || $bulan_angka > 12) {
        return '-';
    }

    // Validasi tanggal kalender
    if (!checkdate($bulan_angka, $hari_tgl, (int)$tahun)) {
        return '-';
    }

    $tgl_indo = sprintf(
        '%02d %s %04d',
        $hari_tgl,
        $bulan[$bulan_angka],
        (int)$tahun
    );

    if ($cetak_hari) {
        $num = date('N', strtotime($tanggal));
        return $hari[$num] . ', ' . $tgl_indo;
    }

    return $tgl_indo;
}
?>