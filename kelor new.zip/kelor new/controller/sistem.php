<?php
	// INCLUDE KONEKSI DATABASE 
	include ("config/database.php");
	// INCLUDE MODEL DARI FOLDER MODEL 
	include ("model/model_sistem.php");
	include ("model/model_pegawai.php");
	include ("model/model_user.php");
    include ("vendor/autoload.php");

	// CLASS SISTEM
	class sistem {
		// PROPERTY
		// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
			public $sistem;
			public $pegawai;
			public $user;
			
		// METHOD
		// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
			function __construct() {
				// INSTANSIASI CLASS MODEL SISTEM
				$this->sistem		= new model_sistem();
				$this->pegawai		= new model_pegawai();
				$this->user			= new model_user();
				
			}

			// FUNCTION UNTUK MENANGANI PROSES LOGIN JURI
			function home() {
				// VIEW
				$data			= $this->sistem->dataHome();

				$data_pegawai   = $this->pegawai->dataSelect();
				$data_pengguna  = $this->user->dataUser();
				// MENGARAHKAN KE FILE VIEW/LOGIN.PHP

				include "view/dashboard.php";
			}

		// FUNCTION UNTUK MENANGANI PROSES LOGIN JURI
			function login() {
				// VIEW
				$data			= $this->sistem->dataHome();
				// MENGARAHKAN KE FILE VIEW/LOGIN.PHP

				include "view/login.php";
			}

		// FUNCTION UNTUK MENANGANI PROSES DAFTAR JURI
			function daftar() {
				// VIEW
				$data			= $this->sistem->dataHome();
				// MENGARAHKAN KE FILE VIEW/LOGIN.PHP

				include "view/daftar.php";
			}

		// FUNCTION UNTUK MENANGANI PROSES DAFTAR JURI
			function lost_pass() {
				// VIEW
				$data			= $this->sistem->dataHome();
				// MENGARAHKAN KE FILE VIEW/LOGIN.PHP

				include "view/lost.php";
			}

		// FUNCTION UNTUK MENANGANI PROSES DAFTAR JURI
			function pengaturan() {
				// VIEW
				$data			= $this->sistem->dataHome();
				$data_pengaturan			= $this->sistem->dataHome();

				// MENGARAHKAN KE FILE VIEW/LOGIN.PHP

				include "view/dashboard.php";
			}

		// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
			function update_data() {

    // AUTHORIZATION SERVER-SIDE
    if (!isset($_SESSION['level_simpeg']) || $_SESSION['level_simpeg'] !== 'superadmin') {
        http_response_code(403);
        exit('Akses ditolak.');
    }

    // VALIDASI ID
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

    if ($id <= 0) {
        exit('ID tidak valid.');
    }

    $nama_profil = isset($_POST['nama_profil']) ? trim($_POST['nama_profil']) : '';
    $alamat      = isset($_POST['alamat']) ? trim($_POST['alamat']) : '';
    $judul       = isset($_POST['judul']) ? trim($_POST['judul']) : '';
    $kota        = isset($_POST['kota']) ? trim($_POST['kota']) : '';
    $provinsi    = isset($_POST['provinsi']) ? trim($_POST['provinsi']) : '';
    $ig          = isset($_POST['ig']) ? trim($_POST['ig']) : '';
    $fb          = isset($_POST['fb']) ? trim($_POST['fb']) : '';
    $twitter     = isset($_POST['twitter']) ? trim($_POST['twitter']) : '';

    /*
     * Upload tetap perlu diperiksa lebih lanjut di Model.
     * Jangan mempercayai filename dari user.
     */
    $fotox = '';
    $lokasi = '';
    $foto = '';

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == UPLOAD_ERR_OK) {
        $fotox = basename($_FILES['gambar']['name']);
        $lokasi = $_FILES['gambar']['tmp_name'];

        $foto = 'ikon_' . $fotox;
    }

    $data = $this->sistem->dataUpdate(
        $id,
        $nama_profil,
        $judul,
        $provinsi,
        $kota,
        $alamat,
        $foto,
        $lokasi,
        $fb,
        $twitter,
        $ig,
        $fotox
    );

    if ($data == TRUE) {
        echo "<script>
              window.location = 'index.php?controller=sistem&method=pengaturan';
              </script>";
    } else {
        echo "<script>
              alert('Proses Update Gagal!');
              window.location = 'index.php?controller=sistem&method=pengaturan';
              </script>";
    }
}

		// FUNCTION UNTUK MENANGANI PROSES DELETE
			function hapus_logo() {

    if (!isset($_SESSION['level_simpeg']) || $_SESSION['level_simpeg'] !== 'superadmin') {
        http_response_code(403);
        exit('Akses ditolak.');
    }

    $data = $this->sistem->DeleteLogo();

    if ($data == TRUE) {
        echo "<script>
              alert('Proses Delete Berhasil!');
              window.location = 'index.php?controller=sistem&method=pengaturan';
              </script>";
    } else {
        echo "<script>
              alert('Proses Delete Gagal!');
              window.location = 'index.php?controller=sistem&method=pengaturan';
              </script>";
    }
}

		// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
			function user_daftar() {

				$options = ['cost' => 5,];
				// DARI VIEW
				// MENAMPUNG DATA YANG DIINPUTKAN
				$username			= $_POST['username'];
				$nip 				= $_POST['nip'];
				$nama				= $_POST['nama'];
				$password 			= $_POST['password'];
				$re_password 		= $_POST['re_password'];
				$gender 			= $_POST['gender'];

				
				$pswd = password_hash($password, PASSWORD_DEFAULT, $options);
				
				// DARI MODEL

				if($password != $re_password)
				{
					echo "<script> 
						  alert('Gunakan Password Yang Sama!'); 
						  window.location = 'index.php?controller=sistem&method=daftar';
						  </script>";
				}
				else
				{
				// MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
				$data			= $this->sistem->dataDaftar($username,$nip,$pswd,$nama,$gender);
				
				// DARI VIEW
				// MENGARAHKAN KE FILE VIEW/SELECT.PHP
				// JIKA HASIL PROSES INSERT BERHASIL
				if($data 		== TRUE) {
					echo "<script> 
						  alert('Proses Pendaftaran Berhasil!,Silahkan Login');
						  window.location = 'https://sikelor.parigimoutongkab.go.id/devlop'; 
						  </script>";
				
				} 
				// MENGARAHKAN KE FILE VIEW/INSERT.PHP
				// JIKA HASIL PROSES INSERT GAGAL
				else {
					echo "<script> 
						  alert('Username sudah dipakai!');
						  window.location = 'daftar'; 
						  </script>";
				}
			}
			}

			// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
			function ubah_pass() {

    $options = array('cost' => 5);

    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if ($username == '' || $password == '') {
        exit('Username dan password wajib diisi.');
    }

    if (strlen($password) < 8) {
        echo "<script>
              alert('Password minimal 8 karakter!');
              window.location = 'lost';
              </script>";
        exit;
    }

    $pswd = password_hash($password, PASSWORD_DEFAULT, $options);

    $cek = $this->sistem->dataCek($username);

    if ($cek != FALSE) {

        $data = $this->sistem->UpdateLupaPassword($username, $pswd);

        if ($data == TRUE) {
            echo "<script>
                  alert('Proses Ubah Password Berhasil!,Silahkan Login');
                  window.location = 'https://sikelor.parigimoutongkab.go.id/devlop';
                  </script>";
        } else {
            echo "<script>
                  alert('Gagal!');
                  window.location = 'https://sikelor.parigimoutongkab.go.id/devlop';
                  </script>";
        }

    } else {

        echo "<script>
              alert(" . json_encode('Username ' . $username . ' Tidak Terdaftar!') . ");
              window.location = 'lost';
              </script>";
    }
}

		// FUNCTION UNTUK MENANGANI PROSES VALIDASI LOGIN
			function validasi() {

    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if ($username == '' || $password == '') {
        echo "<script>
              alert('Username dan Password wajib diisi!');
              window.location = 'https://sikelor.parigimoutongkab.go.id/devlop';
              </script>";
        exit;
    }

    $data_valid = $this->sistem->dataValidasi($username);

    if ($data_valid != FALSE &&
        isset($data_valid['password']) &&
        password_verify($password, $data_valid['password'])) {

        // Mencegah session fixation
        session_regenerate_id(true);

        $_SESSION['nama_simpeg'] = $data_valid['nama'];
        $_SESSION['username_simpeg'] = $data_valid['username'];
        $_SESSION['level_simpeg'] = $data_valid['level'];
        $_SESSION['bagian_simpeg'] = $data_valid['level'];

        if ($data_valid['level'] == 'superadmin') {

            echo "<script>
                  window.location = 'index.php?controller=sistem&method=home';
                  </script>";

        } elseif ($data_valid['level'] == 'user') {

            echo "<script>
                  window.location = 'index.php?controller=sistem&method=home';
                  </script>";

        } else {

            echo "<script>
                  alert('Tidak Bisa Login, Hak Akses Salah!');
                  window.location = 'https://sikelor.parigimoutongkab.go.id/devlop';
                  </script>";
        }

    } else {

        echo "<script>
              alert('Proses Login Gagal! Username / Password Salah! Silakan Coba Lagi!');
              window.location = 'https://sikelor.parigimoutongkab.go.id/devlop';
              </script>";
    }
}

		// FUNCTION UNTUK MENANGANI PROSES LOGOUT
			function logout() {
				// MEMULAI SESSION
				

				
					// MENGHAPUS SESSION
					unset($_SESSION['nip']);
					unset($_SESSION['username_simpeg']);
					unset($_SESSION['nama_simpeg']);
					unset($_SESSION['level_simpeg']);
					unset($_SESSION['bagian_simpeg']);
					// MENUTUP SESSIOn
					session_destroy();
				
				
				// VIEW
				// MENGARAHKAN KE FILE VIEW/LOGIN.PHP
				echo "<script> 
					  alert('Proses Logout Berhasil!'); 
					  window.location = 'https://sikelor.parigimoutongkab.go.id/devlop'; 
					  </script>";
			}
		
	}
?>