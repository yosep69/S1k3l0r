<?php
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_riwayat.php");
include("model/model_sistem.php");


// CLASS RIWAYAT
class riwayat
{
	// PROPERTY
	// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
	public $riwayat; 
	public $sistem;

	// METHOD
	// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
	function __construct()
	{
		// INSTANSIASI CLASS MODEL RIWAYAT
		$this->riwayat	= new model_riwayat();
		$this->sistem	= new model_sistem();
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function select()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL SISTEM
		$data = $this->sistem->dataHome();

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}


// RIWAYAT JABATAN table: riwayat_jabatan
    // FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
    // INSERT
public function insert_riwayat_jabatan() {
        $nip          = $_POST['nip'];
        $jabatan      = trim($_POST['jabatan']);
        $jabatan_tmt  = $_POST['jabatan_tmt'];
        $keterangan   = $_POST['keterangan'];

        $nama_file = '';
        if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "upload_berkas/";
            if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

            $ext = strtolower(pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION));
            $nama_file = uniqid() . '.' . $ext;
            $target_file = $target_dir . $nama_file;

            $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
            $max_size = 900 * 1024;

            if (!in_array($ext, $allowed) || $_FILES['file_sk']['size'] > $max_size) {
                echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
                return;
            }
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        }

        $data = $this->riwayat->dataInsertJabatan($nip, $jabatan, $jabatan_tmt, $keterangan, $nama_file);

        if ($data) {
            echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
        } else {
            echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
        }
    }

    public function update_riwayat_jabatan() {
        $id           = $_POST['id'];
        $nip          = $_POST['nip'];
        $jabatan      = trim($_POST['jabatan']);
        $jabatan_tmt  = $_POST['jabatan_tmt'];
        $keterangan   = $_POST['keterangan'];

        $nama_file = '';
        if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "upload_berkas/riwayat_jabatan";
            if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

            $ext = strtolower(pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION));
            $nama_file = uniqid() . '.' . $ext;
            $target_file = $target_dir . $nama_file;

            $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
            $max_size = 900 * 1024;

            if (!in_array($ext, $allowed) || $_FILES['file_sk']['size'] > $max_size) {
                echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
                return;
            }
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        }

        $data = $this->riwayat->dataUpdateJabatan($id, $nip, $jabatan, $jabatan_tmt, $keterangan, $nama_file);

        if ($data) {
            echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
        } else {
            echo "<script>alert('Proses Update Gagal!'); window.history.back();</script>";
        }
    }

public function delete_riwayat_jabatan() {
    $nip = $_GET['nip'];
    $id = $_GET['id'];

    $data = $this->riwayat->dataDeleteJabatan($nip, $id);

    if ($data == TRUE) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
        exit;
    } else {
        echo "<script>alert('Proses Delete Gagal!'); window.history.back();</script>";
        exit;
    }
}

// RIWAYAT BERKALA table: riwayat_berkala
// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
public function insert_riwayat_berkala() {
    $nip          = $_POST['nip'];
    $jabatan      = trim($_POST['jabatan']);
    $jabatan_tmt  = $_POST['jabatan_tmt'];
    $keterangan   = $_POST['keterangan'];

    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

        $ext = strtolower(pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION));
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array($ext, $allowed) || $_FILES['file_sk']['size'] > $max_size) {
            echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
            return;
        }
        if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
            echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertBerkala($nip, $jabatan, $jabatan_tmt, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}

public function update_riwayat_berkala() {
    $id           = $_POST['id'];
    $nip          = $_POST['nip'];
    $jabatan      = trim($_POST['jabatan']);
    $jabatan_tmt  = $_POST['jabatan_tmt'];
    $keterangan   = $_POST['keterangan'];

    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

        $ext = strtolower(pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION));
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (!in_array($ext, $allowed) || $_FILES['file_sk']['size'] > $max_size) {
            echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
            return;
        }
        if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
            echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataUpdateBerkala($id, $nip, $jabatan, $jabatan_tmt, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Update Gagal!'); window.history.back();</script>";
    }
}

public function delete_riwayat_berkala() {
    $nip = $_GET['nip'];
    $id = $_GET['id'];

    $data = $this->riwayat->dataDeleteBerkala($nip, $id);

    if ($data == TRUE) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
        exit;
    } else {
        echo "<script>alert('Proses Delete Gagal!'); window.history.back();</script>";
        exit;
    }
}


		// RIWAYAT GOLONGAN table: riwayat_golongan
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_golongan()
{
    $nip          = $_POST['nip'];
    $id_golongan  = $_POST['id_golongan'];
    $golongan_tmt = $_POST['golongan_tmt'];
    $keterangan = $_POST['keterangan'];

    // Upload File
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) { 
    	$maxFileSize = 900 * 1024; // 900 KB dalam byte
        $fileSize = $_FILES['file_sk']['size'];

		if ($fileSize > $maxFileSize) {
            echo "<script>alert('Ukuran file tidak boleh lebih dari 900 KB!'); window.history.back();</script>";
            return;
        }

        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array(strtolower($ext), $allowed)) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung!'); window.history.back();</script>";
            return;
        }
    }

    // Simpan ke database via model
    $data = $this->riwayat->dataInsertGolongan($nip, $id_golongan, $golongan_tmt,$keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_golongan()
{
    $id           = $_POST['id'];
    $nip          = $_POST['nip'];
    $id_golongan  = $_POST['id_golongan'];
    $golongan_tmt = $_POST['golongan_tmt'];
    $keterangan   = $_POST['keterangan'];

    // Upload File
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $maxFileSize = 900 * 1024; // 900 KB dalam byte
        $fileSize = $_FILES['file_sk']['size'];

        if ($fileSize > $maxFileSize) {
            echo "<script>alert('Ukuran file tidak boleh lebih dari 900 KB!'); window.history.back();</script>";
            return;
        }

        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array(strtolower($ext), $allowed)) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung!'); window.history.back();</script>";
            return;
        }
    }

    // Simpan ke database via model
    $data = $this->riwayat->dataUpdateGolongan($id, $nip, $id_golongan, $golongan_tmt, $keterangan, $nama_file);

    if ($data) {
        echo "<script>alert('Proses Update Berhasil!'); window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Update Gagal!'); window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    }
}

	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_golongan()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteGolongan($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// RIWAYAT ANGKA KREDIT table: riwayat_angka_kredit
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_angka_kredit()
{
    $nip          = $_POST['nip'];
    $tanggal_sk   = $_POST['tanggal_sk'];
    $ak_utama     = $_POST['ak_utama'];
    $ak_penunjang = $_POST['ak_penunjang'];
    $ak_total     = $_POST['ak_total'];

    // ================================
    // PROSES UPLOAD FILE
    // ================================
    $nama_file = '';

    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/"; // pastikan folder ini ada dan bisa ditulis
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext; // agar nama file unik
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];

        if (in_array(strtolower($ext), $allowed)) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal mengupload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung!'); window.history.back();</script>";
            return;
        }
    }

    // SIMPAN KE DATABASE
    $data = $this->riwayat->dataInsertAngkaKredit($nip, $tanggal_sk, $ak_utama, $ak_penunjang, $ak_total, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_angka_kredit()
	{
		// DARI VIEW
		// MENAMPUNG DATA YANG DIINPUTKAN
		$id = $_POST['id'];
		$nip = $_POST['nip'];
		$tanggal_sk = $_POST['tanggal_sk'];
		$ak_utama = $_POST['ak_utama'];
		$ak_penunjang = $_POST['ak_penunjang'];
		$ak_total = $_POST['ak_total'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataUpdateAngkaKredit($id, $nip, $tanggal_sk, $ak_utama, $ak_penunjang, $ak_total);

		// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES UPDATE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/INSERT.PHP
		// JIKA HASIL PROSES UPDATE GAGAL
		else {
			echo "<script> 
              alert('Proses Update Gagal!');
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_angka_kredit()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteAngkaKredit($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// RIWAYAT DIKLAT PIMPINAN table: riwayat_diklat_pimpinan
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_diklat_pimpinan()
{
    // DARI VIEW
    $nip = $_POST['nip'];
    $nama_diklat = $_POST['nama_diklat'];
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'] ?? ''; // Tambahkan field keterangan

    // PROSES UPLOAD FILE
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $maxFileSize = 900 * 1024; // 900 KB dalam byte
        $fileSize = $_FILES['file_sk']['size'];

        if ($fileSize > $maxFileSize) {
            echo "<script>alert('Ukuran file tidak boleh lebih dari 900 KB!'); window.history.back();</script>";
            return;
        }

        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array(strtolower($ext), $allowed)) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung!'); window.history.back();</script>";
            return;
        }
    }

    // DARI MODEL
    $data = $this->riwayat->dataInsertDiklatPimpinan($nip, $nama_diklat, $tahun, $keterangan, $nama_file);

    // DARI VIEW
    if ($data) {
        echo "<script>
            alert('Proses Insert Berhasil!');
            window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';
        </script>";
    } else {
        echo "<script>
            alert('Proses Insert Gagal!');
            window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';
        </script>";
    }
}

function update_riwayat_diklat_pimpinan()
{
    // DARI VIEW
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $nama_diklat = $_POST['nama_diklat'];
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'] ?? ''; // Tambahkan field keterangan

    // PROSES UPLOAD FILE
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $maxFileSize = 900 * 1024; // 900 KB dalam byte
        $fileSize = $_FILES['file_sk']['size'];

        if ($fileSize > $maxFileSize) {
            echo "<script>alert('Ukuran file tidak boleh lebih dari 900 KB!'); window.history.back();</script>";
            return;
        }

        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array(strtolower($ext), $allowed)) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung!'); window.history.back();</script>";
            return;
        }
    }

    // DARI MODEL
    $data = $this->riwayat->dataUpdateDiklatPimpinan($id, $nip, $nama_diklat, $tahun, $keterangan, $nama_file);

    // DARI VIEW
    if ($data) {
        echo "<script>
            alert('Proses Update Berhasil!');
            window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';
        </script>";
    } else {
        echo "<script>
            alert('Proses Update Gagal!');
            window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';
        </script>";
    }
}

	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_diklat_pimpinan()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteDiklatPimpinan($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// RIWAYAT DP3 table: riwayat_dp3
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_dp3()
{
    $nip = $_POST['nip'];
    $tahun = $_POST['tahun'];
    $nilai_rata_rata = $_POST['nilai_rata_rata'];
    $keterangan = $_POST['keterangan'];

    // Upload file
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
          $max_size = 2 * 1024 * 1024; // 2 MB

        if (in_array(strtolower($ext), $allowed) && $_FILES['file_sk']['size'] <= $max_size) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung atau ukuran terlalu besar!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertDP3($nip, $tahun, $nilai_rata_rata, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_dp3()
{
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $tahun = $_POST['tahun'];
    $nilai_rata_rata = $_POST['nilai_rata_rata'];
    $keterangan = $_POST['keterangan'];
    $file_sk = $_FILES['file_sk'];

    try {
        $data = $this->riwayat->dataUpdateDP3($id, $nip, $tahun, $nilai_rata_rata, $keterangan, $file_sk);
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } catch (Exception $e) {
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_dp3()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteDP3($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}



	// RIWAYAT HUKUMAN DISIPLIN table: riwayat_hukuman_disiplin
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_hukuman_disiplin()
{
    $nip = $_POST['nip'];
    $jenis_hukuman = $_POST['jenis_hukuman'];
    $tgl_hukuman = $_POST['tgl_hukuman'];
    $tgl_akhir = $_POST['tgl_akhir'];
    $keterangan = $_POST['keterangan'];

    // Upload file
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (in_array(strtolower($ext), $allowed) && $_FILES['file_sk']['size'] <= $max_size) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung atau ukuran terlalu besar!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertHukumanDisiplin($nip, $jenis_hukuman, $tgl_hukuman, $tgl_akhir, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_hukuman_disiplin()
{
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $jenis_hukuman = $_POST['jenis_hukuman'];
    $tgl_hukuman = $_POST['tgl_hukuman'];
    $tgl_akhir = $_POST['tgl_akhir'];
    $keterangan = $_POST['keterangan'];
    $file_sk = $_FILES['file_sk'];

    try {
        $data = $this->riwayat->dataUpdateHukumanDisiplin($id, $nip, $jenis_hukuman, $tgl_hukuman, $tgl_akhir, $keterangan, $file_sk);
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } catch (Exception $e) {
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_hukuman()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteHukumanDisiplin($nip, $id);
		
		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	




	// RIWAYAT KETERANGAN KELUARGA table: riwayat_keterangan_keluarga
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_keterangan_keluarga()
{
    $nip = $_POST['nip'];
    $keterangan = $_POST['keterangan'];
    $no = $_POST['no'];
    $nama_keluarga = $_POST['nama_keluarga'];

    // Upload File
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (in_array(strtolower($ext), $allowed) && $_FILES['file_sk']['size'] <= $max_size) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertKeteranganKeluarga($nip, $keterangan, $no, $nama_keluarga, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_keterangan_keluarga()
{
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $keterangan = $_POST['keterangan'];
    $no = $_POST['no'];
    $nama_keluarga = $_POST['nama_keluarga'];
    $file_sk = $_FILES['file_sk'];

    try {
        $data = $this->riwayat->dataUpdateKeteranganKeluarga($id, $nip, $keterangan, $no, $nama_keluarga, $file_sk);
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } catch (Exception $e) {
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_keterangan_keluarga()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteKeteranganKeluarga($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// RIWAYAT KURSUS table: riwayat_kursus
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_kursus()
{
    $nip = $_POST['nip'];
    $nama_kursus = $_POST['nama_kursus'];
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'];

    // Upload file
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (in_array(strtolower($ext), $allowed) && $_FILES['file_sk']['size'] <= $max_size) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertKursus($nip, $nama_kursus, $tahun, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_kursus()
{
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $nama_kursus = $_POST['nama_kursus'];
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'];
    $file_sk = $_FILES['file_sk'];

    try {
        $data = $this->riwayat->dataUpdateKursus($id, $nip, $nama_kursus, $tahun, $keterangan, $file_sk);
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } catch (Exception $e) {
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_kursus()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeleteKursus($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// RIWAYAT PENDIDIKAN table: riwayat_pendidikan
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_pendidikan()
{
    $nip = $_POST['nip'];
    $nama_pendidikan = $_POST['nama_pendidikan'];
    $tahun_pendidikan = $_POST['tahun_pendidikan'];
    $keterangan = $_POST['keterangan'];

    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (in_array(strtolower($ext), $allowed) && $_FILES['file_sk']['size'] <= $max_size) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung atau ukuran file terlalu besar!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertPendidikan($nip, $nama_pendidikan, $tahun_pendidikan, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_pendidikan()
{
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $nama_pendidikan = $_POST['nama_pendidikan'];
    $tahun_pendidikan = $_POST['tahun_pendidikan'];
    $keterangan = $_POST['keterangan'];
    $file_sk = $_FILES['file_sk'];

    try {
        $data = $this->riwayat->dataUpdatePendidikan($id, $nip, $nama_pendidikan, $tahun_pendidikan, $keterangan, $file_sk);
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } catch (Exception $e) {
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_pendidikan()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeletePendidikan($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}

	// RIWAYAT PENGHARGAAN table: riwayat_penghargaan
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_riwayat_penghargaan()
{
    $nip = $_POST['nip'];
    $jenis_penghargaan = $_POST['jenis_penghargaan'];
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'];

    // Upload file
    $nama_file = '';
    if (isset($_FILES['file_sk']) && $_FILES['file_sk']['error'] == 0) {
        $target_dir = "upload_berkas/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = pathinfo($_FILES["file_sk"]["name"], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ext;
        $target_file = $target_dir . $nama_file;

        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $max_size = 900 * 1024;

        if (in_array(strtolower($ext), $allowed) && $_FILES['file_sk']['size'] <= $max_size) {
            if (!move_uploaded_file($_FILES["file_sk"]["tmp_name"], $target_file)) {
                echo "<script>alert('Gagal upload file!'); window.history.back();</script>";
                return;
            }
        } else {
            echo "<script>alert('Tipe file tidak didukung atau ukuran terlalu besar!'); window.history.back();</script>";
            return;
        }
    }

    $data = $this->riwayat->dataInsertPenghargaan($nip, $jenis_penghargaan, $tahun, $keterangan, $nama_file);

    if ($data) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES UPDATE KE TABEL
	function update_riwayat_penghargaan()
{
    $id = $_POST['id'];
    $nip = $_POST['nip'];
    $jenis_penghargaan = $_POST['jenis_penghargaan'];
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'];
    $file_sk = $_FILES['file_sk'];

    try {
        $data = $this->riwayat->dataUpdatePenghargaan($id, $nip, $jenis_penghargaan, $tahun, $keterangan, $file_sk);
        echo "<script>window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip';</script>";
    } catch (Exception $e) {
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_riwayat_penghargaan()
	{
		// DARI VIEW
		// MENANGKAP NILAI NIP
		$nip = $_GET['nip'];
		$id = $_GET['id'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL
		$data = $this->riwayat->dataDeletePenghargaan($nip, $id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data == TRUE) {
			echo "<script> 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
              alert('Proses Delete Gagal!'); 
              window.location = 'index.php?controller=pegawai&method=riwayat&nip=$nip'; 
              </script>";
		}
	}


}
