<?php
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_pegawai.php");
include("model/model_riwayat.php");
include("model/model_sistem.php");

// CLASS PENDUDUK
class pegawai
{
	// PROPERTY
	// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
	public $pegawai;
	public $sistem;
	public $riwayat;

	// METHOD
	// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
	function __construct()
	{
		// INSTANSIASI CLASS MODEL PENDUDUK
		$this->pegawai	= new model_pegawai();
		$this->sistem	= new model_sistem();
		$this->riwayat = new model_riwayat();
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function select()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$data			        = $this->sistem->dataHome();
		$data_pegawai			= $this->pegawai->dataSelect();


		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function detail()
	{
		// DARI CONTROLLER
		// MENANGKAP NILAI NIK
		$nip			= $_GET['nip'];

		$data		 = $this->sistem->dataHome();
		$data_pegawai = $this->pegawai->dataDetail($nip);
		$foto_pegawai = $this->pegawai->dataDetailFoto($nip);

		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function insert()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$data			        = $this->sistem->dataHome();


		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function keluarga()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$nip					= $_GET['nip'];


		$data			        = $this->sistem->dataHome();
		$data_detail   			= $this->pegawai->dataDetail($nip);
		$data_keluarga   		= $this->pegawai->dataKeluarga($nip);

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function anak()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$nip					= $_GET['nip'];


		$data			        = $this->sistem->dataHome();
		$data_detail   			= $this->pegawai->dataDetail($nip);
		$data_anak   			= $this->pegawai->dataAnak($nip);


		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function gaji()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$nip					= $_GET['nip'];


		$data			        = $this->sistem->dataHome();
		$data_pegawai   			= $this->pegawai->dataDetail($nip);
		$data_pegawai2   			= $this->pegawai->dataDetail($nip);

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function berkas()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$nip					= $_GET['nip'];


		$data			        = $this->sistem->dataHome();
		$data_detail   			= $this->pegawai->dataDetail($nip);
		$data_berkas   			= $this->pegawai->dataBerkas($nip);

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENGAMBIL DATA RIWAYAT 
	function riwayat()
{
    // Ambil NIP dari parameter
    $nip = $_GET['nip'];

    // Data umum dari model
    $data = $this->sistem->dataHome();
    $data_detail = $this->pegawai->dataDetail($nip);

    // Riwayat-riwayat
    $data_riwayat_golongan = $this->riwayat->dataRiwayatGolongan($nip);
    $data_riwayat_angka_kredit = $this->riwayat->dataRiwayatAngkaKredit($nip);
    $data_riwayat_diklat_pimpinan = $this->riwayat->dataRiwayatDiklatPimpinan($nip);
    $data_riwayat_dp3 = $this->riwayat->dataRiwayatDP3($nip);
    $data_riwayat_hukuman_disiplin = $this->riwayat->dataRiwayatHukumanDisiplin($nip);
    $data_riwayat_jabatan = $this->riwayat->dataRiwayatJabatan($nip);
    $data_riwayat_berkala = $this->riwayat->dataRiwayatBerkala($nip); // ✅ Ditambahkan
    $data_riwayat_keterangan_keluarga = $this->riwayat->dataRiwayatKeteranganKeluarga($nip);
    $data_riwayat_kursus = $this->riwayat->dataRiwayatKursus($nip);
    $data_riwayat_pendidikan = $this->riwayat->dataRiwayatPendidikan($nip);
    $data_riwayat_penghargaan = $this->riwayat->dataRiwayatPenghargaan($nip);

    // Tampilkan view
    include "view/dashboard.php"; // atau view lain tempat semua data ditampilkan
}

 
	// FUNCTION UNTUK CETAK 
	function cetak()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$nip					= $_GET['nip'];
		$data = $this->sistem->dataHome();
		$data_detail = $this->pegawai->dataDetail($nip);
		$data_riwayat_golongan = $this->riwayat->dataRiwayatGolongan($nip);
		$data_riwayat_angka_kredit = $this->riwayat->dataRiwayatAngkaKredit($nip);
		$data_riwayat_diklat_pimpinan = $this->riwayat->dataRiwayatDiklatPimpinan($nip);
		// var_dump($data_riwayat_diklat_pimpinan);die;
		$data_riwayat_dp3 = $this->riwayat->dataRiwayatDP3($nip);
		$data_riwayat_hukuman_disiplin = $this->riwayat->dataRiwayatHukumanDisiplin($nip);
		// var_dump($data_riwayat_hukuman_disiplin);die;
		$data_riwayat_jabatan = $this->riwayat->dataRiwayatJabatan($nip);
		// var_dump($data_riwayat_jabatan);die;
		$data_riwayat_keterangan_keluarga = $this->riwayat->dataRiwayatKeteranganKeluarga($nip);
		$data_riwayat_kursus = $this->riwayat->dataRiwayatKursus($nip);
		$data_riwayat_pendidikan = $this->riwayat->dataRiwayatPendidikan($nip);
		$data_riwayat_penghargaan = $this->riwayat->dataRiwayatPenghargaan($nip);
		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	} 

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function info()
	{
		// MODEL


		$data			        = $this->sistem->dataHome();

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}
	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function info_gaji()
	{
		// MODEL


		$data			        = $this->sistem->dataHome();

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	public function insert_data()
{
    require_once 'model/model_pegawai.php';
    $pegawai = new model_pegawai();

    // Ambil data POST dengan validasi dasar
    $nip             = trim($_POST['nip'] ?? '');
    $nama            = trim($_POST['nama'] ?? '');
    $tempat_lahir    = trim($_POST['tempat'] ?? '');
    $tahun           = $_POST['tahun'] ?? '';
    $bulan           = $_POST['bulan'] ?? '';
    $hari            = $_POST['hari'] ?? '';
    $tgl_lahir       = "$tahun-$bulan-$hari";
    $gender          = $_POST['gender'] ?? '';
    $agama           = $_POST['agama_pegawai'] ?? '';
    $kebangsaan      = $_POST['kebangsaan'] ?? '';
    $jumlah_keluarga = $_POST['jml_keluarga'] ?? '';
    $alamat          = $_POST['alamat'] ?? '';
    $sk_terakhir     = $_POST['sk_terakhir'] ?? '';
    $pangkat         = $_POST['pangkat'] ?? '';
    $tmt_golongan    = $_POST['tmt_golongan'] ?? '';
    $jenis           = $_POST['jenis_pegawai'] ?? '';
    $tmt_capeg       = $_POST['tmt_capeg'] ?? '';
    $status          = $_POST['status_pegawai'] ?? '';
    $jabatan         = trim($_POST['jabatan'] ?? ''); // teks biasa, sesuai permintaan
    $digaji          = $_POST['gaji'] ?? '';

    // Hapus tanda titik pada nominal
    $gaji_pokok      = (int) str_replace('.', '', ($_POST['gaji_pokok'] ?? '0'));
    $penghasilan     = (int) str_replace('.', '', ($_POST['penghasilan'] ?? '0'));

    $masa_golongan   = $_POST['masa_golongan'] ?? '';
    $masa_keseluruhan = $_POST['masa_keseluruhan'] ?? '';
    $npwp            = $_POST['npwp'] ?? '';
    $rt              = $_POST['rt'] ?? '';
    $rw              = $_POST['rw'] ?? '';
    $desa            = $_POST['desa'] ?? '';
    $kecamatan       = $_POST['kecamatan'] ?? '';
    $kabupaten       = $_POST['kabupaten'] ?? '';
    $wa              = $_POST['wa'] ?? '';

    // ===== PROSES UPLOAD FOTO =====
    $foto = '-';
    if (!empty($_FILES['foto']['name'])) {
        $target_dir = __DIR__ . '/../uploads/foto_pegawai/';
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $new_name = "foto_" . preg_replace('/\D/', '', $nip) . "_" . time() . "." . $ext;
        $target_file = $target_dir . $new_name;

        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
            $foto = $new_name;
        } else {
            echo "<script>alert('Upload foto gagal!'); history.back();</script>";
            exit;
        }
    }

    // === Panggil Model untuk insert ===
    $insert = $pegawai->dataInsert(
        $nip, $nama, $tempat_lahir, $tgl_lahir, $gender, $agama,
        $kebangsaan, $jumlah_keluarga, $alamat, $sk_terakhir, $pangkat,
        $tmt_golongan, $jenis, $tmt_capeg, $status, $jabatan, $digaji,
        $gaji_pokok, $penghasilan, $masa_golongan, $masa_keseluruhan,
        $npwp, $rt, $rw, $desa, $kecamatan, $kabupaten, $wa, $foto
    );

    if ($insert) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=select';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal! Pastikan semua field sesuai!'); history.back();</script>";
    }
}

	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	public function ubah_data()
{
	// Panggil model manual
	require_once 'model/model_pegawai.php';
	$pegawai = new model_pegawai();

	$nip 			= $_POST['nip'] ?? '-';
	$nama			= $_POST['nama'] ?? '-';
	$tempat_lahir 	= $_POST['tempat'] ?? '-';
	$tahun			= $_POST['tahun'] ?? '-';
	$bulan 			= $_POST['bulan'] ?? '-';
	$hari 			= $_POST['hari'] ?? '-';
	$tgl_lahir  	= "$tahun-$bulan-$hari";
	$gender			= $_POST['gender'] ?? '-';
	$agama 			= $_POST['agama_pegawai'] ?? '-';
	$kebangsaan 	= $_POST['kebangsaan'] ?? '-';
	$jumlah_keluarga = $_POST['jml_keluarga'] ?? '-';
	$alamat 		= $_POST['alamat'] ?? '-';
	$sk_terakhir 	= $_POST['sk_terakhir'] ?? '-';
	$pangkat 		= $_POST['pangkat'] ?? '-';
	$tmt_golongan	= $_POST['tmt_golongan'] ?? '-';
	$jenis 			= $_POST['jenis_pegawai'] ?? '-';
	$tmt_capeg 		= $_POST['tmt_capeg'] ?? '-';
	$status 		= $_POST['status_pegawai'] ?? '-';
	$jabatan		= $_POST['jabatan'] ?? '-';
	$digaji 		= $_POST['gaji'] ?? '-';

	$gaji_pokok 	= str_replace('.', '', ($_POST['gaji_pokok'] ?? '0'));
	$penghasilan 	= str_replace('.', '', ($_POST['penghasilan'] ?? '0'));

	$masa_golongan 	= $_POST['masa_golongan'] ?? '-';
	$masa_keseluruhan = $_POST['masa_keseluruhan'] ?? '-';
	$npwp 			= $_POST['npwp'] ?? '-';
	$rt 			= $_POST['rt'] ?? '-';
	$rw 			= $_POST['rw'] ?? '-';
	$desa 			= $_POST['desa'] ?? '-';
	$kecamatan 		= $_POST['kecamatan'] ?? '-';
	$kabupaten 		= $_POST['kabupaten'] ?? '-';
	$wa             = $_POST['wa'] ?? '-';

	// CEK FOTO LAMA DARI DATABASE
	$pegawai_data = $pegawai->getByNip($nip);
	$foto_lama = $pegawai_data['foto'] ?? '-';

	// PROSES UPLOAD FOTO BARU JIKA ADA
	$foto = $foto_lama;
	if (isset($_FILES['foto']) && $_FILES['foto']['name'] != '') {
		$target_dir = "uploads/foto_pegawai/";
		if (!file_exists($target_dir)) {
			mkdir($target_dir, 0777, true);
		}

		$ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
		$new_name = "foto_" . $nip . "_" . time() . "." . $ext;
		$target_file = $target_dir . $new_name;

		if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
			$foto = $new_name;
			// Hapus foto lama jika ada
			if ($foto_lama != '-' && file_exists($target_dir . $foto_lama)) {
				unlink($target_dir . $foto_lama);
			}
		} else {
			echo "<script>alert('Upload foto gagal!'); window.location = 'index.php?controller=pegawai&method=detail&nip=$nip';</script>";
			exit;
		}
	}

	// UPDATE DATA KE DATABASE
	$hasil = $pegawai->dataUpdate(
		$nip, $nama, $tempat_lahir, $tgl_lahir, $gender, $agama,
		$kebangsaan, $jumlah_keluarga, $alamat, $sk_terakhir, $pangkat,
		$tmt_golongan, $jenis, $tmt_capeg, $status, $jabatan, $digaji,
		$gaji_pokok, $penghasilan, $masa_golongan, $masa_keseluruhan,
		$npwp, $rt, $rw, $desa, $kecamatan, $kabupaten, $wa, $foto
	);

	// REDIRECT SETELAH UPDATE
	if ($hasil) {
		echo "<script>window.location = 'index.php?controller=pegawai&method=detail&nip=$nip';</script>";
	} else {
		echo "<script>alert('Proses Update Gagal!'); window.location = 'index.php?controller=pegawai&method=detail&nip=$nip';</script>";
	}
}



	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete()
	{
		// DARI CONTROLLER
		// MENANGKAP NILAI NIK
		$nip			= $_GET['nip'];

		$data = $this->pegawai->dataDelete($nip);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data 		== TRUE) {
			echo "<script> 
						  window.location = 'index.php?controller=pegawai&method=select'; 
						  </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
							alert('Proses Delete Gagal!'); 
						  window.location = 'index.php?controller=pegawai&method=select'; 
						  </script>";
		}
	}

	// Bagian Keluarga
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_keluarga()
	{
		// DARI VIEW
		// MENAMPUNG DATA YANG DIINPUTKAN
		$nip 			= $_POST['nip'] == '' ? '-' : $_POST['nip'];
		$nama			= $_POST['nama'] == '' ? '-' : $_POST['nama'];
		$tempat_lahir 	= $_POST['tempat'] == '' ? '-' : $_POST['tempat'];
		$tahun			= $_POST['tahun'] == '' ? '-' : $_POST['tahun'];
		$bulan 			= $_POST['bulan']== '' ? '-' : $_POST['bulan'];
		$hari 			= $_POST['hari'] == '' ? '-' : $_POST['hari'];
		$tgl_lahir  	= $tahun . "-" . $bulan . "-" . $hari;
		$pekerjaan 		= $_POST['pekerjaan'] == '' ? '-' : $_POST['pekerjaan'];
		$tgl_perkawinan = $_POST['tgl_perkawinan'] == '' ? '' : $_POST['tgl_perkawinan'];
		$ke				= $_POST['ke'] == '' ? '0' : $_POST['ke'];
		$nik 		    = $_POST['nik'] == '' ? '0' : $_POST['nik'];
		$penghasilan	= $_POST['penghasilan'] == '' ? '0' : $_POST['penghasilan'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
		$data_insert			= $this->pegawai->dataInsertKeluarga($nip, $nama, $tempat_lahir, $tgl_lahir, $nik, $pekerjaan, $tgl_perkawinan, $ke, $penghasilan);

		// DARI VIEW
		if ($data_insert 		== TRUE) {
			echo "<script> 
						  window.location = 'index.php?controller=pegawai&method=keluarga&nip=$nip';
						  </script>";
		}
		// MENGARAHKAN KE FILE VIEW/INSERT.PHP
		// JIKA HASIL PROSES INSERT GAGAL
		else {
			echo "<script> 
						  alert('Proses Insert Gagal!');
						  window.location = 'index.php?controller=pegawai&method=keluarga&nip='.$nip; 
						  </script>";
		}
	}

	// FUNCTION UNTUK MENANGANI PROSES Update
	function ubah_keluarga()
	{
		// DARI VIEW
		// MENAMPUNG DATA YANG DIINPUTKAN
		$id				= $_POST['id'];
		$nip 			= $_POST['nip'] == '' ? '-' : $_POST['nip'];
		$nama			= $_POST['nama'] == '' ? '-' : $_POST['nama'];
		$tempat_lahir 	= $_POST['tempat'] == '' ? '-' : $_POST['tempat'];
		$tahun			= $_POST['tahun'] == '' ? '-' : $_POST['tahun'];
		$bulan 			= $_POST['bulan']== '' ? '-' : $_POST['bulan'];
		$hari 			= $_POST['hari'] == '' ? '-' : $_POST['hari'];
		$tgl_lahir  	= $tahun . "-" . $bulan . "-" . $hari;
		$pekerjaan 		= $_POST['pekerjaan'] == '' ? '-' : $_POST['pekerjaan'];
		$tgl_perkawinan = $_POST['tgl_perkawinan'] == '' ? '' : $_POST['tgl_perkawinan'];
		$ke				= $_POST['ke'] == '' ? '0' : $_POST['ke'];
		$nik 		    = $_POST['nik'] == '' ? '0' : $_POST['nik'];
		$penghasilan	= $_POST['penghasilan'] == '' ? '0' : $_POST['penghasilan'];

		// DARI MODEL
		// MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
		$data_insert			= $this->pegawai->dataUpdateKeluarga($id, $nama, $tempat_lahir, $tgl_lahir, $nik, $pekerjaan, $tgl_perkawinan, $ke, $penghasilan);

		// DARI VIEW
		if ($data_insert 		== TRUE) {
			echo "<script> 
						  window.location = 'index.php?controller=pegawai&method=keluarga&nip=$nip';
						  </script>";
		}
		// MENGARAHKAN KE FILE VIEW/INSERT.PHP
		// JIKA HASIL PROSES INSERT GAGAL
		else {
			echo "<script> 
						  alert('Proses Update Gagal!');
						  window.location = 'index.php?controller=pegawai&method=keluarga&nip=$nip'; 
						  </script>";
		}
	}
	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_keluarga()
	{
		// DARI CONTROLLER
		// MENANGKAP NILAI NIK
		$id			= $_GET['id'];
		$nip		= $_GET['nip'];

		$data = $this->pegawai->dataDeleteKeluarga($id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data 		== TRUE) {
			echo "<script> 
						  window.location = 'index.php?controller=pegawai&method=keluarga&nip=$nip'; 
						  </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
							alert('Proses Delete Gagal!'); 
						  window.location = 'index.php?controller=pegawai&method=keluarga&nip=$nip'; 
						  </script>";
		}
	}



	// Bagian Keluarga
	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_anak()
{
    // Ambil input
    $nip            = $_POST['nip'] ?? '-';
    $nama           = $_POST['nama'] ?? '-';
    $tempat_lahir   = $_POST['tempat'] ?? '';
    $tahun          = $_POST['tahun'] ?? '';
    $bulan          = $_POST['bulan'] ?? '';
    $hari           = $_POST['tgl'] ?? ''; // <== disesuaikan dengan name="tgl" di form

    // Validasi tanggal
    if (empty($tahun) || empty($bulan) || empty($hari)) {
        $tgl_lahir = NULL;
    } else {
        if (!checkdate((int)$bulan, (int)$hari, (int)$tahun)) {
            echo "<script>alert('Tanggal lahir tidak valid!'); history.back();</script>";
            exit;
        }
        $tgl_lahir = $tahun . '-' . str_pad($bulan, 2, '0', STR_PAD_LEFT) . '-' . str_pad($hari, 2, '0', STR_PAD_LEFT);
    }

    $kawin      = $_POST['kawin'] ?? '-';
    $tunjangan  = $_POST['tunjangan'] ?? '-';
    $ke         = $_POST['ke'] ?? '0';
    $status     = $_POST['status'] ?? '-';
    $bekerja    = $_POST['bekerja'] ?? '-';
    $sekolah    = $_POST['sekolah'] ?? '-';
    $putusan    = $_POST['putusan'] ?? '-';
    $gender     = $_POST['gender'] ?? '-';

    // Kirim ke model
    $data_insert = $this->pegawai->dataInsertAnak(
        $nip, $nama, $tempat_lahir, $tgl_lahir, $status, $ke, $gender,
        $tunjangan, $kawin, $bekerja, $sekolah, $putusan
    );

    if ($data_insert) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=anak&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Insert Gagal!'); window.location = 'index.php?controller=pegawai&method=anak&nip=$nip';</script>";
    }
}

function ubah_anak()
{
    $id             = $_POST['id'];
    $nip            = $_POST['nip'] ?? '-';
    $nama           = $_POST['nama'] ?? '-';
    $tempat_lahir   = $_POST['tempat'] ?? '';
    $tahun          = $_POST['tahun'] ?? '';
    $bulan          = $_POST['bulan'] ?? '';
    $hari           = $_POST['tgl'] ?? ''; // <== disesuaikan juga di sini

    // Validasi tanggal
    if (empty($tahun) || empty($bulan) || empty($hari)) {
        $tgl_lahir = NULL;
    } else {
        if (!checkdate((int)$bulan, (int)$hari, (int)$tahun)) {
            echo "<script>alert('Tanggal lahir tidak valid!'); history.back();</script>";
            exit;
        }
        $tgl_lahir = $tahun . '-' . str_pad($bulan, 2, '0', STR_PAD_LEFT) . '-' . str_pad($hari, 2, '0', STR_PAD_LEFT);
    }

    $kawin      = $_POST['kawin'] ?? '-';
    $tunjangan  = $_POST['tunjangan'] ?? '-';
    $ke         = $_POST['ke'] ?? '0';
    $status     = $_POST['status'] ?? '-';
    $bekerja    = $_POST['bekerja'] ?? '-';
    $sekolah    = $_POST['sekolah'] ?? '-';
    $putusan    = $_POST['putusan'] ?? '-';
    $gender     = $_POST['gender'] ?? '-';

    // Kirim ke model
    $data_update = $this->pegawai->dataUbahAnak(
        $id, $nip, $nama, $tempat_lahir, $tgl_lahir, $status, $ke, $gender,
        $tunjangan, $kawin, $bekerja, $sekolah, $putusan
    );

    if ($data_update) {
        echo "<script>window.location = 'index.php?controller=pegawai&method=anak&nip=$nip';</script>";
    } else {
        echo "<script>alert('Proses Update Gagal!'); window.location = 'index.php?controller=pegawai&method=anak&nip=$nip';</script>";
    }
}


	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_anak()
	{
		// DARI CONTROLLER
		// MENANGKAP NILAI NIK
		$id			= $_GET['id'];
		$nip		= $_GET['nip'];

		$data = $this->pegawai->dataDeleteAnak($id);

		/// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE BERHASIL
		if ($data 		== TRUE) {
			echo "<script> 
						  window.location = 'index.php?controller=pegawai&method=anak&nip=$nip'; 
						  </script>";
		}
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES DELETE GAGAL
		else {
			echo "<script>
							alert('Proses Delete Gagal!'); 
						  window.location = 'index.php?controller=pegawai&method=anak&nip=$nip'; 
						  </script>";
		}
	}
}
