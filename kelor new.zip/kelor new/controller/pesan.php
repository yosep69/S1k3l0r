<?php
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_wa.php");
include("model/model_sistem.php");
include("model/model_pegawai.php");
include("model/model_message.php");

// CLASS PENDUDUK
class pesan
{
	// PROPERTY
	// DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
	public $wa;
	public $sistem;
	public $pegawai;
	public $message;

	// METHOD
	// FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
	function __construct()
	{
		// INSTANSIASI CLASS MODEL PENDUDUK
		$this->wa	= new model_wa();
		$this->sistem	= new model_sistem();
		$this->pegawai	= new model_pegawai();
		$this->message = new model_message();
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function get()
	{
		$getUser = $_SESSION['username_simpeg'];
    
		if (isset($_POST['kontak'])) {
			$_SESSION['kontak'] = $_POST['kontak'];
		}
		$with = isset($_SESSION['kontak']) ? $_SESSION['kontak'] : '';
	
		if ($with !== '') {
			$penerima = $this->message->getPenerima($with);
		} else {
			// Handle the case when $with is empty or not set
			// For example, you can set $penerima to an empty array or display a message to select a contact.
			$penerima = array();
		}

		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$data			    = $this->sistem->dataHome();
		$data_wa			= $this->wa->dataSelect();
		$messages			= $this->message->get_messages($getUser);

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}
	function send_message()
	{
		$sender = $_SESSION['username_simpeg'];
		$receiver = $_POST['receiver'];
		$messageContent = $_POST['messageContent'];
		$send_message = $this->message->send_message($sender, $receiver, $messageContent);
	
		if ($send_message) {
			$_SESSION['kontak'] = $receiver; // Update the session data for 'kontak'
			$redirect_url = 'index.php?controller=pesan&method=get';
			echo "<script>
					window.location.href = '$redirect_url';
				</script>";
			exit();
		} else {
			$redirect_url = 'index.php?controller=pesan&method=get';
			echo "<script> 
					alert('Proses Insert Gagal!');
					window.location.href = '$redirect_url';
				</script>";
			exit();
		}
	}
	
	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function pemberitahuan()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL 
		$data			    = $this->sistem->dataHome();
		$data_pegawai		= $this->pegawai->dataSelect();

		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function setting()
	{
		// MODEL
		// MENGARAH KE METHOD DI CLASS MODEL AGAMA
		$data			        = $this->sistem->dataHome();
		$data_wa			= $this->wa->dataSelect();


		// VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function edit()
	{
		// DARI CONTROLLER
		// MENANGKAP NILAI NIK
		$token			= $_POST['token'];

		// MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
		$data			= $this->wa->dataUpdate($token);

		// DARI VIEW
		// MENGARAHKAN KE FILE VIEW/SELECT.PHP
		// JIKA HASIL PROSES INSERT BERHASIL
		if ($data 		== TRUE) {
			echo "<script> 
						  window.location = 'index.php?controller=wa&method=setting'; 
						  </script>";
		}
		// MENGARAHKAN KE FILE VIEW/INSERT.PHP
		// JIKA HASIL PROSES INSERT GAGAL
		else {
			echo "<script> 
						  alert('Proses Update Gagal!');
						  window.location = 'index.php?controller=wa&method=setting'; 
						  </script>";
		}

		include "view/dashboard.php";
	}

}
