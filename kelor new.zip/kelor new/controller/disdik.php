<?php  
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_disdik.php");
include("model/model_sistem.php");

// CLASS DISDIK
class disdik
{
    // PROPERTY
    public $kategori;
    public $sistem;
    
    // CONSTRUCT
    function __construct()
    {
        $this->kategori  = new model_disdik();
        $this->sistem    = new model_sistem();
    }
    
    // SELECT CONFIGURASI
    function select()
    {
        $data         = $this->sistem->dataHome();
        $data_disdik  = $this->kategori->dataDisdikKonfigurasi();
        include "view/dashboard.php";
    }
    
    // SELECT UNTUK ADMIN
    function user()
    {
        $data         = $this->sistem->dataHome();
        $data_disdik  = $this->kategori->dataDisdik();
        include "view/dashboard.php";
    }
    
    // SELECT UNTUK USER
    function read()
    {
        $data         = $this->sistem->dataHome();
        $data_disdik  = $this->kategori->dataDisdikUser();
        include "view/dashboard.php";
    }
    
    // INSERT KONFIGURASI
    function insert_disdik()
    {
        $nama    = $_POST['nama'];
        $size    = $_POST['size'];
        $nip     = $_POST['nip'];
        $karyawan = '';
        
        include("config/koneksi.php");
        $query_status = "SELECT * FROM pegawai WHERE nip = '{$nip}'";
        $status = mysqli_query($koneksi, $query_status);
        while ($row_status = mysqli_fetch_array($status)) {
            $karyawan = $row_status['nama'];
        }

        $ekstensi = implode(",", $_POST['ekstensi']);
        $jenis_pengajuan = 'disdik';

        $data = $this->kategori->dataInsert_Disdik($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan);

        if ($data) {
            echo "<script>window.location = 'index.php?controller=disdik&method=select';</script>";
        } else {
            echo "<script>alert('Proses Insert Gagal!');window.location = 'index.php?controller=disdik&method=select';</script>";
        }
    }
    
    // INSERT BERKAS
    function insert_disdik_berkas()
    {
        if (isset($_POST['submit'])) {
            $nip      = $_SESSION['nip'];
            $tanggal  = date("d-m-Y H:i:s");
            $status   = 'Upload Berkas';

            if (!file_exists('surat/disdik/')) {
                mkdir('surat/disdik/', 0777, true);
            }

            for ($i = 0; $i < count($_POST['nama_file']); $i++) {
                $nama_file = $_POST['nama_file'][$i];
                $size_file = $_POST['size_file'][$i];
                $ekstensi  = $_POST['accept_file'][$i];
                $filename  = $_FILES["file"]["name"][$i];
                $tempname  = $_FILES["file"]["tmp_name"][$i];

                $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
                $unique_filename = date('YmdHis') . '_' . uniqid() . '.' . $file_ext;
                $folder = "surat/disdik/" . $unique_filename;

                if (move_uploaded_file($tempname, $folder)) {
                    $data = $this->kategori->dataInsert_DisdikBerkas($nama_file, $size_file, $ekstensi, $unique_filename, $nip, $tanggal, $status);
                    $success = $data ? true : false;
                } else {
                    $success = false;
                }
            }

            if (isset($success) && $success) {
                echo "<script>alert('Proses Insert Berhasil!');window.location = 'index.php?controller=disdik&method=select';</script>";
            } else {
                echo "<script>alert('Proses Insert Gagal!');window.location = 'index.php?controller=disdik&method=select';</script>";
            }
        }
    }
    
    // UPDATE STATUS
    function update_status()
    {
        $id      = $_POST['id'];
        $status  = $_POST['status'];
        $reason  = $_POST['reason'];
        $tanggal = date("d-m-Y H:i:s");

        $upload_file = null;

        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == 0) {
            $filename   = $_FILES['upload_file']['name'];
            $tempname   = $_FILES['upload_file']['tmp_name'];

            $allowed_extensions = ['pdf', 'doc', 'docx'];
            $file_extension = pathinfo($filename, PATHINFO_EXTENSION);

            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                if (!file_exists('surat/disdik/')) {
                    mkdir('surat/disdik/', 0777, true);
                }

                $unique_filename = date('YmdHis') . '_' . uniqid() . '.' . $file_extension;
                $folder = "surat/disdik/" . $unique_filename;

                if (move_uploaded_file($tempname, $folder)) {
                    $upload_file = $unique_filename;
                } else {
                    echo "<script>alert('Gagal mengupload file!');window.location = 'index.php?controller=disdik&method=user';</script>";
                    return;
                }
            } else {
                echo "<script>alert('Ekstensi file tidak diizinkan!');window.location = 'index.php?controller=disdik&method=user';</script>";
                return;
            }
        }

        $data = $this->kategori->dataUpdate_Disdik($id, $status, $reason, $tanggal, $upload_file);

        if ($data) {
            echo "<script>window.location = 'index.php?controller=disdik&method=user';</script>";
        } else {
            echo "<script>alert('Proses Update Gagal!');window.location = 'index.php?controller=disdik&method=user';</script>";
        }
    }
    
    // DELETE KONFIGURASI
    function delete_disdik()
    {
        $id = $_GET['id'];
        $data = $this->kategori->dataDeleteDisdik($id);

        if ($data) {
            echo "<script>alert('Proses Delete Berhasil!');window.location = 'index.php?controller=disdik&method=select';</script>";
        } else {
            echo "<script>alert('Proses Delete Gagal!');window.location = 'index.php?controller=disdik&method=select';</script>";
        }
    }
    
    // DELETE BERKAS
    function delete()
    {
        $id = $_GET['id'];

        include("config/koneksi.php");
        $query = "SELECT upload FROM disdik WHERE id = '$id'";
        $result = mysqli_query($koneksi, $query);
        if ($row = mysqli_fetch_assoc($result)) {
            if (!empty($row['upload'])) {
                $file_path = "surat/disdik/" . $row['upload'];
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
        }

        $data = $this->kategori->dataDeleteDisdikBerkas($id);

        if ($data) {
            if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
                echo "<script>alert('Proses Delete Berhasil!');window.location = 'index.php?controller=disdik&method=user';</script>";
            } elseif ($_SESSION['level_simpeg'] == 'user') {
                echo "<script>alert('Proses Delete Berhasil!');window.location = 'index.php?controller=disdik&method=read';</script>";
            }
        } else {
            if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
                echo "<script>alert('Proses Delete Gagal!');window.location = 'index.php?controller=disdik&method=user';</script>";
            } elseif ($_SESSION['level_simpeg'] == 'user') {
                echo "<script>alert('Proses Delete Gagal!');window.location = 'index.php?controller=disdik&method=read';</script>";
            }
        }
    }
}
?>
