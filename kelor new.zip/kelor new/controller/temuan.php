<?php
// INCLUDE KONEKSI DATABASE 
include_once("config/database.php");

// INCLUDE MODEL DARI FOLDER MODEL 
include_once("model/model_temuan.php");
include_once("model/model_sistem.php");

// CLASS CONTROLLER TEMUAN
class Temuan
{
    // PROPERTY
    private $kategori;
    private $sistem;

    // CONSTRUCTOR
    public function __construct()
    {
        $this->kategori = new model_temuan();
        $this->sistem   = new model_sistem();
    }

    // TAMPIL UNTUK ADMIN / SUPERADMIN
    public function select()
    {
        $data        = $this->sistem->dataHome();
        $data_temuan = $this->kategori->dataTemuanKonfigurasi();
        include "view/dashboard.php";
    }

    // TAMPIL UNTUK USER ADMIN
    public function user()
    {
        $data        = $this->sistem->dataHome();
        $data_temuan = $this->kategori->dataTemuan();
        include "view/dashboard.php";
    }

    // TAMPIL UNTUK USER BIASA
    public function read()
    {
        $data        = $this->sistem->dataHome();
        $data_temuan = $this->kategori->dataTemuanUser();
        include "view/dashboard.php";
    }

    // INSERT DATA TEMUAN (konfigurasi)
    public function insert_temuan()
    {
        if (empty($_POST['nama']) || empty($_POST['size']) || empty($_POST['nip']) || empty($_POST['ekstensi'])) {
            echo "<script>alert('Data tidak lengkap!'); window.location='index.php?controller=temuan&method=select';</script>";
            return;
        }

        $nama     = $_POST['nama'];
        $size     = $_POST['size'];
        $nip      = $_POST['nip'];
        $karyawan = '';

        include("config/koneksi.php");
        $query_status = "SELECT nama FROM pegawai WHERE nip = '{$nip}' LIMIT 1";
        $status = mysqli_query($koneksi, $query_status);

        if ($status && $row_status = mysqli_fetch_assoc($status)) {
            $karyawan = $row_status['nama'];
        }

        $ekstensi = implode(",", $_POST['ekstensi']);
        $jenis_pengajuan = 'temuan';

        $data = $this->kategori->dataInsert_Temuan($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan);

        if ($data) {
            echo "<script>window.location='index.php?controller=temuan&method=select';</script>";
        } else {
            echo "<script>alert('Proses Insert Gagal!'); window.location='index.php?controller=temuan&method=select';</script>";
        }
    }

    // INSERT TEMUAN BERKAS
    public function insert_temuan_berkas()
    {
        if (isset($_POST['submit']) && isset($_FILES['file'])) {
            $nip     = $_SESSION['nip'];
            $tanggal = date("Y-m-d H:i:s");
            $status  = 'Upload Berkas';

            // pastikan folder upload ada
            $uploadDir = "upload_berkas/temuan/";
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            for ($i = 0; $i < count($_POST['nama_file']); $i++) {
                $nama_file = $_POST['nama_file'][$i];
                $size_file = $_POST['size_file'][$i];
                $ekstensi  = $_POST['accept_file'][$i];

                $filename  = $_FILES["file"]["name"][$i];
                $tempname  = $_FILES["file"]["tmp_name"][$i];
                $folder    = $uploadDir . basename($filename);

                if (move_uploaded_file($tempname, $folder)) {
                    $data = $this->kategori->dataInsert_TemuanBerkas(
                        $nama_file,
                        $size_file,
                        $ekstensi,
                        $filename,
                        $nip,
                        $tanggal,
                        $status
                    );

                    if (!$data) {
                        echo "<script>alert('Proses Insert Gagal!'); window.location='index.php?controller=temuan&method=select';</script>";
                        return;
                    }
                }
            }

            echo "<script>alert('Proses Insert Berhasil!'); window.location='index.php?controller=temuan&method=select';</script>";
        
        }
    
    }


    // UPDATE STATUS TEMUAN
    public function update_status()
    {
        if (empty($_POST['id']) || empty($_POST['status'])) {
            echo "<script>alert('Data tidak lengkap!'); window.location='index.php?controller=temuan&method=user';</script>";
            return;
        }

        $id       = $_POST['id'];
        $status   = $_POST['status'];
        $reason   = $_POST['reason'] ?? '';
        $tanggal  = date("Y-m-d H:i:s");
        $upload_file = null;

        // pastikan folder upload ada
        $uploadDir = "upload_berkas/temuan/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == 0) {
            $filename  = basename($_FILES['upload_file']['name']);
            $tempname  = $_FILES['upload_file']['tmp_name'];
            $folder    = $uploadDir . $filename;

            if (move_uploaded_file($tempname, $folder)) {
                $upload_file = $filename;
            }
        }

        $data = $this->kategori->dataUpdate_Temuan($id, $status, $reason, $tanggal, $upload_file);

        if ($data) {
            echo "<script>window.location='index.php?controller=temuan&method=user';</script>";
        } else {
            echo "<script>alert('Proses Update Gagal!'); window.location='index.php?controller=temuan&method=user';</script>";
        }
    }

    // DELETE TEMUAN (konfigurasi)
    // DELETE TEMUAN (konfigurasi)
public function delete_temuan()
{
    $id = $_POST['id'] ?? ($_GET['id'] ?? null);

    if (!$id) {
        echo "<script>alert('ID tidak ditemukan!'); window.location='index.php?controller=temuan&method=select';</script>";
        return;
    }

    $data = $this->kategori->dataDeleteTemuan($id);

    if ($data) {
        echo "<script>alert('Proses Delete Berhasil!'); window.location='index.php?controller=temuan&method=select';</script>";
    } else {
        echo "<script>alert('Proses Delete Gagal!'); window.location='index.php?controller=temuan&method=select';</script>";
    }
}

// DELETE TEMUAN BERKAS
public function delete()
{
    $id = $_POST['id'] ?? ($_GET['id'] ?? null);

    if (!$id) {
        echo "<script>alert('ID tidak ditemukan!'); window.location='index.php?controller=temuan&method=user';</script>";
        return;
    }

    $data = $this->kategori->dataDeleteTemuanBerkas($id);

    $redirect = ($_SESSION['level_simpeg'] == 'user') ? "read" : "user";
    $pesan    = $data ? "Proses Delete Berhasil!" : "Proses Delete Gagal!";

    echo "<script>alert('{$pesan}'); window.location='index.php?controller=temuan&method={$redirect}';</script>";
}

}
?>
