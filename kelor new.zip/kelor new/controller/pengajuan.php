<?php
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_pengajuan.php");
include("model/model_sistem.php");

// CLASS PENDUDUK
class pengajuan
{
	// PROPERTY
	public $kategori;
	public $sistem;

	// METHOD
	function __construct()
	{
		$this->kategori	= new model_pengajuan();
		$this->sistem	= new model_sistem();
	}

	// FUNCTION UNTUK MENANGANI PROSES SELECT
	function select()
	{
		$data			        = $this->sistem->dataHome();
		$data_pengajuan			= $this->kategori->dataPengajuanKonfigurasi();
		include "view/dashboard.php";
	}

	function user()
	{
		$data			        = $this->sistem->dataHome();
		$data_pengajuan			= $this->kategori->dataPengajuan();
		include "view/dashboard.php";
	}

	function read()
	{
		$data			        = $this->sistem->dataHome();
		$data_pengajuan			= $this->kategori->dataPengajuanUser();
		include "view/dashboard.php";
	}

	// FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
	function insert_pengajuan()
	{
		$nama		= $_POST['nama'];
		$size		= $_POST['size'];
		$nip		= $_POST['nip'];
		$karyawan   = '';

		include("config/koneksi.php");
		$query_status = "select * from pegawai where nip = '{$nip}'";
		$status = mysqli_query($koneksi, $query_status);
		while ($row_status = mysqli_fetch_array($status)) {
			$karyawan = $row_status['nama'];
		}
		$ekstensi = implode(",", $_POST['ekstensi']);

		$jenis_pengajuan = 'pengajuan';
		$data = $this->kategori->dataInsert_Pengajuan($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan);

		if ($data == TRUE) {
			echo "<script> window.location = 'index.php?controller=pengajuan&method=select'; </script>";
		} else {
			echo "<script> 
					  alert('Proses Insert Gagal!');
					  window.location = 'index.php?controller=pengajuan&method=select'; 
					  </script>";
		}
	}

	function insert_pengajuan_berkas()
	{
		if (isset($_POST['submit'])) {
			$nip = $_SESSION['nip'];
			$tanggal 	= date("d-m-Y H:i:s");
			$status = 'Upload Berkas';

			for ($i = 0; $i < count($_POST['nama_file']); $i++) {
				$nama_file	= $_POST['nama_file'][$i];
				$size_file	= $_POST['size_file'][$i];
				$ekstensi   = $_POST['accept_file'][$i];
				$filename   = $_FILES["file"]["name"][$i];
				$name       = $_FILES["file"]["name"][$i];

				$tempname   = $_FILES["file"]["tmp_name"][$i];
				$folder     = "upload_berkas/" . $filename;
				move_uploaded_file($tempname, $folder);

				$data = $this->kategori->dataInsert_PengajuanBerkas($nama_file, $size_file, $ekstensi, $name, $nip, $tanggal, $status);

				if ($data == TRUE) {
					echo "<script>
							alert('Proses Insert Berhasil!');
							window.location = 'index.php?controller=pengajuan&method=select'; 
						  </script>";
				} else {
					echo "<script> 
							alert('Proses Insert Gagal!');
							window.location = 'index.php?controller=pengajuan&method=select'; 
						  </script>";
				}
			}
		}
	}

	// FUNCTION UNTUK MENANGANI PROSES UPDATE STATUS
	function update_status()
	{
		$id			= $_POST['id'];
		$status		= $_POST['status'];
		$reason		= $_POST['reason'];
		$tanggal 	= date("d-m-Y H:i:s");

		$upload_file = null;
		if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == 0) {
			$filename   = $_FILES['upload_file']['name'];
			$tempname   = $_FILES['upload_file']['tmp_name'];
			$folder     = "upload_berkas/" . $filename;

			if (move_uploaded_file($tempname, $folder)) {
				$upload_file = $filename;
			}
		}

		$data = $this->kategori->dataUpdate_Pengajuan($id, $status, $reason, $tanggal, $upload_file);

		if ($data == TRUE) {
			echo "<script> window.location = 'index.php?controller=pengajuan&method=user'; </script>";
		} else {
			echo "<script> 
					  alert('Proses Update Gagal!');
					  window.location = 'index.php?controller=pengajuan&method=user'; 
					  </script>";
		}
	}

	// FUNCTION UNTUK MENANGANI PROSES DELETE
	function delete_pengajuan()
	{
		$id	= $_GET['id'];
		$data = $this->kategori->dataDeletePengajuan($id);

		if ($data == TRUE) {
			echo "<script> 
					  alert('Proses Delete Berhasil!');
					  window.location = 'index.php?controller=pengajuan&method=select'; 
					  </script>";
		} else {
			echo "<script>
					  alert('Proses Delete Gagal!'); 
					  window.location = 'index.php?controller=pengajuan&method=select'; 
					  </script>";
		}
	}

	function delete()
	{
		$id	= $_GET['id'];
		$data = $this->kategori->dataDeletePengajuanBerkas($id);

		if ($data == TRUE) {
			if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
				echo "<script> 
						  alert('Proses Delete Berhasil!');
						  window.location = 'index.php?controller=pengajuan&method=user'; 
						  </script>";
			} elseif ($_SESSION['level_simpeg'] == 'user') {
				echo "<script> 
						alert('Proses Delete Berhasil!');
						window.location = 'index.php?controller=pengajuan&method=read'; 
					  </script>";
			}
		} else {
			if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
				echo "<script> 
						  alert('Proses Delete Gagal!');
						  window.location = 'index.php?controller=pengajuan&method=user'; 
						  </script>";
			} elseif ($_SESSION['level_simpeg'] == 'user') {
				echo "<script> 
						alert('Proses Delete Gagal!');
						window.location = 'index.php?controller=pengajuan&method=read'; 
					  </script>";
			}
		}
	}
}
?>
