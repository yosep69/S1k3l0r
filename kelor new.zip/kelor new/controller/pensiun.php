<?php
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_pensiun.php");
include("model/model_sistem.php");
// CLASS PENDUDUK
class pensiun
{
    // PROPERTY
    // DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
    public $kategori;
    public $sistem;
    
    // METHOD
    // FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
    function __construct()
    {
        // INSTANSIASI CLASS MODEL PENDUDUK
        $this->kategori  = new model_pensiun();
        $this->sistem    = new model_sistem();
    }
    
    // FUNCTION UNTUK MENANGANI PROSES SELECT
    function select()
    {
        // MODEL
        // MENGARAH KE METHOD DI CLASS MODEL AGAMA
        $data                = $this->sistem->dataHome();
        $data_pensiun        = $this->kategori->dataPensiunKonfigurasi();

        // VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        include "view/dashboard.php";
    }
    
    function user()
    {
        // MODEL
        // MENGARAH KE METHOD DI CLASS MODEL AGAMA
        $data                = $this->sistem->dataHome();
        $data_pensiun        = $this->kategori->dataPensiun();

        // VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        include "view/dashboard.php";
    }
    
    function read()
    {
        // MODEL
        // MENGARAH KE METHOD DI CLASS MODEL AGAMA
        $data                = $this->sistem->dataHome();
        $data_pensiun        = $this->kategori->dataPensiunUser();

        // VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        include "view/dashboard.php";
    }
    
    // FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
    function insert_pensiun()
    {
        // DARI VIEW
        // MENAMPUNG DATA YANG DIINPUTKAN
        $nama       = $_POST['nama'];
        $size       = $_POST['size'];
        $nip        = $_POST['nip'];
        $karyawan = '';
        include("config/koneksi.php");
        $query_status = "select * from pegawai where nip = '{$nip}'";
        $status = mysqli_query($koneksi, $query_status);
        while ($row_status = mysqli_fetch_array($status)) {
            $karyawan = $row_status['nama'];
        }
        $ekstensi = implode(",", $_POST['ekstensi']);

        // DARI MODEL
        // MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
        $jenis_pengajuan = 'pensiun';
        $data = $this->kategori->dataInsert_Pensiun($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan);

        // DARI VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES INSERT BERHASIL
        if ($data        == TRUE) {
            echo "<script>
                          window.location = 'index.php?controller=pensiun&method=select'; 
                          </script>";
        }
        // MENGARAHKAN KE FILE VIEW/INSERT.PHP
        // JIKA HASIL PROSES INSERT GAGAL
        else {
            echo "<script> 
                          alert('Proses Insert Gagal!');
                          window.location = 'index.php?controller=pensiun&method=select'; 
                          </script>";
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
    function insert_pensiun_berkas()
    {
        // DARI VIEW
        // MENAMPUNG DATA YANG DIINPUTKAN
        if (isset($_POST['submit'])) {
            $nip = $_SESSION['nip'];
            $tanggal     = date("d-m-Y H:i:s");
            $status = 'Upload Berkas';
            
            // Buat direktori jika belum ada
            if (!file_exists('upload_berkas/pensiun/')) {
                mkdir('upload_berkas/pensiun/', 0777, true);
            }
            
            for ($i = 0; $i < count($_POST['nama_file']); $i++) {
                $nama_file     = $_POST['nama_file'][$i];
                $size_file     = $_POST['size_file'][$i];
                $ekstensi = $_POST['accept_file'][$i];
                $filename = $_FILES["file"]["name"][$i];
                $tempname = $_FILES["file"]["tmp_name"][$i];
                
                // Generate nama file unik untuk menghindari duplikasi
                $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
                $unique_filename = date('YmdHis') . '_' . uniqid() . '.' . $file_ext;
                $folder = "upload_berkas/pensiun/" . $unique_filename;
                
                if (move_uploaded_file($tempname, $folder)) {
                    // DARI MODEL
                    // MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
                    $data = $this->kategori->dataInsert_PensiunBerkas($nama_file, $size_file, $ekstensi, $unique_filename, $nip, $tanggal, $status);
                    
                    // DARI VIEW
                    // MENGARAHKAN KE FILE VIEW/SELECT.PHP
                    // JIKA HASIL PROSES INSERT BERHASIL
                    if ($data == TRUE) {
                        $success = true;
                    } else {
                        $success = false;
                    }
                } else {
                    $success = false;
                }
            }
            
            if (isset($success) && $success) {
                echo "<script>
                        alert('Proses Insert Berhasil!');
                        window.location = 'index.php?controller=pensiun&method=select'; 
                      </script>";
            } else {
                echo "<script> 
                        alert('Proses Insert Gagal!');
                        window.location = 'index.php?controller=pensiun&method=select'; 
                      </script>";
            }
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
    function update_status()
    {
        // DARI CONTROLLER
        // MENAMPUNG DATA YANG DIUBAH
        $id        = $_POST['id'];
        $status    = $_POST['status'];
        $reason    = $_POST['reason'];
        $tanggal   = date("d-m-Y H:i:s");
        
        $upload_file = null;

        
        
        // Cek apakah ada file yang diupload
        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == 0) {
            $filename   = $_FILES['upload_file']['name'];
            $tempname   = $_FILES['upload_file']['tmp_name'];
            
            // Validasi ekstensi file
            $allowed_extensions = array('pdf', 'doc', 'docx', 'zip', 'rar');
            $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
            
            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                // Buat direktori jika belum ada
                if (!file_exists('upload_berkas/pensiun/')) {
                    mkdir('upload_berkas/pensiun/', 0777, true);
                }
                
                // Generate nama file unik untuk menghindari duplikasi
                $unique_filename = date('YmdHis') . '_' . uniqid() . '.' . $file_extension;
                $folder     = "upload_berkas/pensiun/" . $unique_filename;
                
                // Pindahkan file ke folder tujuan
                if (move_uploaded_file($tempname, $folder)) {
                    $upload_file = $unique_filename;
                } else {
                    echo "<script> 
                            alert('Gagal mengupload file!');
                            window.location = 'index.php?controller=pensiun&method=user'; 
                          </script>";
                    return;
                }
            } else {
                echo "<script> 
                        alert('Ekstensi file tidak diizinkan! Hanya PDF, DOC, dan DOCX yang diperbolehkan.');
                        window.location = 'index.php?controller=pensiun&method=user'; 
                      </script>";
                return;
            }
        }

        // DARI MODEL
        // MENGARAH KE METHOD DI CLASS MODEL PENDUDUK
        $data = $this->kategori->dataUpdate_Pensiun($id, $status, $reason, $tanggal, $upload_file);
        
        // DARI VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES UPDATE BERHASIL
        if ($data == TRUE) {
            echo "<script> 
                          window.location = 'index.php?controller=pensiun&method=user'; 
                          </script>";
        }
        // MENGARAHKAN KE FILE VIEW/UPDATE.PHP
        // JIKA HASIL PROSES UPDATE GAGAL
        else {
            echo "<script> 
                          alert('Proses Update Gagal!');
                          window.location = 'index.php?controller=pensiun&method=user'; 
                          </script>";
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES DELETE
    function delete_pensiun()
    {
        // DARI CONTROLLER
        // MENANGKAP NILAI NIK
        $id         = $_GET['id'];
        $data = $this->kategori->dataDeletePensiun($id);
        
        /// DARI VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES DELETE BERHASIL
        if ($data == TRUE) {
            echo "<script> 
                          alert('Proses Delete Berhasil!');
                          window.location = 'index.php?controller=pensiun&method=select'; 
                          </script>";
        }
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES DELETE GAGAL
        else {
            echo "<script>
                            alert('Proses Delete Gagal!'); 
                          window.location = 'index.php?controller=pensiun&method=select'; 
                          </script>";
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES DELETE
    function delete()
    {
        // DARI CONTROLLER
        // MENANGKAP NILAI NIK
        $id         = $_GET['id'];
        
        // Hapus file terkait jika ada
        include("config/koneksi.php");
        $query = "SELECT upload FROM pensiun WHERE id = '$id'";
        $result = mysqli_query($koneksi, $query);
        if ($row = mysqli_fetch_assoc($result)) {
            if (!empty($row['upload'])) {
                $file_path = "upload_berkas/pensiun/" . $row['upload'];
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
        }
        
        $data = $this->kategori->dataDeletePensiunBerkas($id);
        
        /// DARI VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES DELETE BERHASIL
        if ($data == TRUE) {
            if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
                echo "<script> 
                          alert('Proses Delete Berhasil!');
                          window.location = 'index.php?controller=pensiun&method=user'; 
                          </script>";
            } elseif ($_SESSION['level_simpeg'] == 'user') {
                echo "<script> 
                alert('Proses Delete Berhasil!');
                window.location = 'index.php?controller=pensiun&method=read'; 
                </script>";
            }
        }
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES DELETE GAGAL
        else {
            if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
                echo "<script> 
                              alert('Proses Delete Gagal!');
                              window.location = 'index.php?controller=pensiun&method=user'; 
                              </script>";
            } elseif ($_SESSION['level_simpeg'] == 'user') {
                echo "<script> 
                    alert('Proses Delete Gagal!');
                    window.location = 'index.php?controller=pensiun&method=read'; 
                    </script>";
            }
        }
    }
}
?>