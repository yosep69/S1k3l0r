<?php
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_pangkat.php");
include("model/model_sistem.php");
// CLASS PANGKAT
class pangkat
{
    // PROPERTY
    // DIGUNAKAN UNTUK MENJADI OBJEK SAAT INSTANSIASI DI SINI
    public $kategori;
    public $sistem;
    
    // METHOD
    // FUNCTION __CONSTRUCT UNTUK MENANGANI INSTANSIASI CLASS DARI MODEL 
    function __construct()
    {
        // INSTANSIASI CLASS MODEL PANGKAT
        $this->kategori = new model_pangkat();
        $this->sistem   = new model_sistem();
    }
    
    // FUNCTION UNTUK MENANGANI PROSES SELECT
    function select()
    {
        // MODEL
        // MENGARAH KE METHOD DI CLASS MODEL SISTEM
        $data           = $this->sistem->dataHome();
        $data_pangkat   = $this->kategori->dataPangkatKonfigurasi();

        // VIEW
        // MENGARAHKAN KE FILE VIEW/DASHBOARD.PHP
        include "view/dashboard.php";
    }
    
    function user()
    {
        // MODEL
        // MENGARAH KE METHOD DI CLASS MODEL PANGKAT
        $data           = $this->sistem->dataHome();
        $data_pangkat   = $this->kategori->dataPangkat();

        // VIEW
        // MENGARAHKAN KE FILE VIEW/DASHBOARD.PHP
        include "view/dashboard.php";
    }
    
    function read()
    {
        // MODEL
        // MENGARAH KE METHOD DI CLASS MODEL PANGKAT
        $data           = $this->sistem->dataHome();
        $data_pangkat   = $this->kategori->dataPangkatUser();

        // VIEW
        // MENGARAHKAN KE FILE VIEW/DASHBOARD.PHP
        include "view/dashboard.php";
    }
    
    // FUNCTION UNTUK MENANGANI PROSES INSERT KE TABEL
    function insert_pangkat()
    {
        // DARI VIEW
        // MENAMPUNG DATA YANG DIINPUTKAN
        $nama       = $_POST['nama'];
        $size       = $_POST['size'];
        $nip        = $_POST['nip'];
        $karyawan   = '';
        
        include("config/koneksi.php");
        $query_status = "select * from pegawai where nip = '{$nip}'";
        $status = mysqli_query($koneksi, $query_status);
        while ($row_status = mysqli_fetch_array($status)) {
            $karyawan = $row_status['nama'];
        }
        $ekstensi = implode(",", $_POST['ekstensi']);

        // DARI MODEL
        // MENGARAH KE METHOD DI CLASS MODEL PANGKAT
        $jenis_pengajuan = 'pangkat';
        $data = $this->kategori->dataInsert_Pangkat($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan);

        // DARI VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES INSERT BERHASIL
        if ($data == TRUE) {
            echo "<script>
                      window.location = 'index.php?controller=pangkat&method=select'; 
                      </script>";
        }
        // MENGARAHKAN KE FILE VIEW/INSERT.PHP
        // JIKA HASIL PROSES INSERT GAGAL
        else {
            echo "<script> 
                      alert('Proses Insert Gagal!');
                      window.location = 'index.php?controller=pangkat&method=select'; 
                      </script>";
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES INSERT BERKAS
    function insert_pangkat_berkas()
    {
        if (isset($_POST['submit'])) {
            $nip     = $_SESSION['nip'];
            // Perbaikan format tanggal untuk database (Y-m-d H:i:s)
            $tanggal = date("Y-m-d H:i:s");
            $status  = 'Upload Berkas';
            
            // Buat folder upload jika belum ada
            if (!file_exists('upload_berkas')) {
                mkdir('upload_berkas', 0777, true);
            }
            
            for ($i = 0; $i < count($_POST['nama_file']); $i++) {
                $nama_file  = $_POST['nama_file'][$i];
                $size_file  = $_POST['size_file'][$i];
                $ekstensi   = $_POST['accept_file'][$i];
                $filename   = $_FILES["file"]["name"][$i];
                $tempname   = $_FILES["file"]["tmp_name"][$i];
                
                if (!empty($filename)) {
                    $folder = "upload_berkas/" . $filename;
                    
                    // Cek apakah file berhasil diupload
                    if (!move_uploaded_file($tempname, $folder)) {
                        echo "<script> 
                                alert('Gagal mengupload file: $filename');
                                window.location = 'index.php?controller=pangkat&method=select'; 
                              </script>";
                        exit;
                    }
                }
                
                $data = $this->kategori->dataInsert_PangkatBerkas(
                    $nama_file,
                    $size_file,
                    $ekstensi,
                    $filename,
                    $nip,
                    $tanggal,
                    $status
                );
                
                if (!$data) {
                    echo "<script> 
                            alert('Proses Insert Gagal!');
                            window.location = 'index.php?controller=pangkat&method=select'; 
                          </script>";
                    exit;
                }
            }
            
            echo "<script>
                    alert('Proses Insert Berhasil!');
                    window.location = 'index.php?controller=pangkat&method=select'; 
                  </script>";
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES UPDATE STATUS
    function update_status()
    {
        $id      = $_POST['id'];
        $status  = $_POST['status'];
        $reason  = $_POST['reason'];
        // Perbaikan format tanggal untuk database (Y-m-d H:i:s)
        $tanggal = date("Y-m-d H:i:s");
        $upload_file = null;
        
        // Buat folder upload jika belum ada
        if (!file_exists('upload_berkas')) {
            mkdir('upload_berkas', 0777, true);
        }
        
        // Cek apakah ada file yang diupload
        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == 0) {
            $file_name = $_FILES['upload_file']['name'];
            $file_tmp  = $_FILES['upload_file']['tmp_name'];
            $file_size = $_FILES['upload_file']['size'];
            $file_type = $_FILES['upload_file']['type'];
            
            // Validasi tipe file jika diperlukan
            $allowed_types = array('application/pdf', 'image/jpeg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
            
            if (in_array($file_type, $allowed_types)) {
                $folder = "upload_berkas/" . $file_name;
                
                // Pindahkan file ke folder tujuan
                if (move_uploaded_file($file_tmp, $folder)) {
                    $upload_file = $file_name;
                } else {
                    // Jika gagal upload, set $upload_file ke null
                    $upload_file = null;
                }
            } else {
                echo "<script> 
                        alert('Tipe file tidak diizinkan! Silakan upload file PDF, JPG, PNG, atau DOC.');
                        window.location = 'index.php?controller=pangkat&method=user'; 
                      </script>";
                exit;
            }
        }
        
        // Panggil model untuk update data
        $data = $this->kategori->dataUpdate_Pangkat($id, $status, $reason, $tanggal, $upload_file);
        
        if ($data == TRUE) {
            echo "<script> 
                    alert('Proses Update Berhasil!');
                    window.location = 'index.php?controller=pangkat&method=user'; 
                  </script>";
        } else {
            echo "<script> 
                    alert('Proses Update Gagal!');
                    window.location = 'index.php?controller=pangkat&method=user'; 
                  </script>";
        }
    }
    
    // FUNCTION UNTUK MENANGANI PROSES DELETE
    function delete()
    {
        // DARI CONTROLLER
        // MENANGKAP NILAI ID
        $id = $_GET['id'];
        
        // Hapus file terkait jika ada
        include("config/koneksi.php");
        $query = "SELECT file, upload FROM pangkat WHERE id = '$id'";
        $result = mysqli_query($koneksi, $query);
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            
            // Hapus file utama
            if (!empty($row['file']) && file_exists("upload_berkas/" . $row['file'])) {
                unlink("upload_berkas/" . $row['file']);
            }
            
            // Hapus file upload tambahan
            if (!empty($row['upload']) && file_exists("upload_berkas/" . $row['upload'])) {
                unlink("upload_berkas/" . $row['upload']);
            }
        }
        
        $data = $this->kategori->dataDeletePangkatBerkas($id);
        
        // DARI VIEW
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES DELETE BERHASIL
        if ($data == TRUE) {
            if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
                echo "<script> 
                          alert('Proses Delete Berhasil!');
                          window.location = 'index.php?controller=pangkat&method=user'; 
                          </script>";
            } elseif ($_SESSION['level_simpeg'] == 'user') {
                echo "<script> 
                          alert('Proses Delete Berhasil!');
                          window.location = 'index.php?controller=pangkat&method=read'; 
                          </script>";
            }
        }
        // MENGARAHKAN KE FILE VIEW/SELECT.PHP
        // JIKA HASIL PROSES DELETE GAGAL
        else {
            if ($_SESSION['level_simpeg'] == 'superadmin' || $_SESSION['level_simpeg'] == 'admin') {
                echo "<script> 
                              alert('Proses Delete Gagal!');
                              window.location = 'index.php?controller=pangkat&method=user'; 
                              </script>";
            } elseif ($_SESSION['level_simpeg'] == 'user') {
                echo "<script> 
                          alert('Proses Delete Gagal!');
                          window.location = 'index.php?controller=pangkat&method=read'; 
                          </script>";
            }
        }
    }
}
?>