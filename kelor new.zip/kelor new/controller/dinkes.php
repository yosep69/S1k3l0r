<?php  
// INCLUDE KONEKSI DATABASE 
include("config/database.php");
// INCLUDE MODEL DARI FOLDER MODEL 
include("model/model_dinkes.php");
include("model/model_sistem.php");

// CLASS DINKES
class dinkes
{
    // PROPERTY
    public $kategori;
    public $sistem;
    
    // CONSTRUCT
    function __construct()
    {
        // INSTANSIASI MODEL DINKES
        $this->kategori  = new model_dinkes();
        $this->sistem    = new model_sistem();
    }
    
    // FUNCTION UNTUK MENAMPILKAN DATA KONFIGURASI
    function select()
    {
        $data           = $this->sistem->dataHome();
        $data_dinkes    = $this->kategori->dataDinkesKonfigurasi();
        include "view/dashboard.php";
    }
    
    function user()
    {
        $data           = $this->sistem->dataHome();
        $data_dinkes    = $this->kategori->dataDinkes();
        include "view/dashboard.php";
    }

    function koordinator()
    {
        $data           = $this->sistem->dataHome();
        $data_dinkes    = $this->kategori->dataDinkes();
        include "view/dashboard.php";
    }
    
    function read()
    {
        $data           = $this->sistem->dataHome();
        $data_dinkes    = $this->kategori->dataDinkesUser();
        $data_dinkes    = $this->kategori->dataDinkesKoordinator();
        include "view/dashboard.php";
    }
    
    // FUNCTION UNTUK INSERT KONFIGURASI
    function insert_dinkes()
    {
        $nama       = $_POST['nama'];
        $size       = $_POST['size'];
        $nip        = $_POST['nip'];
        $karyawan   = '';
        
        include("config/koneksi.php");
        $query_status = "SELECT * FROM pegawai WHERE nip = '{$nip}'";
        $status = mysqli_query($koneksi, $query_status);
        while ($row_status = mysqli_fetch_array($status)) {
            $karyawan = $row_status['nama'];
        }
        
        $ekstensi = implode(",", $_POST['ekstensi']);
        $jenis_pengajuan = 'dinkes';
        
        $data = $this->kategori->dataInsert_Dinkes($nama, $size, $ekstensi, $nip, $karyawan, $jenis_pengajuan);

        if ($data == TRUE) {
            echo "<script>
                  window.location = 'index.php?controller=dinkes&method=select'; 
                  </script>";
        } else {
            echo "<script> 
                  alert('Proses Insert Gagal!');
                  window.location = 'index.php?controller=dinkes&method=select'; 
                  </script>";
        }
    }
    
    // FUNCTION UNTUK INSERT BERKAS
    function insert_dinkes_berkas()
    {
        if (isset($_POST['submit'])) {
            $nip = $_SESSION['nip'];
            $tanggal = date("d-m-Y H:i:s");
            $status = 'Upload Berkas';
            
            if (!file_exists('surat/dinkes/')) {
                mkdir('surat/dinkes/', 0777, true);
            }
            
            for ($i = 0; $i < count($_POST['nama_file']); $i++) {
                $nama_file = $_POST['nama_file'][$i];
                $size_file = $_POST['size_file'][$i];
                $ekstensi = $_POST['accept_file'][$i];
                $filename = $_FILES["file"]["name"][$i];
                $tempname = $_FILES["file"]["tmp_name"][$i];
                
                $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
                $unique_filename = date('YmdHis') . '_' . uniqid() . '.' . $file_ext;
                $folder = "surat/dinkes/" . $unique_filename;
                
                if (move_uploaded_file($tempname, $folder)) {
                    $data = $this->kategori->dataInsert_DinkesBerkas($nama_file, $size_file, $ekstensi, $unique_filename, $nip, $tanggal, $status);
                    $success = $data ? true : false;
                } else {
                    $success = false;
                }
            }
            
            if (isset($success) && $success) {
                echo "<script>
                        alert('Proses Insert Berhasil!');
                        window.location = 'index.php?controller=dinkes&method=select'; 
                      </script>";
            } else {
                echo "<script> 
                        alert('Proses Insert Gagal!');
                        window.location = 'index.php?controller=dinkes&method=select'; 
                      </script>";
            }
        }
    }
    
    // FUNCTION UNTUK UPDATE STATUS
    function update_status()
    {
        $id        = $_POST['id'];
        $status    = $_POST['status'];
        $reason    = $_POST['reason'];
        $tanggal   = date("d-m-Y H:i:s");
        $upload_file = null;
        
        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] == 0) {
            $filename   = $_FILES['upload_file']['name'];
            $tempname   = $_FILES['upload_file']['tmp_name'];
            $allowed_extensions = array('pdf','doc','docx');
            $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
            
            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                if (!file_exists('surat/dinkes/')) mkdir('surat/dinkes/', 0777, true);
                $unique_filename = date('YmdHis') . '_' . uniqid() . '.' . $file_extension;
                $folder = "surat/dinkes/" . $unique_filename;
                if (move_uploaded_file($tempname, $folder)) $upload_file = $unique_filename;
            } else {
                echo "<script>alert('Ekstensi file tidak diizinkan!');window.location='index.php?controller=dinkes&method=user';</script>";
                return;
            }
        }

        $data = $this->kategori->dataUpdate_Dinkes($id, $status, $reason, $tanggal, $upload_file);
        if ($data == TRUE) {
            echo "<script>window.location='index.php?controller=dinkes&method=user';</script>";
        } else {
            echo "<script>alert('Proses Update Gagal!');window.location='index.php?controller=dinkes&method=user';</script>";
        }
    }
    
    // FUNCTION UNTUK DELETE KONFIGURASI
    function delete_dinkes()
    {
        $id = $_GET['id'];
        $data = $this->kategori->dataDeleteDinkes($id);
        if ($data == TRUE) {
            echo "<script>alert('Proses Delete Berhasil!');window.location='index.php?controller=dinkes&method=select';</script>";
        } else {
            echo "<script>alert('Proses Delete Gagal!');window.location='index.php?controller=dinkes&method=select';</script>";
        }
    }
    
    // FUNCTION UNTUK DELETE BERKAS
    function delete()
    {
        $id = $_GET['id'];
        include("config/koneksi.php");
        $query = "SELECT upload FROM dinkes WHERE id = '$id'";
        $result = mysqli_query($koneksi, $query);
        if ($row = mysqli_fetch_assoc($result)) {
            if (!empty($row['upload'])) {
                $file_path = "surat/dinkes/" . $row['upload'];
                if (file_exists($file_path)) unlink($file_path);
            }
        }
        
        $data = $this->kategori->dataDeleteDinkesBerkas($id);
        if ($data == TRUE) {
            $redirect = ($_SESSION['level_simpeg'] == 'user') ? 'read' : 'user';
            echo "<script>alert('Proses Delete Berhasil!');window.location='index.php?controller=dinkes&method={$redirect}';</script>";
        } else {
            $redirect = ($_SESSION['level_simpeg'] == 'user') ? 'read' : 'user';
            echo "<script>alert('Proses Delete Gagal!');window.location='index.php?controller=dinkes&method={$redirect}';</script>";
        }
    }
}
?>
